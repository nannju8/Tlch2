package com.vidgrab.app.ui.browser

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.Spring
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.ExperimentalFoundationApi as EFA
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.animation.core.animateColorAsState
import com.vidgrab.app.browser.TabManager
import com.vidgrab.app.browser.TabState
import com.vidgrab.app.browser.findActivity
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.Bookmark
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.net.Suggest
import com.vidgrab.app.ui.brushFor
import com.vidgrab.app.ui.components.Badge
import com.vidgrab.app.ui.components.DownloadFab
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.components.GlassIconButton
import com.vidgrab.app.ui.components.GradientButton
import com.vidgrab.app.ui.components.TabCountButton
import com.vidgrab.app.ui.components.glassBorder
import com.vidgrab.app.ui.components.staggerIn
import com.vidgrab.app.ui.fmtBytes
import com.vidgrab.app.ui.glowFor
import com.vidgrab.app.ui.hostLabel
import com.vidgrab.app.ui.initialOf
import com.vidgrab.app.ui.theme.Aurora
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce

@Composable
fun BrowserScreen(bottomPad: Dp, onOpenSettings: () -> Unit, onOpenTabs: () -> Unit) {
    val ctx = LocalContext.current
    // Le contexte d'Activity doit toujours être attaché aux WebView (menus <select> natifs).
    androidx.compose.runtime.DisposableEffect(ctx) {
        ctx.findActivity()?.let { TabManager.attachActivity(it) }
        onDispose { }
    }
    val tab = TabManager.current
    Crossfade(targetState = tab.id to tab.url.isEmpty(), label = "browser") { (_, home) ->
        if (home) HomeScreen(tab, bottomPad, onOpenSettings, onOpenTabs)
        else WebScreen(tab, bottomPad, onOpenTabs)
    }
}

// =====================================================================================
//  ACCUEIL
// =====================================================================================
private data class Platform(val name: String, val url: String, val glyph: String, val color: Color)

private val platforms = listOf(
    Platform("Facebook", "https://m.facebook.com", "f", Color(0xFF1877F2)),
    Platform("Instagram", "https://www.instagram.com", "In", Color(0xFFE1306C)),
    Platform("Vimeo", "https://vimeo.com", "V", Color(0xFF1AB7EA)),
    Platform("Dailymotion", "https://www.dailymotion.com", "d", Color(0xFF0066DC)),
    Platform("TikTok", "https://www.tiktok.com", "T", Color(0xFF25F4EE))
)

@OptIn(FlowPreview::class, ExperimentalFoundationApi::class)
@Composable
private fun HomeScreen(tab: TabState, bottomPad: Dp, onOpenSettings: () -> Unit, onOpenTabs: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val google = remember { mutableStateListOf<String>() }

    LaunchedEffect(Unit) {
        snapshotFlow { query }.debounce(300).collectLatest { q ->
            google.clear()
            if (q.trim().length >= 2) google.addAll(Suggest.fetch(q.trim()))
        }
    }

    fun go(s: String) { TabManager.navigate(tab, s) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        // Barre supérieure
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TabCountButton(TabManager.tabs.size, onOpenTabs)
            Box(Modifier.weight(1f))
            GlassIconButton(Icons.AutoMirrored.Rounded.HelpOutline, "Aide", { showHelp = true })
            Box(Modifier.width(8.dp))
            GlassIconButton(Icons.Rounded.Settings, "Paramètres", onOpenSettings)
            Box(Modifier.width(8.dp))
            Box {
                GlassIconButton(Icons.Rounded.MoreVert, "Menu", { menu = true })
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Nouvel onglet") },
                        leadingIcon = { Icon(Icons.Rounded.Add, null) },
                        onClick = { menu = false; TabManager.newTab() }
                    )
                    DropdownMenuItem(
                        text = { Text("Effacer l'historique") },
                        leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) },
                        onClick = { menu = false; AppPrefs.clearHistory() }
                    )
                }
            }
        }

        Box(Modifier.height(28.dp))
        Text("VidGrab", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
        Text("Naviguez, détectez, téléchargez.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(Modifier.height(18.dp))

        SearchPill(query, { query = it }, focused, { focused = it }, onSubmit = { go(it) })

        // Suggestions : favoris + historique + Google
        val q = query.trim()
        val favs = if (q.isEmpty()) emptyList() else AppPrefs.bookmarks.filter { it.title.contains(q, true) || it.url.contains(q, true) }.take(3)
        val hist = if (q.isEmpty()) emptyList() else AppPrefs.history.filter { it.title.contains(q, true) || it.url.contains(q, true) }.take(3)
        AnimatedVisibility(
            visible = q.isNotEmpty() && (favs.isNotEmpty() || hist.isNotEmpty() || google.isNotEmpty()),
            enter = expandVertically(spring()) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            GlassCard(Modifier.fillMaxWidth().padding(top = 10.dp), glow = Aurora.Cyan) {
                Column(Modifier.padding(vertical = 6.dp)) {
                    favs.forEach { SuggestionRow(Icons.Rounded.Bookmark, it.title, Aurora.Gold) { go(it.url) } }
                    hist.forEach { SuggestionRow(Icons.Rounded.History, it.title, Aurora.Indigo) { go(it.url) } }
                    google.forEach { SuggestionRow(Icons.Rounded.Search, it, Aurora.Cyan) { go(it) } }
                }
            }
        }

        // Raccourcis 3D
        Box(Modifier.height(26.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            platforms.forEachIndexed { i, p -> Medallion(p, Modifier.staggerIn(i)) { go(p.url) } }
        }

        // Mes favoris
        Box(Modifier.height(28.dp))
        SectionTitle("Mes favoris")
        if (AppPrefs.bookmarks.isEmpty()) {
            Text(
                "Touchez ★ dans la barre d'adresse pour ajouter un site.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            LazyRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(AppPrefs.bookmarks.toList(), key = { it.url }) { b ->
                    BookmarkCard(b, onOpen = { go(b.url) })
                }
            }
        }

        // Sites récents
        Box(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Sites récemment utilisés", Modifier.weight(1f))
            if (AppPrefs.history.isNotEmpty()) {
                TextButton(onClick = { AppPrefs.clearHistory() }) {
                    Icon(Icons.Rounded.DeleteSweep, null, modifier = Modifier.size(18.dp))
                    Text("  Effacer", fontSize = 13.sp)
                }
            }
        }
        val recent by remember { derivedStateOf { AppPrefs.history.distinctBy { hostLabel(it.url) }.take(5) } }
        if (recent.isEmpty()) {
            Text("Aucun historique pour le moment.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                recent.forEach { h ->
                    Column(
                        Modifier.width(62.dp).clip(RoundedCornerShape(14.dp)).clickable { go(h.url) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(50.dp)
                                .shadow(8.dp, CircleShape, ambientColor = glowFor(h.url), spotColor = glowFor(h.url))
                                .clip(CircleShape).background(brushFor(h.url)),
                            contentAlignment = Alignment.Center
                        ) { Text(initialOf(h.title, h.url), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                        Text(
                            hostLabel(h.url), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Aide
        Box(Modifier.height(30.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            GradientButton("Comment télécharger", Aurora.navBrush, { showHelp = true }, icon = Icons.AutoMirrored.Rounded.HelpOutline)
        }
        Box(Modifier.height(bottomPad + 16.dp))
    }

    if (showHelp) HelpGuideDialog { showHelp = false }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
private fun SuggestionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        Text(text, Modifier.padding(start = 14.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
    }
}

/** Barre pilule : morphing fluide au focus (élargissement, halo, échelle). */
@Composable
private fun SearchPill(query: String, onQuery: (String) -> Unit, focused: Boolean, onFocus: (Boolean) -> Unit, onSubmit: (String) -> Unit) {
    val hp by animateDpAsState(if (focused) 0.dp else 10.dp, spring(), label = "hp")
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(300), label = "glow")
    val scale by animateFloatAsState(if (focused) 1.02f else 1f, spring(), label = "scale")
    val shape = CircleShape
    val border = if (focused || glow > 0.01f) Brush.linearGradient(listOf(Aurora.Indigo.copy(alpha = glow), Aurora.Cyan.copy(alpha = glow)))
    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.15f), Color.Transparent))
    Row(
        Modifier.fillMaxWidth().padding(horizontal = hp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .height(56.dp)
            .shadow((6 + 14 * glow).dp, shape, ambientColor = Aurora.Indigo, spotColor = Aurora.Cyan)
            .clip(shape).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.78f))
            .border(1.5.dp, border, shape).padding(start = 18.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
            cursorBrush = SolidColor(Aurora.Cyan),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
            keyboardActions = KeyboardActions(onGo = { onSubmit(query) }),
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp).onFocusChanged { onFocus(it.isFocused) },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Rechercher ou inscrire l'URL", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
                    inner()
                }
            }
        )
        if (query.isNotEmpty()) {
            Box(Modifier.size(36.dp).clip(CircleShape).clickable { onQuery("") }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, "Effacer", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Aurora.navBrush).clickable { onSubmit(query) },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Rounded.ArrowForward, "Valider", tint = Color.White) }
        }
    }
}

/** Médaillon circulaire en relief avec effet d'enfoncement 3D au toucher. */
@Composable
private fun Medallion(p: Platform, modifier: Modifier, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val ip = remember { MutableInteractionSource() }
    val pressed by ip.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.86f else 1f, spring(0.5f, Spring.StiffnessMedium), label = "s")
    val rx by animateFloatAsState(if (pressed) 14f else 0f, spring(0.5f), label = "rx")
    val elev by animateDpAsState(if (pressed) 2.dp else 14.dp, label = "elev")
    Column(
        modifier.width(62.dp).clickable(interactionSource = ip, indication = null) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick()
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(58.dp)
                .graphicsLayer { scaleX = s; scaleY = s; rotationX = rx; cameraDistance = 16f * density }
                .shadow(elev, CircleShape, ambientColor = p.color, spotColor = p.color)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(p.color.copy(alpha = 0.75f), p.color)))
                .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(p.glyph, color = if (p.name == "TikTok") Color.Black else Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        }
        Text(p.name, fontSize = 10.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun BookmarkCard(b: Bookmark, onOpen: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    Box {
        GlassCard(Modifier.width(96.dp).height(110.dp), glow = glowFor(b.url), tilt = true, onClick = onOpen, onLongClick = { menu = true }) {
            Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(brushFor(b.url)),
                    contentAlignment = Alignment.Center
                ) { Text(initialOf(b.title, b.url), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
                Text(
                    b.title, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; rename = true })
            DropdownMenuItem(text = { Text("Supprimer") }, leadingIcon = { Icon(Icons.Rounded.Delete, null) }, onClick = { menu = false; AppPrefs.removeBookmark(b) })
        }
    }
    if (rename) {
        var text by remember { mutableStateOf(b.title) }
        AlertDialog(
            onDismissRequest = { rename = false },
            title = { Text("Renommer le favori") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ AppPrefs.renameBookmark(b, text); rename = false }) { Text("OK") } },
            dismissButton = { TextButton({ rename = false }) { Text("Annuler") } }
        )
    }
}

// ---- Guide interactif ----
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HelpGuideDialog(onDismiss: () -> Unit) {
    val steps = listOf(
        Triple(Icons.Rounded.Search, "1. Ouvrez un site", "Tapez une adresse ou choisissez un raccourci (Vimeo, Dailymotion…)."),
        Triple(Icons.Rounded.OpenInBrowser, "2. Lancez la vidéo", "Appuyez sur lecture : VidGrab démasque les flux, même cachés."),
        Triple(Icons.Rounded.Star, "3. Le bouton s'illumine", "Le bouton corail/magenta affiche le nombre de flux détectés."),
        Triple(Icons.Rounded.Share, "4. Choisissez et téléchargez", "Sélectionnez la qualité, suivez l'avancement dans « Progression ».")
    )
    val pager = rememberPagerState { steps.size }
    val scope = rememberCoroutineScope()
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        GlassCard(Modifier.padding(20.dp).fillMaxWidth(), glow = Aurora.Indigo) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                HorizontalPager(pager, Modifier.fillMaxWidth().height(230.dp)) { i ->
                    val (icon, title, text) = steps[i]
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(
                            Modifier.size(84.dp).shadow(16.dp, CircleShape, ambientColor = Aurora.Indigo, spotColor = Aurora.Cyan)
                                .clip(CircleShape).background(Aurora.navBrush),
                            contentAlignment = Alignment.Center
                        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp), color = MaterialTheme.colorScheme.onSurface)
                        Text(text, fontSize = 14.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                    }
                }
                Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(steps.size) { i ->
                        val w by animateDpAsState(if (pager.currentPage == i) 22.dp else 8.dp, label = "dot")
                        Box(Modifier.height(8.dp).width(w).clip(CircleShape).background(if (pager.currentPage == i) Aurora.Cyan else Color.Gray.copy(alpha = 0.4f)))
                    }
                }
                GradientButton(
                    if (pager.currentPage == steps.size - 1) "Terminé" else "Suivant", Aurora.navBrush,
                    { if (pager.currentPage == steps.size - 1) onDismiss() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }
                )
            }
        }
    }
}


// =====================================================================================
//  VUE WEB
// =====================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WebScreen(tab: TabState, bottomPad: Dp, onOpenTabs: () -> Unit) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var menu by remember { mutableStateOf(false) }
    var editUrl by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val bookmarked = AppPrefs.bookmarks.any { it.url == tab.url }
    val starRot by animateFloatAsState(if (bookmarked) 360f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "star")
    val starColor by animateColorAsState(if (bookmarked) Aurora.Gold else MaterialTheme.colorScheme.onSurfaceVariant, label = "starc")
    val blurDp by animateDpAsState(if (sheet) 14.dp else 0.dp, label = "blur")
    val progress by animateFloatAsState(tab.progress, tween(200), label = "prog")

    BackHandler {
        val wv = tab.webView
        if (wv != null && wv.canGoBack()) wv.goBack() else TabManager.goHome(tab)
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TabCountButton(TabManager.tabs.size) { TabManager.capturePreview(tab); onOpenTabs() }
            Box(Modifier.width(6.dp))
            GlassIconButton(Icons.Rounded.Home, "Accueil", { TabManager.goHome(tab) })
            Box(Modifier.width(8.dp))
            // Barre d'adresse compacte
            Row(
                Modifier.weight(1f).height(42.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)).glassBorder(CircleShape)
                    .padding(start = 12.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val https = tab.url.startsWith("https://")
                Icon(if (https) Icons.Rounded.Lock else Icons.Rounded.LockOpen, null, modifier = Modifier.size(15.dp), tint = if (https) Aurora.Cyan else Aurora.Coral)
                Text(
                    tab.url.removePrefix("https://").removePrefix("http://").removePrefix("www."),
                    Modifier.weight(1f).padding(horizontal = 8.dp).clickable { editUrl = true },
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    Modifier.size(34.dp).clip(CircleShape).clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        AppPrefs.toggleBookmark(tab.url, tab.title)
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (bookmarked) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favori", tint = starColor,
                        modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = starRot }
                    )
                }
                Box(
                    Modifier.size(34.dp).clip(CircleShape).clickable {
                        if (tab.isLoading) tab.webView?.stopLoading() else TabManager.goHome(tab)
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Close, "Arrêter", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp)) }
            }
            Box {
                GlassIconButton(Icons.Rounded.MoreVert, "Menu", { menu = true }, Modifier.padding(start = 6.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Version ordinateur") },
                        leadingIcon = { Icon(Icons.Rounded.Computer, null) },
                        trailingIcon = { Switch(checked = tab.desktop, onCheckedChange = { TabManager.setDesktop(tab, it); menu = false }) },
                        onClick = { TabManager.setDesktop(tab, !tab.desktop); menu = false }
                    )
                    DropdownMenuItem(text = { Text("Actualiser") }, leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                        onClick = { menu = false; tab.webView?.reload() })
                    DropdownMenuItem(text = { Text("Partager le lien") }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                        onClick = {
                            menu = false
                            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, tab.url) }
                            ctx.startActivity(Intent.createChooser(i, "Partager"))
                        })
                    DropdownMenuItem(text = { Text("Ouvrir dans le navigateur externe") }, leadingIcon = { Icon(Icons.Rounded.OpenInBrowser, null) },
                        onClick = {
                            menu = false
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(tab.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
                        })
                    DropdownMenuItem(text = { Text("Tout effacer") }, leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) },
                        onClick = { menu = false; TabManager.clearAll(tab); Toast.makeText(ctx, "Cache, cookies et historique effacés", Toast.LENGTH_SHORT).show() })
                }
            }
        }

        // Barre de progression lumineuse (Cyan → Indigo)
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (tab.isLoading) {
                Box(Modifier.fillMaxWidth(progress.coerceIn(0.03f, 1f)).fillMaxHeight().background(Brush.horizontalGradient(listOf(Aurora.Cyan, Aurora.Indigo))))
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            Box(Modifier.fillMaxSize().padding(bottom = bottomPad - 8.dp).blur(blurDp)) {
                key(tab.id) {
                    AndroidView(
                        factory = { _ ->
                            val wv = TabManager.ensureWebView(tab)
                            (wv.parent as? ViewGroup)?.removeView(wv)
                            wv
                        },
                        modifier = Modifier.fillMaxSize(),
                        onRelease = { (it.parent as? ViewGroup)?.removeView(it) }
                    )
                }
            }
            DownloadFab(
                count = tab.videos.size,
                onClick = {
                    if (tab.videos.isEmpty()) Toast.makeText(ctx, "Lancez la lecture d'une vidéo pour la détecter", Toast.LENGTH_SHORT).show()
                    else sheet = true
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 4.dp, bottom = bottomPad - 20.dp)
            )
        }
    }

    if (sheet) {
        ModalBottomSheet(
            onDismissRequest = { sheet = false }, sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
            scrimColor = Color.Black.copy(alpha = 0.5f)
        ) {
            Text("Vidéos détectées (${tab.videos.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(tab.videos.toList(), key = { it.url }) { v ->
                    VideoRow(v) {
                        val added = DownloadCenter.enqueue(v)
                        Toast.makeText(ctx, if (added) "Ajouté aux téléchargements" else "Déjà dans la file", Toast.LENGTH_SHORT).show()
                        sheet = false
                    }
                }
                item { Box(Modifier.height(32.dp)) }
            }
        }
    }

    if (editUrl) {
        var text by remember { mutableStateOf(tab.url) }
        AlertDialog(
            onDismissRequest = { editUrl = false },
            title = { Text("Adresse") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ editUrl = false; TabManager.navigate(tab, text) }) { Text("Aller") } },
            dismissButton = { TextButton({ editUrl = false }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun VideoRow(v: DetectedVideo, onDownload: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), glow = Aurora.Coral) {
        Column(Modifier.padding(16.dp)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Badge(v.type, Aurora.Cyan)
                Badge(v.quality, Aurora.Magenta)
                Text(if (v.sizeBytes > 0L) fmtBytes(v.sizeBytes) else "Taille inconnue", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            GradientButton("Télécharger", Aurora.alertBrush, onDownload, Modifier.fillMaxWidth(), glow = Aurora.Coral)
        }
    }
}
