package com.vidgrab.app.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.ContextWrapper
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DetectedVideo
import java.io.ByteArrayInputStream
import java.lang.ref.WeakReference
import java.net.URLEncoder
import java.util.UUID

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

class TabState(val id: String, onVideo: (TabState, DetectedVideo) -> Unit) {
    // --- État Compose (thread principal uniquement) ---
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var isLoading by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var preview by mutableStateOf<ImageBitmap?>(null)
    val videos = mutableStateListOf<DetectedVideo>()

    // --- Champs @Volatile lus depuis le thread réseau de la WebView ---
    @Volatile var currentUrl: String = ""
    @Volatile var currentTitle: String = ""
    @Volatile var lastTypedAt: Long = 0L
    @Volatile var lastRealClickAt: Long = 0L

    var webView: WebView? = null
    var wrapper: MutableContextWrapper? = null
    var pendingUrl: String? = null

    val sniffer = VideoSniffer { v -> onVideo(this, v) }
}

object TabManager {
    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"

    private lateinit var appContext: Context
    private var activityRef: WeakReference<Activity>? = null
    private val main = Handler(Looper.getMainLooper())

    val tabs = mutableStateListOf<TabState>()
    var currentId by mutableStateOf("")
        private set

    val current: TabState
        get() = tabs.firstOrNull { it.id == currentId } ?: tabs.first()

    fun init(ctx: Context) {
        if (::appContext.isInitialized) return
        appContext = ctx.applicationContext
        newTab()
    }

    // ---------- Cycle de vie du MutableContextWrapper ----------
    /** Appelé dans onCreate/onResume : les <select> HTML natifs exigent un contexte d'Activity. */
    fun attachActivity(activity: Activity) {
        activityRef = WeakReference(activity)
        tabs.forEach { it.wrapper?.setBaseContext(activity) }
    }

    /** Appelé dans onDestroy : évite toute fuite mémoire lors des rotations. */
    fun detachActivity(activity: Activity) {
        tabs.forEach { t ->
            val w = t.wrapper
            if (w != null && w.baseContext === activity) w.setBaseContext(appContext)
        }
        if (activityRef?.get() === activity) activityRef = null
    }

    // ---------- Onglets ----------
    fun newTab(): TabState {
        val tab = TabState(UUID.randomUUID().toString()) { t, v ->
            main.post { if (t.videos.none { it.url == v.url }) t.videos.add(v) }
        }
        tabs.add(tab)
        currentId = tab.id
        return tab
    }

    fun select(tab: TabState) { currentId = tab.id }

    fun closeTab(tab: TabState) {
        tab.webView?.let { wv ->
            wv.removeJavascriptInterface("VidBridge")
            wv.stopLoading()
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        tab.webView = null
        tab.wrapper = null
        tab.sniffer.close()
        val idx = tabs.indexOf(tab)
        tabs.remove(tab)
        if (tabs.isEmpty()) newTab()
        else if (currentId == tab.id) currentId = tabs[minOf(idx, tabs.size - 1)].id
    }

    // ---------- Navigation ----------
    fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (!t.contains(' ') && t.contains('.')) return "https://$t"
        return "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    fun navigate(tab: TabState, input: String) {
        val u = resolve(input)
        if (u.isEmpty()) return
        tab.lastTypedAt = SystemClock.elapsedRealtime()
        tab.url = u
        tab.currentUrl = u
        tab.videos.clear()
        tab.sniffer.reset()
        val wv = tab.webView
        if (wv != null) wv.loadUrl(u) else tab.pendingUrl = u
    }

    fun goHome(tab: TabState) {
        tab.url = ""
        tab.currentUrl = ""
        tab.title = ""
        tab.isLoading = false
        tab.videos.clear()
        tab.sniffer.reset()
        tab.pendingUrl = null
        tab.webView?.let { it.loadUrl("about:blank"); it.clearHistory() }
    }

    fun clearAll(tab: TabState) {
        tab.webView?.let { it.clearCache(true); it.clearHistory(); it.clearFormData() }
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        AppPrefs.clearHistory()
    }

    /** Version ordinateur : UA Chrome Desktop + viewport large, MAJ du UA du sniffer, puis reload(). */
    fun setDesktop(tab: TabState, on: Boolean) {
        tab.desktop = on
        val wv = tab.webView ?: return
        val s = wv.settings
        if (on) {
            s.userAgentString = DESKTOP_UA
            s.useWideViewPort = true
            s.loadWithOverviewMode = true
        } else {
            s.userAgentString = null
            s.useWideViewPort = true
            s.loadWithOverviewMode = false
        }
        tab.sniffer.userAgent = s.userAgentString
        wv.reload()
    }

    fun capturePreview(tab: TabState) {
        val wv = tab.webView ?: return
        if (wv.width <= 0 || wv.height <= 0 || tab.url.isEmpty()) return
        try {
            val full = Bitmap.createBitmap(wv.width, wv.height, Bitmap.Config.ARGB_8888)
            wv.draw(Canvas(full))
            val scaled = Bitmap.createScaledBitmap(full, wv.width / 3, wv.height / 3, true)
            if (scaled !== full) full.recycle()
            tab.preview = scaled.asImageBitmap()
        } catch (_: Throwable) { }
    }

    // ---------- Création de la WebView ----------
    @SuppressLint("SetJavaScriptEnabled")
    fun ensureWebView(tab: TabState): WebView {
        tab.webView?.let { return it }

        // JAMAIS le applicationContext seul : un MutableContextWrapper porte l'Activity courante.
        val wrapper = MutableContextWrapper(appContext)
        activityRef?.get()?.let { wrapper.setBaseContext(it) }
        tab.wrapper = wrapper

        val wv = WebView(wrapper)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.mediaPlaybackRequiresUserGesture = false
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        if (tab.desktop) {
            s.userAgentString = DESKTOP_UA
            s.loadWithOverviewMode = true
        }
        tab.sniffer.userAgent = s.userAgentString
        wv.addJavascriptInterface(Bridge(tab), "VidBridge")
        wv.webViewClient = Client(tab)
        wv.webChromeClient = Chrome(tab)
        tab.webView = wv

        tab.pendingUrl?.let { wv.loadUrl(it); tab.pendingUrl = null }
        return wv
    }

    // ---------- Pont JavaScript ----------
    class Bridge(private val tab: TabState) {
        @Keep
        @JavascriptInterface
        fun onVideoSrc(src: String?, title: String?) {
            if (src.isNullOrBlank() || src.startsWith("blob:") || src.startsWith("data:")) return
            tab.sniffer.onJsVideo(src, tab.currentUrl, title ?: tab.currentTitle)
        }

        @Keep
        @JavascriptInterface
        fun onRealClick(href: String?) {
            tab.lastRealClickAt = SystemClock.elapsedRealtime()
        }
    }

    // ---------- WebViewClient : bouclier anti-pub / anti-redirection / sniffer ----------
    private class Client(private val tab: TabState) : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url.toString()
            // Sous-requête vers une régie → réponse vide 200 OK
            if (!request.isForMainFrame && AdBlock.isAdUrl(url)) {
                return WebResourceResponse("text/plain", "utf-8", 200, "OK", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
            val scheme = request.url.scheme
            if (scheme == "http" || scheme == "https") {
                val cookie = try { CookieManager.getInstance().getCookie(url) } catch (e: Exception) { null }
                // Thread IO : uniquement les champs @Volatile de TabState
                tab.sniffer.onRequest(url, request.requestHeaders ?: emptyMap(), tab.currentUrl, tab.currentTitle, cookie)
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            // Ne jamais bloquer les sous-frames : les lecteurs iframe externes doivent charger
            if (!request.isForMainFrame) return false
            val url = request.url.toString()
            val scheme = request.url.scheme ?: ""
            if (scheme != "http" && scheme != "https") return true       // intent://, market://...
            if (AdBlock.isAdUrl(url)) return true
            val cur = tab.currentUrl
            if (cur.isEmpty() || cur == "about:blank") return false
            val now = SystemClock.elapsedRealtime()
            val allowed = AdBlock.sameRoot(cur, url) ||
                AdBlock.isSearchEngine(cur) ||
                now - tab.lastTypedAt < 5_000L ||
                now - tab.lastRealClickAt < 2_000L
            return !allowed
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (url == "about:blank") return
            tab.url = url
            tab.currentUrl = url
            tab.isLoading = true
            tab.progress = 0.05f
            tab.videos.clear()
            tab.sniffer.reset()
        }

        override fun onPageFinished(view: WebView, url: String) {
            if (url == "about:blank") return
            tab.isLoading = false
            tab.progress = 1f
            view.evaluateJavascript(AdBlock.INJECT_JS, null)
            if (url.startsWith("http")) AppPrefs.addHistory(url, view.title.orEmpty())
        }

        override fun onPageCommitVisible(view: WebView, url: String) {
            view.evaluateJavascript(AdBlock.INJECT_JS, null)
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            if (url != "about:blank" && tab.url.isNotEmpty()) { tab.url = url; tab.currentUrl = url }
        }
    }

    // ---------- WebChromeClient : popups bloquées + dialogues JS sécurisés ----------
    private class Chrome(private val tab: TabState) : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            tab.progress = newProgress / 100f
            tab.isLoading = newProgress < 100
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            tab.title = title.orEmpty()
            tab.currentTitle = title.orEmpty()
        }

        /** Neutralise 100 % des fenêtres publicitaires : on ne charge JAMAIS l'URL demandée. */
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean = false

        override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
            dialog(view, message, false, result)

        override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
            dialog(view, message, true, result)

        override fun onJsBeforeUnload(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
            dialog(view, message, true, result)

        private fun dialog(view: WebView, message: String?, cancellable: Boolean, result: JsResult): Boolean {
            val act = view.context.findActivity()
            if (act == null || act.isFinishing || act.isDestroyed) {
                // Repli silencieux
                if (cancellable) result.cancel() else result.confirm()
                return true
            }
            var handled = false
            fun once(block: () -> Unit) { if (!handled) { handled = true; block() } }
            try {
                val b = AlertDialog.Builder(act)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> once { result.confirm() } }
                    .setOnCancelListener { once { result.cancel() } }
                if (cancellable) b.setNegativeButton(android.R.string.cancel) { _, _ -> once { result.cancel() } }
                b.show()
            } catch (e: Exception) {
                once { result.cancel() }
            }
            return true
        }
    }
}
