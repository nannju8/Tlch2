package com.vidgrab.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.ui.components.AuroraBackground
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.components.GlassIconButton
import com.vidgrab.app.ui.theme.Aurora

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    AuroraBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Retour", onBack)
                Text("Paramètres", Modifier.padding(start = 14.dp), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
            }

            Box(Modifier.size(20.dp))
            GlassCard(Modifier.fillMaxWidth(), glow = Aurora.Cyan) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Wifi, null, tint = Aurora.Cyan, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text("Télécharger uniquement en Wi-Fi", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("Sécurité data : les téléchargements attendent une connexion Wi-Fi.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = AppPrefs.wifiOnly,
                        onCheckedChange = { AppPrefs.setWifiOnly(it); DownloadCenter.onNetworkTick() },
                        colors = SwitchDefaults.colors(checkedTrackColor = Aurora.Indigo)
                    )
                }
            }

            Box(Modifier.size(16.dp))
            GlassCard(Modifier.fillMaxWidth(), glow = Aurora.Indigo) {
                Column(Modifier.padding(18.dp)) {
                    Text("Thème", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "Sombre", 2 to "Clair", 0 to "Système").forEach { (mode, label) ->
                            FilterChip(selected = AppPrefs.themeMode == mode, onClick = { AppPrefs.setTheme(mode) }, label = { Text(label) })
                        }
                    }
                }
            }

            Box(Modifier.size(16.dp))
            GlassCard(Modifier.fillMaxWidth(), glow = Aurora.Coral, onClick = { AppPrefs.clearHistory() }) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.DeleteSweep, null, tint = Aurora.Coral)
                    Text("Effacer l'historique de navigation", Modifier.padding(start = 14.dp), color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                }
            }

            Text(
                "VidGrab 1.0.0 · com.vidgrab.app", Modifier.padding(top = 28.dp).fillMaxWidth(),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
