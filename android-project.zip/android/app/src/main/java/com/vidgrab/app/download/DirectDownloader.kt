package com.vidgrab.app.download

import android.content.Context
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * Téléchargement direct ultra-rapide : file dynamique de micro-blocs de 3 Mo consommée par
 * 8 workers parallèles (Range + écriture positionnelle FileChannel). Les workers piochent
 * toujours dans la file, donc le débit reste à 100 % jusqu'au dernier octet.
 * Bascule automatique en flux unique si le serveur ne supporte pas Range.
 */
object DirectDownloader {
    private const val BLOCK: Long = 3L * 1024L * 1024L
    private const val WORKERS = 8
    private const val BUF = 128 * 1024

    suspend fun download(ctx: Context, item: DownloadItem, rt: TaskRuntime): DownloadResult =
        withContext(Dispatchers.IO) {
            val v = item.video
            val ext = when (v.type) { "WEBM" -> "webm"; "MKV" -> "mkv"; else -> "mp4" }
            val mime = when (ext) { "webm" -> "video/webm"; "mkv" -> "video/x-matroska"; else -> "video/mp4" }
            val out = rt.tmpFile ?: File(ctx.cacheDir, "dl/${item.id}.part").also {
                it.parentFile?.mkdirs()
                rt.tmpFile = it
            }
            val info = rt.rangeInfo ?: probeRange(v, item.id).also { rt.rangeInfo = it }

            if (info.supportsRange && info.total > 0L) {
                ranged(out, v, item.id, info.total, rt)
            } else {
                single(out, v, item.id, info.total, rt)
            }
            DownloadResult(out, ext, mime)
        }

    private fun probeRange(v: DetectedVideo, id: String): RangeInfo {
        val req = Request.Builder().url(v.url).headers(Http.headersFor(v.headers)).header("Range", "bytes=0-0").build()
        val call = Http.newCall(id, req)
        try {
            call.execute().use { r ->
                if (r.code == 206) {
                    val total: Long = r.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
                    return RangeInfo(total > 0L, total)
                }
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val len: Long = r.body?.contentLength() ?: -1L
                return RangeInfo(false, len)
            }
        } finally {
            Http.release(id, call)
        }
    }

    private suspend fun ranged(out: File, v: DetectedVideo, id: String, total: Long, rt: TaskRuntime) {
        RandomAccessFile(out, "rw").use { raf ->
            if (raf.length() != total) raf.setLength(total)
            val ch = raf.channel
            val blocks: Int = ((total + BLOCK - 1L) / BLOCK).toInt()
            rt.total.set(total)
            val queue = Channel<Int>(Channel.UNLIMITED)
            for (i in 0 until blocks) if (!rt.doneBlocks.contains(i)) queue.trySend(i)
            queue.close()
            coroutineScope {
                repeat(WORKERS) {
                    launch(Dispatchers.IO) {
                        for (idx in queue) {
                            var tries = 0
                            while (true) {
                                try {
                                    fetchBlock(ch, v, id, idx, total, rt)
                                    break
                                } catch (e: IOException) {
                                    ensureActive()
                                    tries++
                                    if (tries >= 4) throw e
                                    delay(500L * tries.toLong())
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun fetchBlock(ch: FileChannel, v: DetectedVideo, id: String, idx: Int, total: Long, rt: TaskRuntime) {
        val start: Long = idx.toLong() * BLOCK
        val end: Long = minOf(total - 1L, start + BLOCK - 1L)
        val req = Request.Builder().url(v.url).headers(Http.headersFor(v.headers))
            .header("Range", "bytes=$start-$end").build()
        val call = Http.newCall(id, req)
        var got = 0L
        var ok = false
        try {
            call.execute().use { r ->
                if (r.code != 206) throw IOException("Range refusé (${r.code})")
                val body = r.body ?: throw IOException("Corps vide")
                val input = BufferedInputStream(body.byteStream(), BUF)
                val buf = ByteArray(BUF)
                var pos = start
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    val bb = ByteBuffer.wrap(buf, 0, n)
                    while (bb.hasRemaining()) pos += ch.write(bb, pos).toLong()
                    got += n.toLong()
                    rt.downloaded.addAndGet(n.toLong())
                }
                if (pos != end + 1L) throw IOException("Bloc incomplet")
            }
            ok = true
            rt.doneBlocks.add(idx)
        } finally {
            if (!ok) rt.downloaded.addAndGet(-got)
            Http.release(id, call)
        }
    }

    private suspend fun single(out: File, v: DetectedVideo, id: String, total: Long, rt: TaskRuntime) = coroutineScope {
        rt.doneBlocks.clear()
        rt.downloaded.set(0L)
        rt.total.set(if (total > 0L) total else 0L)
        val req = Request.Builder().url(v.url).headers(Http.headersFor(v.headers)).build()
        val call = Http.newCall(id, req)
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Corps vide")
                if (rt.total.get() <= 0L) rt.total.set(maxOf(body.contentLength(), 0L))
                val input = BufferedInputStream(body.byteStream(), BUF)
                FileOutputStream(out).use { fos ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        rt.downloaded.addAndGet(n.toLong())
                    }
                }
            }
        } finally {
            Http.release(id, call)
        }
    }
}
