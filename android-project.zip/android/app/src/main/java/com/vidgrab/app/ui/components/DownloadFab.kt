package com.vidgrab.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.ui.theme.Aurora

/**
 * FAB 3D de détection vidéo.
 * Inactif : sphère grise translucide. Actif : rotationY 360° (Spring MediumBouncy), dégradé corail/magenta,
 * onde radar concentrique pulsante et badge compteur en relief.
 */
@Composable
fun DownloadFab(count: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val active = count > 0
    val haptic = LocalHapticFeedback.current
    val rotY = remember { Animatable(0f) }

    LaunchedEffect(count) {
        if (count > 0) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            rotY.snapTo(0f)
            rotY.animateTo(360f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessVeryLow))
            rotY.snapTo(0f)
        }
    }

    val t = rememberInfiniteTransition(label = "fab")
    val w1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "w1")
    val w2 by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart, StartOffset(900)), label = "w2"
    )
    val pulse by t.animateFloat(1f, 1.07f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")

    Box(modifier.size(124.dp), contentAlignment = Alignment.Center) {
        if (active) {
            Canvas(Modifier.size(124.dp)) {
                val minR = 30.dp.toPx()
                val maxR = 62.dp.toPx()
                for (w in listOf(w1, w2)) {
                    val r = minR + (maxR - minR) * w
                    drawCircle(
                        brush = Brush.linearGradient(listOf(Aurora.Coral, Aurora.Magenta)),
                        radius = r, center = Offset(size.width / 2f, size.height / 2f),
                        style = Stroke(width = 3.dp.toPx()), alpha = (1f - w) * 0.6f
                    )
                }
            }
        }
        val glow = if (active) Aurora.Coral else Color.Black
        Box(
            Modifier
                .size(62.dp)
                .graphicsLayer {
                    rotationY = rotY.value
                    cameraDistance = 16f * density
                    val s = if (active) pulse else 1f
                    scaleX = s
                    scaleY = s
                }
                .shadow(if (active) 18.dp else 8.dp, CircleShape, ambientColor = glow, spotColor = glow)
                .clip(CircleShape)
                .background(
                    if (active) Aurora.alertBrush
                    else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.White.copy(alpha = 0.06f)))
                )
                .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent)), CircleShape)
                .clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Download, "Télécharger", tint = Color.White, modifier = Modifier.size(30.dp))
        }
        if (active) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-18).dp, y = 18.dp)
                    .size(24.dp)
                    .shadow(8.dp, CircleShape, ambientColor = Aurora.Magenta, spotColor = Aurora.Magenta)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFFFE4EC))))
                    .border(1.dp, Aurora.Coral.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(count.toString(), color = Aurora.Coral, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            }
        }
    }
}
