package com.vidgrab.app.ui.library

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.theme.Aurora
import kotlinx.coroutines.launch

enum class PinMode { Enter, Create }

/** Pavé numérique tactile moderne ; PIN stocké en SHA-256 salé (AppPrefs). */
@Composable
fun PinDialog(mode: PinMode, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var entered by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    val shake = remember { Animatable(0f) }

    val title = when {
        mode == PinMode.Enter -> "Entrez votre code PIN"
        first == null -> "Créez un code PIN"
        else -> "Confirmez le code PIN"
    }

    fun fail() {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        entered = ""
        scope.launch {
            for (v in listOf(-18f, 18f, -12f, 12f, -6f, 0f)) shake.animateTo(v, tween(50))
        }
    }

    fun submit(pin: String) {
        if (mode == PinMode.Enter) {
            if (AppPrefs.verifyPin(pin)) onSuccess() else fail()
        } else {
            val f = first
            if (f == null) { first = pin; entered = "" }
            else if (f == pin) { AppPrefs.setPin(pin); onSuccess() }
            else { first = null; fail() }
        }
    }

    fun press(d: String) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (entered.length < 4) {
            entered += d
            if (entered.length == 4) submit(entered)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(Modifier.fillMaxWidth(), glow = Aurora.Magenta) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Row(
                    Modifier.padding(vertical = 22.dp).graphicsLayer { translationX = shake.value * density },
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    repeat(4) { i ->
                        Box(
                            Modifier.size(14.dp).clip(CircleShape)
                                .background(if (i < entered.length) Aurora.Cyan else Color.Gray.copy(alpha = 0.35f))
                        )
                    }
                }
                val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
                rows.forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        r.forEach { d -> Key(d) { press(d) } }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    Box(Modifier.size(64.dp))
                    Key("0") { press("0") }
                    Box(
                        Modifier.size(64.dp).clip(CircleShape).clickable { if (entered.isNotEmpty()) entered = entered.dropLast(1) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Rounded.Backspace, "Effacer", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}

@Composable
private fun Key(label: String, onClick: () -> Unit) {
    GlassCard(Modifier.size(64.dp), shape = CircleShape, glow = Aurora.Indigo, tilt = true, onClick = onClick) {
        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            Text(label, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
