package com.vidgrab.app.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.vidgrab.app.browser.AdBlock
import java.util.Locale

fun fmtBytes(b: Long): String {
    if (b <= 0L) return "—"
    val mo: Double = b.toDouble() / 1_048_576.0
    return if (mo >= 1024.0) String.format(Locale.FRANCE, "%.2f Go", mo / 1024.0)
    else String.format(Locale.FRANCE, "%.1f Mo", mo)
}

fun fmtSpeed(bps: Long): String {
    val mo: Double = bps.toDouble() / 1_048_576.0
    return String.format(Locale.FRANCE, "%.1f Mo/s", mo)
}

fun fmtEta(sec: Long): String {
    if (sec < 0L) return "—"
    val h = sec / 3600L
    val m = (sec % 3600L) / 60L
    val s = sec % 60L
    return when {
        h > 0L -> String.format(Locale.FRANCE, "%dh %02dmin", h, m)
        m > 0L -> String.format(Locale.FRANCE, "%dmin %02ds", m, s)
        else -> "${s}s"
    }
}

fun fmtDuration(ms: Long): String {
    val total = ms / 1000L
    val h = total / 3600L
    val m = (total % 3600L) / 60L
    val s = total % 60L
    return if (h > 0L) String.format(Locale.FRANCE, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.FRANCE, "%02d:%02d", m, s)
}

fun hostLabel(url: String): String = AdBlock.hostOf(url).removePrefix("www.").ifEmpty { url }

private val palette = listOf(
    listOf(Color(0xFF6366F1), Color(0xFF8B5CF6)),
    listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)),
    listOf(Color(0xFFF43F5E), Color(0xFFF97316)),
    listOf(Color(0xFF10B981), Color(0xFF06B6D4)),
    listOf(Color(0xFFEC4899), Color(0xFF8B5CF6)),
    listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
)

fun brushFor(key: String): Brush {
    val c = palette[(key.hashCode() and 0x7fffffff) % palette.size]
    return Brush.linearGradient(c)
}

fun glowFor(key: String): Color = palette[(key.hashCode() and 0x7fffffff) % palette.size][0]

fun initialOf(title: String, url: String): String {
    val t = hostLabel(url).ifEmpty { title }
    return t.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "•"
}
