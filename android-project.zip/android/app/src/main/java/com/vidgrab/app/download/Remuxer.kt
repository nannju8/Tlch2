package com.vidgrab.app.download

import android.content.Context
import android.net.Uri
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Remux .ts → .mp4 sans ré-encodage via Media3 Transformer. */
object Remuxer {

    @androidx.annotation.OptIn(UnstableApi::class)
    suspend fun tsToMp4(ctx: Context, input: File, output: File): Boolean {
        val done = CompletableDeferred<Boolean>()
        var transformer: Transformer? = null
        // Looper principal obligatoire : start() sur Dispatchers.IO sans Looper provoque un crash.
        withContext(Dispatchers.Main) {
            try {
                val t = Transformer.Builder(ctx.applicationContext)
                    .setLooper(Looper.getMainLooper())
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            done.complete(true)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            done.complete(false)
                        }
                    })
                    .build()
                transformer = t
                t.start(MediaItem.fromUri(Uri.fromFile(input)), output.absolutePath)
            } catch (e: Exception) {
                done.complete(false)
            }
        }
        return try {
            withTimeoutOrNull(30L * 60L * 1000L) { done.await() } ?: false
        } finally {
            if (!done.isCompleted) {
                withContext(Dispatchers.Main) { try { transformer?.cancel() } catch (_: Exception) { } }
            }
        }
    }
}
