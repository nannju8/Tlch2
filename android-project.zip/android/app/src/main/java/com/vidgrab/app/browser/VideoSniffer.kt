package com.vidgrab.app.browser

import android.net.Uri
import android.webkit.CookieManager
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.net.HlsParser
import com.vidgrab.app.net.Http
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Détecteur de flux vidéo. Appelé depuis le thread IO de la WebView (shouldInterceptRequest) :
 * il n'accède donc JAMAIS à l'état Compose, uniquement à des valeurs @Volatile / thread-safe.
 */
class VideoSniffer(private val onFound: (DetectedVideo) -> Unit) {

    @Volatile var userAgent: String = DEFAULT_UA

    private val seen: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val probes = AtomicInteger(0)
    private val gate = Semaphore(4)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class Probe(val kind: String, val total: Long)

    fun reset() { seen.clear(); probes.set(0) }
    fun close() { scope.cancel() }

    /** Requête réseau de la WebView, avec en-têtes exacts (Referer de l'iframe, Origin, UA, Cookie). */
    fun onRequest(url: String, reqHeaders: Map<String, String>, pageUrl: String, pageTitle: String, cookie: String?) {
        if (isExcluded(url, pageUrl) || looksLikeSegment(url)) return
        val accept = reqHeaders["Accept"] ?: ""
        if (accept.startsWith("text/html")) return
        val ext = extOf(url)
        if (ext in SKIP_EXT) return
        val candidate = ext in VIDEO_EXT || ext in DISGUISE_EXT || ext.isEmpty()
        if (!candidate) return
        val headers = HashMap<String, String>(reqHeaders)
        if (!cookie.isNullOrBlank()) headers["Cookie"] = cookie
        submit(url, headers, pageUrl, pageTitle)
    }

    /** Filet de sécurité JS : video.currentSrc remonté par @JavascriptInterface. */
    fun onJsVideo(src: String, pageUrl: String, pageTitle: String) {
        if (isExcluded(src, pageUrl) || looksLikeSegment(src)) return
        val headers = HashMap<String, String>()
        headers["User-Agent"] = userAgent
        if (pageUrl.isNotEmpty()) {
            headers["Referer"] = pageUrl
            val u = Uri.parse(pageUrl)
            if (u.scheme != null && u.host != null) headers["Origin"] = u.scheme + "://" + u.host
        }
        val cookie = try { CookieManager.getInstance().getCookie(src) } catch (e: Exception) { null }
        if (!cookie.isNullOrBlank()) headers["Cookie"] = cookie
        submit(src, headers, pageUrl, pageTitle)
    }

    private fun submit(url: String, headers: Map<String, String>, pageUrl: String, pageTitle: String) {
        if (!url.startsWith("http")) return
        if (probes.get() > 80) return
        if (!seen.add(url)) return
        probes.incrementAndGet()
        scope.launch {
            gate.withPermit {
                try { probeAndEmit(url, headers, pageUrl, pageTitle) } catch (_: Exception) { }
            }
        }
    }

    private fun probeAndEmit(url: String, headers: Map<String, String>, pageUrl: String, pageTitle: String) {
        val probe = probe(url, headers) ?: return
        val title = cleanTitle(pageTitle, url)
        if (probe.kind == "HLS") {
            val text = HlsParser.load(url, headers, null) ?: return
            if (text.contains("#EXT-X-STREAM-INF")) {
                val variants = HlsParser.parseMaster(text, url).take(4)
                for (v in variants) {
                    seen.add(v.url)
                    val size = HlsParser.estimateSize(v.url, v.bandwidth, headers)
                    val q = if (v.height > 0) "${v.height}p" else "Auto"
                    onFound(DetectedVideo(v.url, title, "HLS", q, size, headers, pageUrl))
                }
            } else {
                val size = HlsParser.estimateSize(url, 0L, headers)
                onFound(DetectedVideo(url, title, "HLS", qualityFromUrl(url), size, headers, pageUrl))
            }
        } else {
            onFound(DetectedVideo(url, title, probe.kind, qualityFromUrl(url), probe.total, headers, pageUrl))
        }
    }

    /**
     * Sonde sécurisée (anti-OOM) : Range 0-1023, lecture de 512 octets max, Response fermée immédiatement.
     * 400/416/501 → retente sans Range. 401/403 avec Origin → retente avec Origin + Referer + Cookie.
     */
    private fun probe(url: String, hdrs: Map<String, String>): Probe? {
        var useRange = true
        var full = false
        var attempts = 0
        val hasOrigin = hdrs.keys.any { it.equals("origin", ignoreCase = true) }
        while (attempts < 4) {
            attempts++
            val rb = Request.Builder().url(url)
            if (full) {
                rb.headers(Http.headersFor(hdrs))
            } else {
                rb.header("User-Agent", userAgent)
                hdrs["Referer"]?.let { rb.header("Referer", it) }
            }
            if (useRange) rb.header("Range", "bytes=0-1023")
            val resp = try { Http.client.newCall(rb.build()).execute() } catch (e: IOException) { return null }
            resp.use { r ->
                val code = r.code
                if ((code == 400 || code == 416 || code == 501) && useRange) { useRange = false; return@use }
                if ((code == 401 || code == 403) && hasOrigin && !full) { full = true; return@use }
                if (code !in 200..299) return null
                val body = r.body ?: return null
                val buf = ByteArray(512)
                var n = 0
                val stream = body.byteStream()
                while (n < buf.size) {
                    val read = stream.read(buf, n, buf.size - n)
                    if (read < 0) break
                    n += read
                }
                val ct = r.header("Content-Type").orEmpty().lowercase()
                val cr = r.header("Content-Range")
                val total: Long = if (cr != null) {
                    cr.substringAfterLast('/').trim().toLongOrNull() ?: -1L
                } else if (code == 200) {
                    body.contentLength()
                } else -1L
                return classify(url, buf, n, ct, total)
            }
        }
        return null
    }

    private fun classify(url: String, buf: ByteArray, n: Int, ct: String, total: Long): Probe? {
        // Segment MPEG-TS déguisé (octets 0 et 188 = 0x47) → rejeté
        if (n > 188 && buf[0] == 0x47.toByte() && buf[188] == 0x47.toByte()) return null
        if (ct.contains("mp2t")) return null
        val head = String(buf, 0, minOf(n, 16), Charsets.ISO_8859_1)
        val kind: String? = when {
            head.startsWith("#EXTM3U") -> "HLS"
            n >= 8 && String(buf, 4, 4, Charsets.ISO_8859_1) == "ftyp" -> "MP4"
            n >= 4 && buf[0] == 0x1A.toByte() && buf[1] == 0x45.toByte() &&
                buf[2] == 0xDF.toByte() && buf[3] == 0xA3.toByte() ->
                if (ct.contains("webm") || extOf(url) == "webm") "WEBM" else "MKV"
            ct.startsWith("video/") && !ct.contains("mpegurl") -> "MP4"
            else -> null
        }
        if (kind == null) return null
        if (kind != "HLS" && total in 0L..299_999L) return null
        return Probe(kind, total)
    }

    companion object {
        const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36"

        private val EXCLUDED = listOf("youtube.com", "googlevideo.com", "youtu.be", "youtube-nocookie.com")
        private val VIDEO_EXT = setOf("m3u8", "mp4", "mkv", "webm", "mov", "m4v", "txt", "php")
        private val DISGUISE_EXT = setOf("png", "jpg", "jpeg", "js", "json", "dat", "bin", "html", "htm", "css", "gif", "webp")
        private val SKIP_EXT = setOf("ts", "m4s", "woff", "woff2", "ttf", "otf", "ico", "svg", "mpd", "vtt", "srt", "mp3", "aac")

        fun isExcluded(url: String, pageUrl: String): Boolean {
            val h = AdBlock.hostOf(url)
            val p = AdBlock.hostOf(pageUrl)
            return EXCLUDED.any { h == it || h.endsWith(".$it") || p == it || p.endsWith(".$it") }
        }

        fun looksLikeSegment(url: String): Boolean {
            val l = url.lowercase()
            return l.contains("/seg") || l.contains("seg-") || l.contains("segment") ||
                l.contains("chunk-") || l.contains(".m4s") || l.contains("init.")
        }

        /** Extension uniquement depuis le dernier segment du chemin (ex: /v1.2/stream/master → ""). */
        fun extOf(url: String): String {
            val path = try { Uri.parse(url).path.orEmpty() } catch (e: Exception) { "" }
            val last = path.substringAfterLast('/', "")
            return last.substringAfterLast('.', "").lowercase()
        }

        private val reQ = Regex("(2160|1440|1080|720|480|360|240)p?")

        fun qualityFromUrl(url: String): String {
            val m = reQ.find(url.substringAfterLast('/'))
            return if (m != null) m.groupValues[1] + "p" else "Auto"
        }

        fun cleanTitle(pageTitle: String, url: String): String {
            val t = pageTitle.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), " ").replace(Regex("\\s+"), " ").trim()
            return if (t.isNotEmpty()) t.take(90) else AdBlock.hostOf(url).ifEmpty { "video" }
        }
    }
}
