package com.vidgrab.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat
import com.vidgrab.app.browser.TabManager
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.ui.MainScreen
import com.vidgrab.app.ui.theme.VidGrabTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        TabManager.attachActivity(this)
        requestNotificationPermission()
        DownloadCenter.kick()
        setContent {
            VidGrabTheme { MainScreen() }
        }
    }

    override fun onResume() {
        super.onResume()
        TabManager.attachActivity(this)
    }

    override fun onDestroy() {
        TabManager.detachActivity(this)
        super.onDestroy()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
