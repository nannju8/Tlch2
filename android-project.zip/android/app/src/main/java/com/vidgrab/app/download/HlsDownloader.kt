package com.vidgrab.app.download

import android.content.Context
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.net.HlsParser
import com.vidgrab.app.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * HLS : choix de la meilleure qualité, segments en parallèle (tampon 128 Ko — jamais 512 octets),
 * déchiffrement AES-128, fusion puis remux sans ré-encodage vers .mp4 (repli propre en .ts).
 */
object HlsDownloader {
    private const val WORKERS = 8
    private const val BUF = 128 * 1024

    suspend fun download(ctx: Context, item: DownloadItem, rt: TaskRuntime, onMerging: () -> Unit): DownloadResult =
        withContext(Dispatchers.IO) {
            val v = item.video
            var playlistUrl = v.url
            var text = HlsParser.load(playlistUrl, v.headers, item.id) ?: throw IOException("Playlist inaccessible")
            if (text.contains("#EXT-X-STREAM-INF")) {
                val best = HlsParser.parseMaster(text, playlistUrl).firstOrNull() ?: throw IOException("Aucune qualité")
                playlistUrl = best.url
                text = HlsParser.load(playlistUrl, v.headers, item.id) ?: throw IOException("Playlist inaccessible")
            }
            val media = HlsParser.parseMedia(text, playlistUrl)
            if (media.segments.isEmpty()) throw IOException("Playlist vide")

            val dir = File(ctx.cacheDir, "dl/${item.id}").apply { mkdirs() }
            val n = media.segments.size
            val keyCache = ConcurrentHashMap<String, ByteArray>()

            val initFile: File? = media.initUri?.let { u ->
                val f = File(dir, "init.bin")
                if (!f.exists()) fetch(u, v.headers, item.id, f, null, null, rt)
                f
            }

            val queue = Channel<Int>(Channel.UNLIMITED)
            for (i in 0 until n) if (!rt.doneBlocks.contains(i)) queue.trySend(i)
            queue.close()

            coroutineScope {
                repeat(WORKERS) {
                    launch(Dispatchers.IO) {
                        for (i in queue) {
                            var tries = 0
                            while (true) {
                                try {
                                    val seg = media.segments[i]
                                    var key: ByteArray? = null
                                    var iv: ByteArray? = null
                                    val k = seg.key
                                    if (k != null) {
                                        key = keyCache.getOrPut(k.uri) { loadBytes(k.uri, v.headers, item.id) }
                                        iv = k.iv ?: HlsParser.seqIv(seg.seq)
                                    }
                                    val target = File(dir, "seg_$i")
                                    val tmp = File(dir, "seg_$i.tmp")
                                    fetch(seg.url, v.headers, item.id, tmp, key, iv, rt)
                                    tmp.renameTo(target)
                                    rt.doneBlocks.add(i)
                                    val d: Long = rt.doneBlocks.size.toLong()
                                    rt.total.set((rt.downloaded.get() / d) * n.toLong())
                                    break
                                } catch (e: IOException) {
                                    ensureActive()
                                    tries++
                                    if (tries >= 4) throw e
                                    delay(400L * tries.toLong())
                                }
                            }
                        }
                    }
                }
            }
            rt.total.set(rt.downloaded.get())

            // Fusion des segments dans l'ordre
            onMerging()
            val merged = File(dir, "merged.bin")
            FileOutputStream(merged).use { out ->
                val buf = ByteArray(BUF)
                val parts = ArrayList<File>()
                if (initFile != null) parts.add(initFile)
                for (i in 0 until n) parts.add(File(dir, "seg_$i"))
                for (p in parts) {
                    p.inputStream().use { input ->
                        while (true) {
                            val r = input.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                        }
                    }
                }
            }
            for (i in 0 until n) File(dir, "seg_$i").delete()

            val fmp4 = media.initUri != null || media.segments[0].url.substringBefore('?').let {
                it.endsWith(".m4s") || it.endsWith(".mp4")
            }
            if (fmp4) {
                val mp4 = File(dir, "out.mp4")
                merged.renameTo(mp4)
                DownloadResult(mp4, "mp4", "video/mp4")
            } else {
                val mp4 = File(dir, "out.mp4")
                val ok = Remuxer.tsToMp4(ctx, merged, mp4)
                if (ok && mp4.exists() && mp4.length() > 0L) {
                    merged.delete()
                    DownloadResult(mp4, "mp4", "video/mp4")
                } else {
                    mp4.delete()
                    val ts = File(dir, "out.ts")
                    merged.renameTo(ts)
                    DownloadResult(ts, "ts", "video/mp2t")
                }
            }
        }

    private fun loadBytes(url: String, headers: Map<String, String>, id: String): ByteArray {
        val call = Http.newCall(id, Request.Builder().url(url).headers(Http.headersFor(headers)).build())
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("Clé HTTP ${r.code}")
                return r.body?.bytes() ?: throw IOException("Clé vide")
            }
        } finally {
            Http.release(id, call)
        }
    }

    private fun fetch(
        url: String, headers: Map<String, String>, id: String, out: File,
        key: ByteArray?, iv: ByteArray?, rt: TaskRuntime
    ) {
        val call = Http.newCall(id, Request.Builder().url(url).headers(Http.headersFor(headers)).build())
        var got = 0L
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Corps vide")
                var input: InputStream = BufferedInputStream(body.byteStream(), BUF)
                if (key != null && iv != null) {
                    val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
                    c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
                    input = CipherInputStream(input, c)
                }
                FileOutputStream(out).use { fos ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        got += n.toLong()
                        rt.downloaded.addAndGet(n.toLong())
                    }
                }
            }
        } catch (e: Exception) {
            rt.downloaded.addAndGet(-got)
            if (e is IOException) throw e
            throw IOException(e.message, e)
        } finally {
            Http.release(id, call)
        }
    }
}
