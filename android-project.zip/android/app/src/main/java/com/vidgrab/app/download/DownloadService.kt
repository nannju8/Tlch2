package com.vidgrab.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vidgrab.app.MainActivity
import com.vidgrab.app.data.DlState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/** ForegroundService dataSync + PARTIAL_WAKE_LOCK + WifiLock HIGH_PERF + notification temps réel. */
class DownloadService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        acquireLocks()
        if (job == null) {
            job = scope.launch {
                launch {
                    DownloadCenter.items.collect {
                        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
                        if (!DownloadCenter.needsService()) stopSelf()
                    }
                }
                launch {
                    while (isActive) {
                        delay(5_000L)
                        acquireLocks()              // vérifie le maintien des verrous dans la boucle active
                        DownloadCenter.onNetworkTick()
                    }
                }
            }
        }
        return START_STICKY
    }

    /** Android 15 : limite de 6 h pour dataSync → pause propre puis arrêt. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        DownloadCenter.pauseAll()
        stopSelf()
    }

    override fun onTimeout(startId: Int) {
        DownloadCenter.pauseAll()
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wake?.isHeld != true) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vidgrab:download").apply {
                setReferenceCounted(false)
                acquire(6L * 60L * 60L * 1000L)
            }
        }
        if (wifi?.isHeld != true) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            // HIGH_PERF (et non LOW_LATENCY, inactif écran éteint)
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "vidgrab:wifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun buildNotification(): Notification {
        val list = DownloadCenter.items.value
        val running = list.filter { it.state == DlState.Running }
        val speed: Long = running.fold(0L) { a, i -> a + i.speedBps }
        val total: Long = list.fold(0L) { a, i -> a + i.total }
        val done: Long = list.fold(0L) { a, i -> a + i.downloaded }
        val pct: Int = if (total > 0L) ((done * 100L) / total).toInt().coerceIn(0, 100) else 0
        val text = when {
            list.any { it.waitingWifi } -> "En attente du Wi-Fi…"
            running.isEmpty() -> "En file d'attente…"
            else -> String.format(Locale.FRANCE, "%.1f Mo/s · %d %%", speed / 1_048_576.0, pct)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("VidGrab · ${list.size} téléchargement(s)")
            .setContentText(text)
            .setProgress(100, pct, total <= 0L)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        job = null
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) { }
        try { if (wifi?.isHeld == true) wifi?.release() } catch (_: Exception) { }
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "vidgrab_downloads"
        const val NOTIF_ID = 4242

        fun createChannel(ctx: Context) {
            val ch = NotificationChannel(CHANNEL, "Téléchargements", NotificationManager.IMPORTANCE_LOW)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (_: Exception) {
                // Démarrage interdit en arrière-plan (Android 12+) : le Worker retentera.
            }
        }
    }
}
