package com.vidgrab.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Downloading
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.ui.browser.BrowserScreen
import com.vidgrab.app.ui.browser.TabSwitcher
import com.vidgrab.app.ui.components.AuroraBackground
import com.vidgrab.app.ui.components.glassBorder
import com.vidgrab.app.ui.library.LibraryScreen
import com.vidgrab.app.ui.progress.ProgressScreen
import com.vidgrab.app.ui.settings.SettingsScreen
import com.vidgrab.app.ui.theme.Aurora

@Composable
fun MainScreen() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showTabs by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val items by DownloadCenter.items.collectAsState()

    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = showTabs) { showTabs = false }

    AuroraBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (!showTabs) FloatingGlassNavBar(selected = tab, badge = items.size, onSelect = { tab = it })
            }
        ) { inner ->
            val bottom: Dp = inner.calculateBottomPadding()
            Box(Modifier.fillMaxSize()) {
                Crossfade(targetState = tab, label = "screens") { t ->
                    when (t) {
                        0 -> BrowserScreen(bottom, onOpenSettings = { showSettings = true }, onOpenTabs = { showTabs = true })
                        1 -> ProgressScreen(bottom)
                        else -> LibraryScreen(bottom)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showTabs,
            enter = fadeIn() + scaleIn(initialScale = 0.9f),
            exit = fadeOut() + scaleOut(targetScale = 0.9f)
        ) {
            TabSwitcher(onClose = { showTabs = false }, onSelected = { tab = 0; showTabs = false })
        }

        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsScreen(onBack = { showSettings = false })
        }
    }
}

/** Barre de navigation flottante en verre dépoli : coins 28 dp, détachée des bords, 3 onglets. */
@Composable
fun FloatingGlassNavBar(selected: Int, badge: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(22.dp, shape, ambientColor = Color.Black, spotColor = Aurora.Indigo.copy(alpha = 0.55f))
                .clip(shape)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.78f))
                .glassBorder(shape)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            NavItem(Icons.Rounded.Language, "Onglet", selected == 0, 0, Modifier.weight(1f)) { onSelect(0) }
            NavItem(Icons.Rounded.Downloading, "Progression", selected == 1, badge, Modifier.weight(1f)) { onSelect(1) }
            NavItem(Icons.Rounded.VideoLibrary, "Terminé", selected == 2, 0, Modifier.weight(1f)) { onSelect(2) }
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, badge: Int, modifier: Modifier, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val lift by animateDpAsState(if (selected) (-5).dp else 0.dp, spring(Spring.DampingRatioMediumBouncy), label = "lift")
    val halo by animateFloatAsState(if (selected) 1f else 0f, label = "halo")
    val scale by animateFloatAsState(if (badge > 0) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "badge")
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.offset(y = lift), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(52.dp).graphicsLayer { alpha = halo }
                    .background(Brush.radialGradient(listOf(Aurora.Indigo.copy(alpha = 0.55f), Color.Transparent)), CircleShape)
            )
            Box(
                Modifier.size(42.dp).clip(CircleShape)
                    .background(if (selected) Aurora.navBrush else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, label, tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp))
            }
            Box(
                Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-2).dp).size(18.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(CircleShape).background(Aurora.alertBrush),
                contentAlignment = Alignment.Center
            ) { Text(badge.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
        }
        Text(
            label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
