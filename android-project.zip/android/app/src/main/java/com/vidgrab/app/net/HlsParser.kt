package com.vidgrab.app.net

import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.net.URL

/** Parseur HLS natif : playlists maîtres (qualités), playlists média, chiffrement AES-128. */
object HlsParser {
    data class Variant(val url: String, val bandwidth: Long, val height: Int)
    class KeyInfo(val uri: String, val iv: ByteArray?)
    data class Segment(val url: String, val seq: Long, val key: KeyInfo?)
    data class Media(val segments: List<Segment>, val duration: Double, val initUri: String?)

    private val reBandwidth = Regex("BANDWIDTH=(\\d+)")
    private val reRes = Regex("RESOLUTION=(\\d+)x(\\d+)")
    private val reUri = Regex("URI=\"([^\"]+)\"")
    private val reIv = Regex("IV=0[xX]([0-9a-fA-F]+)")

    fun resolve(base: String, ref: String): String =
        try { URL(URL(base), ref).toString() } catch (e: Exception) { ref }

    /** Lit une playlist (max 2 Mo) — annulable si taskId fourni. */
    fun load(url: String, headers: Map<String, String>, taskId: String?): String? {
        return try {
            val req = Request.Builder().url(url).headers(Http.headersFor(headers)).build()
            val call = Http.newCall(taskId, req)
            try {
                call.execute().use { r ->
                    if (!r.isSuccessful) return null
                    val body = r.body ?: return null
                    val bos = ByteArrayOutputStream()
                    val buf = ByteArray(16 * 1024)
                    val input = body.byteStream()
                    var total = 0
                    while (total < 2_000_000) {
                        val n = input.read(buf)
                        if (n < 0) break
                        bos.write(buf, 0, n)
                        total += n
                    }
                    bos.toString("UTF-8")
                }
            } finally {
                Http.release(taskId, call)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun parseMaster(text: String, base: String): List<Variant> {
        val lines = text.lines()
        val out = ArrayList<Variant>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i].trim()
            if (l.startsWith("#EXT-X-STREAM-INF")) {
                val bw: Long = reBandwidth.find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                val h: Int = reRes.find(l)?.groupValues?.get(2)?.toIntOrNull() ?: 0
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                if (j < lines.size) out.add(Variant(resolve(base, lines[j].trim()), bw, h))
                i = j
            }
            i++
        }
        return out.sortedWith(compareByDescending<Variant> { it.height }.thenByDescending { it.bandwidth })
    }

    fun parseMedia(text: String, base: String): Media {
        var seq = 0L
        var key: KeyInfo? = null
        var initUri: String? = null
        var dur = 0.0
        var pendingDur = 0.0
        val segs = ArrayList<Segment>()
        for (raw in text.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-KEY:") -> {
                    key = if (l.contains("METHOD=AES-128")) {
                        val uri = reUri.find(l)?.groupValues?.get(1)
                        if (uri == null) null else KeyInfo(resolve(base, uri), parseIv(reIv.find(l)?.groupValues?.get(1)))
                    } else null
                }
                l.startsWith("#EXT-X-MAP:") -> reUri.find(l)?.groupValues?.get(1)?.let { initUri = resolve(base, it) }
                l.startsWith("#EXTINF:") -> pendingDur = l.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: 0.0
                l.isNotEmpty() && !l.startsWith("#") -> {
                    segs.add(Segment(resolve(base, l), seq, key))
                    seq++
                    dur += pendingDur
                    pendingDur = 0.0
                }
            }
        }
        return Media(segs, dur, initUri)
    }

    private fun parseIv(hex: String?): ByteArray? {
        if (hex == null) return null
        val padded = hex.padStart(32, '0').takeLast(32)
        return ByteArray(16) { i -> padded.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    fun seqIv(seq: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0 until 8) iv[15 - i] = ((seq shr (8 * i)) and 0xFF).toByte()
        return iv
    }

    /** Estime la taille : bande passante × durée, sinon HEAD sur le premier segment × nombre. */
    fun estimateSize(mediaUrl: String, bandwidth: Long, headers: Map<String, String>): Long {
        val text = load(mediaUrl, headers, null) ?: return -1L
        val media = parseMedia(text, mediaUrl)
        if (media.segments.isEmpty()) return -1L
        if (bandwidth > 0L && media.duration > 0.0) {
            val bytes: Double = bandwidth.toDouble() * media.duration / 8.0
            return bytes.toLong()
        }
        return try {
            val req = Request.Builder().url(media.segments[0].url).head().headers(Http.headersFor(headers)).build()
            Http.client.newCall(req).execute().use { r ->
                val len: Long = r.header("Content-Length")?.toLongOrNull() ?: -1L
                if (len > 0L) len * media.segments.size.toLong() else -1L
            }
        } catch (e: Exception) {
            -1L
        }
    }
}
