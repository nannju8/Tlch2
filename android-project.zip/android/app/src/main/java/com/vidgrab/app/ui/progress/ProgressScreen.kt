package com.vidgrab.app.ui.progress

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Downloading
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.data.DlState
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.ui.components.Badge
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.components.staggerIn
import com.vidgrab.app.ui.fmtBytes
import com.vidgrab.app.ui.fmtEta
import com.vidgrab.app.ui.fmtSpeed
import com.vidgrab.app.ui.theme.Aurora

@Composable
fun ProgressScreen(bottomPad: Dp) {
    val items by DownloadCenter.items.collectAsState()
    val speed: Long = items.filter { it.state == DlState.Running }.fold(0L) { a, i -> a + i.speedBps }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PROGRESSION", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
            Row(
                Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)).padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Speed, null, tint = Aurora.Cyan, modifier = Modifier.size(18.dp))
                Text("  " + fmtSpeed(speed), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            }
        }
        if (items.isEmpty()) {
            EmptyState(Modifier.weight(1f).fillMaxWidth())
        } else {
            LazyColumn(
                Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(items, key = { _, it -> it.id }) { idx, item ->
                    Box(Modifier.staggerIn(idx)) { DownloadCard(item) }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "float")
    val y by t.animateFloat(-12f, 12f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
    val tilt by t.animateFloat(-6f, 6f, infiniteRepeatable(tween(3400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "tilt")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(180.dp).graphicsLayer { translationY = y * density; rotationY = tilt; rotationX = -tilt / 2f; cameraDistance = 16f * density }) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                // Ombre portée
                drawOval(Color.Black.copy(alpha = 0.25f), topLeft = Offset(w * 0.2f, h * 0.9f), size = Size(w * 0.6f, h * 0.07f))
                // Carte en relief
                drawRoundRect(
                    Brush.linearGradient(listOf(Aurora.Indigo, Aurora.Cyan)),
                    topLeft = Offset(w * 0.12f, h * 0.12f), size = Size(w * 0.76f, h * 0.7f), cornerRadius = CornerRadius(w * 0.18f)
                )
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent)),
                    topLeft = Offset(w * 0.12f, h * 0.12f), size = Size(w * 0.76f, h * 0.3f), cornerRadius = CornerRadius(w * 0.18f)
                )
                // Flèche de téléchargement
                val p = Path().apply {
                    moveTo(w * 0.44f, h * 0.26f); lineTo(w * 0.56f, h * 0.26f); lineTo(w * 0.56f, h * 0.43f)
                    lineTo(w * 0.65f, h * 0.43f); lineTo(w * 0.5f, h * 0.6f); lineTo(w * 0.35f, h * 0.43f)
                    lineTo(w * 0.44f, h * 0.43f); close()
                }
                drawPath(p, Color.White)
                drawRoundRect(Color.White, topLeft = Offset(w * 0.32f, h * 0.65f), size = Size(w * 0.36f, h * 0.045f), cornerRadius = CornerRadius(20f))
            }
        }
        Text("Aucun téléchargement en cours", Modifier.padding(top = 24.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DownloadCard(item: DownloadItem) {
    val haptic = LocalHapticFeedback.current
    val running = item.state == DlState.Running
    val t = rememberInfiniteTransition(label = "icon")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "spin")
    val status = when {
        item.waitingWifi -> "En attente du Wi-Fi"
        item.state == DlState.Queued -> "En file d'attente"
        item.state == DlState.Paused -> "En pause"
        item.state == DlState.Merging -> "Finalisation…"
        item.state == DlState.Failed -> item.error ?: "Échec"
        else -> fmtSpeed(item.speedBps)
    }
    GlassCard(Modifier.fillMaxWidth(), glow = if (item.state == DlState.Failed) Aurora.Coral else Aurora.Indigo) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).shadow(8.dp, CircleShape, ambientColor = Aurora.Cyan, spotColor = Aurora.Indigo).clip(CircleShape).background(Aurora.navBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Downloading, null, tint = Color.White, modifier = Modifier.size(26.dp).graphicsLayer { rotationY = if (running) spin else 0f; cameraDistance = 16f * density })
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(item.video.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Badge(item.video.type, Aurora.Cyan)
                        Badge(item.video.quality, Aurora.Magenta)
                    }
                }
            }
            Box(Modifier.height(14.dp))
            ShimmerBar(item.progress, running)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(status, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (item.state == DlState.Failed) Aurora.Coral else Aurora.Cyan, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        fmtBytes(item.downloaded) + " / " + fmtBytes(item.total) + (if (running) "  ·  " + fmtEta(item.etaSec) else ""),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                val canPause = item.state == DlState.Running || item.state == DlState.Queued
                RoundAction(if (canPause) Icons.Rounded.Pause else if (item.state == DlState.Failed) Icons.Rounded.Refresh else Icons.Rounded.PlayArrow, Aurora.Indigo) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    if (canPause) DownloadCenter.pause(item.id) else DownloadCenter.resume(item.id)
                }
                Box(Modifier.size(8.dp))
                RoundAction(Icons.Rounded.Close, Aurora.Coral) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    DownloadCenter.cancel(item.id)
                }
            }
        }
    }
}

@Composable
private fun RoundAction(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(color.copy(alpha = 0.18f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = color, modifier = Modifier.size(22.dp)) }
}

/** Barre de progression fluide avec reflet lumineux animé (shimmer). */
@Composable
private fun ShimmerBar(progress: Float, running: Boolean) {
    val p by animateFloatAsState(progress, tween(450), label = "p")
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-0.5f, 1.5f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "x")
    Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))) {
        Box(
            Modifier.fillMaxWidth(p.coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape).background(Aurora.navBrush)
                .drawWithContent {
                    drawContent()
                    if (running) {
                        val w = size.width
                        drawRect(
                            Brush.linearGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.6f), Color.Transparent),
                                start = Offset(x * w - w * 0.25f, 0f), end = Offset(x * w + w * 0.25f, size.height)
                            )
                        )
                    }
                }
        )
    }
}
