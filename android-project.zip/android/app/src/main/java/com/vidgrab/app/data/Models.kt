package com.vidgrab.app.data

import android.net.Uri
import org.json.JSONObject

data class Bookmark(val url: String, val title: String)

data class HistoryEntry(val url: String, val title: String, val time: Long)

/** Flux vidéo détecté par le VideoSniffer, avec les en-têtes exacts nécessaires pour éviter les 403. */
data class DetectedVideo(
    val url: String,
    val title: String,
    val type: String,          // MP4 | WEBM | MKV | HLS
    val quality: String,       // 480p / 720p / 1080p / Auto
    val sizeBytes: Long,       // -1L si inconnue
    val headers: Map<String, String>,
    val pageUrl: String
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("url", url)
        o.put("title", title)
        o.put("type", type)
        o.put("quality", quality)
        o.put("size", sizeBytes)
        o.put("pageUrl", pageUrl)
        o.put("headers", JSONObject(headers))
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): DetectedVideo {
            val h = LinkedHashMap<String, String>()
            val ho = o.optJSONObject("headers")
            if (ho != null) {
                val keys = ho.keys()
                while (keys.hasNext()) {
                    val k: String = keys.next()
                    h[k] = ho.optString(k)
                }
            }
            return DetectedVideo(
                url = o.optString("url"),
                title = o.optString("title"),
                type = o.optString("type", "MP4"),
                quality = o.optString("quality", "Auto"),
                sizeBytes = o.optLong("size", -1L),
                headers = h,
                pageUrl = o.optString("pageUrl")
            )
        }
    }
}

enum class DlState { Queued, Running, Paused, Merging, Failed }

data class DownloadItem(
    val id: String,
    val video: DetectedVideo,
    val state: DlState = DlState.Queued,
    val downloaded: Long = 0L,
    val total: Long = 0L,
    val speedBps: Long = 0L,
    val etaSec: Long = -1L,
    val waitingWifi: Boolean = false,
    val error: String? = null
) {
    val progress: Float
        get() = if (total > 0L) (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
}

data class LibItem(
    val id: String,
    val uri: Uri,
    val title: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSec: Long,
    val isPrivate: Boolean,
    val path: String?
)
