package com.vidgrab.app

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.vidgrab.app.browser.TabManager
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.download.DownloadService
import com.vidgrab.app.download.DownloadWorker
import java.util.concurrent.TimeUnit

class VidGrabApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppPrefs.init(this)
        TabManager.init(this)
        DownloadCenter.init(this)
        DownloadService.createChannel(this)

        val request = PeriodicWorkRequestBuilder<DownloadWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("vidgrab-keepalive", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
