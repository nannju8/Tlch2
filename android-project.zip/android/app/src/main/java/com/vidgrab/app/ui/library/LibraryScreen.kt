package com.vidgrab.app.ui.library

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.LibItem
import com.vidgrab.app.data.Library
import com.vidgrab.app.data.Thumbs
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.player.PlayerActivity
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.components.staggerIn
import com.vidgrab.app.ui.fmtBytes
import com.vidgrab.app.ui.fmtDuration
import com.vidgrab.app.ui.theme.Aurora
import kotlinx.coroutines.launch
import kotlin.math.abs

private enum class SortMode(val label: String) { Date("Date"), Name("Nom"), Size("Taille") }

@Composable
fun LibraryScreen(bottomPad: Dp) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val done by DownloadCenter.completed.collectAsState()
    var unlocked by remember { mutableStateOf(false) }       // se reverrouille en quittant l'onglet
    var pinDialog by remember { mutableStateOf<PinMode?>(null) }
    var pendingMove by remember { mutableStateOf<LibItem?>(null) }
    var sort by remember { mutableStateOf(SortMode.Date) }
    var sortMenu by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }
    val list = remember { mutableStateListOf<LibItem>() }
    var renaming by remember { mutableStateOf<LibItem?>(null) }
    var deleting by remember { mutableStateOf<LibItem?>(null) }

    LaunchedEffect(done, unlocked, reload) {
        val loaded = if (unlocked) Library.loadPrivate(ctx) else Library.loadPublic(ctx)
        list.clear()
        list.addAll(loaded)
    }
    val sorted = when (sort) {
        SortMode.Date -> list.sortedByDescending { it.dateAddedSec }
        SortMode.Name -> list.sortedBy { it.title.lowercase() }
        SortMode.Size -> list.sortedByDescending { it.sizeBytes }
    }

    val lockRot by animateFloatAsState(if (unlocked) 360f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "lock")
    val listState = rememberLazyListState()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("TERMINÉ", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onBackground)
                if (unlocked) Text("Dossier privé", fontSize = 12.sp, color = Aurora.Magenta)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    if (unlocked) unlocked = false
                    else pinDialog = if (AppPrefs.hasPin()) PinMode.Enter else PinMode.Create
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (unlocked) Icons.Rounded.LockOpen else Icons.Rounded.Lock, "Dossier verrouillé",
                    tint = if (unlocked) Aurora.Magenta else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.graphicsLayer { rotationY = lockRot; cameraDistance = 16f * density }
                )
            }
            Box {
                Box(Modifier.size(42.dp).clip(CircleShape).clickable { sortMenu = true }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Sort, "Trier", tint = MaterialTheme.colorScheme.onSurface)
                }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    SortMode.values().forEach { m ->
                        DropdownMenuItem(text = { Text(m.label + if (m == sort) "  ✓" else "") }, onClick = { sort = m; sortMenu = false })
                    }
                }
            }
        }

        if (sorted.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(if (unlocked) Icons.Rounded.Folder else Icons.Rounded.VideoLibrary, null, tint = Aurora.Indigo.copy(alpha = 0.6f), modifier = Modifier.size(72.dp))
                Text(if (unlocked) "Dossier privé vide" else "Aucune vidéo téléchargée", Modifier.padding(top = 14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f), state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad + 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(sorted, key = { _, it -> it.id }) { idx, item ->
                    Box(
                        Modifier.staggerIn(idx).graphicsLayer {
                            // Effet de profondeur au défilement
                            val info = listState.layoutInfo
                            val vi = info.visibleItemsInfo.firstOrNull { it.index == idx }
                            if (vi != null) {
                                val viewport: Float = (info.viewportEndOffset - info.viewportStartOffset).coerceAtLeast(1).toFloat()
                                val center: Float = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                                val itemCenter: Float = vi.offset + vi.size / 2f
                                val d: Float = ((itemCenter - center) / viewport).coerceIn(-1f, 1f)
                                val s = 1f - 0.07f * abs(d)
                                scaleX = s
                                scaleY = s
                                rotationX = -d * 7f
                                cameraDistance = 16f * density
                            }
                        }
                    ) {
                        LibraryCard(
                            item,
                            onPlay = { PlayerActivity.open(ctx, item.uri, item.title, item.id); },
                            onRename = { renaming = item },
                            onShare = {
                                if (item.isPrivate) Toast.makeText(ctx, "Retirez la vidéo du dossier privé pour la partager", Toast.LENGTH_SHORT).show()
                                else Library.share(ctx, item)
                            },
                            onMove = {
                                if (item.isPrivate) scope.launch { Library.restoreToPublic(ctx, item); reload++ }
                                else if (!AppPrefs.hasPin()) { pendingMove = item; pinDialog = PinMode.Create }
                                else scope.launch {
                                    val ok = Library.moveToPrivate(ctx, item)
                                    Toast.makeText(ctx, if (ok) "Déplacée vers le dossier privé" else "Échec du déplacement", Toast.LENGTH_SHORT).show()
                                    reload++
                                }
                            },
                            onDelete = { deleting = item }
                        )
                    }
                }
            }
        }
    }

    pinDialog?.let { mode ->
        PinDialog(
            mode = mode,
            onDismiss = { pinDialog = null; pendingMove = null },
            onSuccess = {
                pinDialog = null
                val mv = pendingMove
                pendingMove = null
                if (mv != null) {
                    scope.launch {
                        val ok = Library.moveToPrivate(ctx, mv)
                        Toast.makeText(ctx, if (ok) "Déplacée vers le dossier privé" else "Échec du déplacement", Toast.LENGTH_SHORT).show()
                        reload++
                    }
                } else unlocked = true
            }
        )
    }

    renaming?.let { it0 ->
        var text by remember(it0.id) { mutableStateOf(it0.title.substringBeforeLast('.')) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renommer") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ val t = text; renaming = null; scope.launch { Library.rename(ctx, it0, t); reload++ } }) { Text("OK") } },
            dismissButton = { TextButton({ renaming = null }) { Text("Annuler") } }
        )
    }
    deleting?.let { it0 ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer la vidéo ?") },
            text = { Text(it0.title) },
            confirmButton = { TextButton({ deleting = null; scope.launch { Library.delete(ctx, it0); reload++ } }) { Text("Supprimer", color = Aurora.Coral) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun LibraryCard(
    item: LibItem, onPlay: () -> Unit, onRename: () -> Unit, onShare: () -> Unit, onMove: () -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val ip = remember { MutableInteractionSource() }
    val pressed by ip.collectIsPressedAsState()
    val zoom by animateFloatAsState(if (pressed) 1.07f else 1f, spring(), label = "zoom")
    val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, item.id) {
        value = Thumbs.get(ctx, item)?.asImageBitmap()
    }
    val seenVersion = AppPrefs.seenVersion   // lecture d'état : recompose quand une vidéo est vue
    val isNew = seenVersion >= 0 && !AppPrefs.isSeen(item.id)

    GlassCard(Modifier.fillMaxWidth(), glow = if (isNew) Aurora.Coral else Aurora.Indigo, tilt = true) {
        Column {
            Box(
                Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                    .background(Color.Black.copy(alpha = 0.4f))
                    .clickable(interactionSource = ip, indication = null, onClick = onPlay)
            ) {
                val img = thumb
                if (img != null) {
                    Image(img, null, Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom }, contentScale = ContentScale.Crop)
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))))
                Box(
                    Modifier.align(Alignment.Center).size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                if (isNew) {
                    Box(
                        Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(Aurora.Coral, Color(0xFFFF2D55)))).padding(horizontal = 9.dp, vertical = 3.dp)
                    ) { Text("Nouveau", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold) }
                }
                if (item.durationMs > 0L) {
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 8.dp, vertical = 3.dp)
                    ) { Text(fmtDuration(item.durationMs), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Row(Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title.substringBeforeLast('.'), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text(fmtBytes(item.sizeBytes), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
                }
                Box {
                    Box(Modifier.size(40.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.MoreVert, "Actions", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Lire") }, leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) }, onClick = { menu = false; onPlay() })
                        DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; onRename() })
                        DropdownMenuItem(text = { Text("Partager") }, leadingIcon = { Icon(Icons.Rounded.Share, null) }, onClick = { menu = false; onShare() })
                        DropdownMenuItem(
                            text = { Text(if (item.isPrivate) "Retirer du dossier privé" else "Déplacer vers le dossier privé") },
                            leadingIcon = { Icon(Icons.Rounded.Lock, null) }, onClick = { menu = false; onMove() }
                        )
                        DropdownMenuItem(text = { Text("Supprimer", color = Aurora.Coral) }, leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Aurora.Coral) }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}
