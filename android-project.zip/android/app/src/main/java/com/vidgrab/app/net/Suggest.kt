package com.vidgrab.app.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

/** Suggestions Google en direct. Timeout court (3 s), échec silencieux hors ligne. */
object Suggest {
    private val quick by lazy { Http.client.newBuilder().callTimeout(3, TimeUnit.SECONDS).build() }

    suspend fun fetch(query: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val url = "https://suggestqueries.google.com/complete/search".toHttpUrl().newBuilder()
                .addQueryParameter("client", "firefox")
                .addQueryParameter("q", query)
                .build()
            quick.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return@use emptyList<String>()
                val text = r.body?.string() ?: return@use emptyList<String>()
                val arr = JSONArray(text).getJSONArray(1)
                val out = ArrayList<String>()
                for (i in 0 until minOf(arr.length(), 6)) out.add(arr.getString(i))
                out
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
