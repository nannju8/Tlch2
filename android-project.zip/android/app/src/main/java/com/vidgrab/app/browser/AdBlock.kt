package com.vidgrab.app.browser

import android.net.Uri

/**
 * Bouclier anti-pub. IMPORTANT : uniquement des noms complets de régies ou domaines exacts.
 * Jamais de mot-clé générique "ad"/"ads" (faux positifs : uqload, mp4upload...).
 */
object AdBlock {
    private val adHosts = listOf(
        "doubleclick", "popads", "propellerads", "exoclick", "adsterra", "tsyndicate",
        "realsrv", "adnxs", "taboola", "outbrain", "googlesyndication", "popcash",
        "juicyads", "clickadu", "hilltopads", "trafficjunky", "onclickads", "adcash",
        "revcontent", "bidvertiser", "popunder", "clickaine", "ad-maven", "admaven"
    )

    private val searchHosts = listOf(
        "google.", "bing.com", "duckduckgo.com", "yahoo.com", "qwant.com",
        "ecosia.org", "startpage.com", "yandex."
    )

    private val twoLevelSuffixes = setOf(
        "co.uk", "org.uk", "com.br", "com.au", "co.jp", "co.in", "com.tr", "com.mx",
        "co.za", "com.ar", "co.nz", "com.sg", "com.hk", "com.cn", "co.kr"
    )

    fun hostOf(url: String): String = try { Uri.parse(url).host?.lowercase() ?: "" } catch (e: Exception) { "" }

    fun isAdUrl(url: String): Boolean {
        val h = hostOf(url)
        if (h.isEmpty()) return false
        return adHosts.any { h.contains(it) }
    }

    fun rootDomain(host: String): String {
        val parts = host.split('.')
        if (parts.size <= 2) return host
        val last2 = parts.takeLast(2).joinToString(".")
        return if (last2 in twoLevelSuffixes) parts.takeLast(3).joinToString(".") else last2
    }

    fun sameRoot(a: String, b: String): Boolean {
        val ha = hostOf(a)
        val hb = hostOf(b)
        if (ha.isEmpty() || hb.isEmpty()) return false
        return rootDomain(ha) == rootDomain(hb)
    }

    fun isSearchEngine(url: String): Boolean {
        val h = hostOf(url)
        return searchHosts.any { h.contains(it) }
    }

    /**
     * Neutralise les calques transparents en z-index élevé, écoute <video> (filet de sécurité
     * si shouldInterceptRequest a été contourné) et remonte les vrais clics sur <a> visibles.
     */
    const val INJECT_JS: String = """
(function(){
  if (window.__vg) return; window.__vg = 1;
  function kill(){
    try {
      var w = innerWidth, h = innerHeight;
      document.querySelectorAll('div,a,span,section').forEach(function(e){
        var s = getComputedStyle(e);
        if ((s.position === 'fixed' || s.position === 'absolute') && parseInt(s.zIndex) >= 1000
            && e.offsetWidth >= w * 0.6 && e.offsetHeight >= h * 0.6
            && !e.querySelector('video,iframe,input,button,form,select')) {
          var bg = s.backgroundColor;
          if (parseFloat(s.opacity) < 0.05 || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') {
            e.style.setProperty('pointer-events', 'none', 'important');
            e.style.setProperty('display', 'none', 'important');
          }
        }
      });
    } catch (x) {}
  }
  setInterval(kill, 1500); kill();
  function hook(v){
    if (v.__vg) return; v.__vg = 1;
    var f = function(){
      var s = v.currentSrc || v.src;
      if (s && s.indexOf('blob:') !== 0 && s.indexOf('data:') !== 0) {
        try { VidBridge.onVideoSrc(s, document.title); } catch (e) {}
      }
    };
    v.addEventListener('loadedmetadata', f);
    v.addEventListener('play', f);
    f();
  }
  function scan(){ document.querySelectorAll('video').forEach(hook); }
  new MutationObserver(scan).observe(document.documentElement, {childList: true, subtree: true});
  scan();
  document.addEventListener('click', function(ev){
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if (a && ev.isTrusted) {
      var r = a.getBoundingClientRect(), st = getComputedStyle(a);
      if (r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none' && st.opacity !== '0') {
        try { VidBridge.onRealClick(a.href); } catch (e) {}
      }
    }
  }, true);
})();
"""
}
