package com.vidgrab.app.download

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Filet de sécurité toutes les 15 min — idempotent : ne relance rien si un téléchargement est déjà actif. */
class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        com.vidgrab.app.data.AppPrefs.init(applicationContext)
        DownloadCenter.init(applicationContext)
        if (DownloadCenter.hasActive()) return Result.success()
        DownloadCenter.kick()
        return Result.success()
    }
}
