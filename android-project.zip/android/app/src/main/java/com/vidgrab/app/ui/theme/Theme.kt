package com.vidgrab.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.vidgrab.app.data.AppPrefs

/** Palette "Obsidian & Neon Aurora". */
object Aurora {
    val Indigo = Color(0xFF6366F1)
    val Cyan = Color(0xFF06B6D4)
    val Coral = Color(0xFFF43F5E)
    val Magenta = Color(0xFFEC4899)
    val Gold = Color(0xFFFBBF24)
    val BgTop = Color(0xFF0B0D14)
    val BgBottom = Color(0xFF121624)
    val LightTop = Color(0xFFF4F6FF)
    val LightBottom = Color(0xFFE4E9FA)

    /** Signature : navigation. */
    val navBrush: Brush get() = Brush.linearGradient(listOf(Indigo, Cyan))
    /** Flux vidéo détecté. */
    val alertBrush: Brush get() = Brush.linearGradient(listOf(Coral, Magenta))
}

val LocalDark = staticCompositionLocalOf { true }

@Composable
fun VidGrabTheme(content: @Composable () -> Unit) {
    val dark = when (AppPrefs.themeMode) {
        0 -> isSystemInDarkTheme()
        2 -> false
        else -> true
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = Aurora.Indigo, secondary = Aurora.Cyan, tertiary = Aurora.Magenta,
            background = Aurora.BgTop, surface = Color(0xFF171B2B), surfaceVariant = Color(0xFF1E2336),
            onBackground = Color(0xFFEDEFF7), onSurface = Color(0xFFEDEFF7), onSurfaceVariant = Color(0xFF9AA3B8),
            error = Aurora.Coral, outline = Color(0x33FFFFFF)
        )
    } else {
        lightColorScheme(
            primary = Aurora.Indigo, secondary = Aurora.Cyan, tertiary = Aurora.Magenta,
            background = Aurora.LightTop, surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFEEF1FC),
            onBackground = Color(0xFF12152A), onSurface = Color(0xFF12152A), onSurfaceVariant = Color(0xFF5A6280),
            error = Aurora.Coral, outline = Color(0x22000000)
        )
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? android.app.Activity)?.window
        if (window != null) {
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
