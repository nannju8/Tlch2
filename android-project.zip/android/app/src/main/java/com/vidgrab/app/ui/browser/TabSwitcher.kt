package com.vidgrab.app.ui.browser

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.browser.TabManager
import com.vidgrab.app.browser.TabState
import com.vidgrab.app.ui.components.AuroraBackground
import com.vidgrab.app.ui.components.GlassCard
import com.vidgrab.app.ui.components.GradientButton
import com.vidgrab.app.ui.hostLabel
import com.vidgrab.app.ui.theme.Aurora
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Gestionnaire d'onglets : carrousel 3D CoverFlow (rotationY + échelle + profondeur).
 * Glisser une carte vers le haut la ferme avec rotation X et rétraction dans l'espace.
 */
@Composable
fun TabSwitcher(onClose: () -> Unit, onSelected: () -> Unit) {
    val tabs = TabManager.tabs
    val start = tabs.indexOfFirst { it.id == TabManager.currentId }.coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = start) { tabs.size }
    val haptic = LocalHapticFeedback.current
    val screenW = LocalConfiguration.current.screenWidthDp.dp

    LaunchedEffect(pager.currentPage, tabs.size) {
        if (pager.currentPage < tabs.size) TabManager.select(tabs[pager.currentPage])
    }

    AuroraBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Onglets", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
                Text("${tabs.size} ouvert(s)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HorizontalPager(
                state = pager,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = (screenW - 230.dp) / 2f),
                pageSpacing = (-40).dp,
                key = { tabs.getOrNull(it)?.id ?: it }
            ) { page ->
                val tab = tabs.getOrNull(page)
                if (tab != null) {
                    val offset: Float = (pager.currentPage - page) + pager.currentPageOffsetFraction
                    TabCard(
                        tab = tab,
                        modifier = Modifier.graphicsLayer {
                            val a = abs(offset).coerceIn(0f, 2f)
                            rotationY = (offset * -42f).coerceIn(-60f, 60f)
                            val s = 1f - 0.16f * a
                            scaleX = s
                            scaleY = s
                            alpha = 1f - 0.3f * (a / 2f)
                            cameraDistance = 16f * density
                        },
                        onOpen = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); TabManager.select(tab); onSelected() },
                        onClose = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); TabManager.closeTab(tab) }
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GradientButton("Nouvel onglet", Aurora.navBrush, { TabManager.newTab(); onSelected() }, icon = Icons.Rounded.Add)
                GradientButton("Terminé", Aurora.alertBrush, onClose, glow = Aurora.Magenta)
            }
        }
    }
}

@Composable
private fun TabCard(tab: TabState, modifier: Modifier, onOpen: () -> Unit, onClose: () -> Unit) {
    val dragY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Box(
        modifier
            .fillMaxSize()
            .padding(vertical = 16.dp)
            .graphicsLayer {
                translationY = dragY.value
                val p = (abs(dragY.value) / 600f).coerceIn(0f, 1f)
                rotationX = -p * 50f
                val s = 1f - 0.35f * p
                scaleX *= s
                scaleY *= s
                alpha *= 1f - 0.8f * p
            }
            .pointerInput(tab.id) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (dragY.value < -220f) {
                                dragY.animateTo(-900f, tween(220))
                                onClose()
                            } else dragY.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                        }
                    },
                    onDragCancel = { scope.launch { dragY.animateTo(0f, spring()) } },
                    onVerticalDrag = { _, d -> scope.launch { dragY.snapTo((dragY.value + d).coerceAtMost(40f)) } }
                )
            }
    ) {
        GlassCard(Modifier.fillMaxSize(), shape = RoundedCornerShape(26.dp), glow = Aurora.Indigo, onClick = onOpen) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 10.dp, end = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Language, null, tint = Aurora.Cyan, modifier = Modifier.size(18.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(
                            if (tab.title.isNotBlank()) tab.title else "Nouvel onglet", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(if (tab.url.isEmpty()) "Accueil" else hostLabel(tab.url), maxLines = 1, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.08f)).let {
                        it.pointerInput(Unit) { androidx.compose.foundation.gestures.detectTapGestures { onClose() } }
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, "Fermer", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp).padding(bottom = 8.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.25f))) {
                    val img = tab.preview
                    if (img != null && tab.url.isNotEmpty()) {
                        Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Language, null, tint = Aurora.Indigo.copy(alpha = 0.5f), modifier = Modifier.size(64.dp))
                        }
                    }
                }
            }
        }
    }
}
