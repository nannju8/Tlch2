package com.vidgrab.app.player

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.ui.theme.Aurora
import com.vidgrab.app.ui.theme.VidGrabTheme
import com.vidgrab.app.ui.fmtDuration
import kotlinx.coroutines.delay

/** Lecteur plein écran Media3 : content:// (MediaStore) et fichiers privés locaux (file://). */
class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppPrefs.init(applicationContext)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val uri = Uri.parse(intent.getStringExtra(EXTRA_URI) ?: "")
        val title = intent.getStringExtra(EXTRA_TITLE) ?: ""
        intent.getStringExtra(EXTRA_ID)?.let { AppPrefs.markSeen(it) }

        val p = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
        player = p
        hideSystemBars()
        setContent {
            VidGrabTheme {
                PlayerScreen(p, title, onBack = { finish() }, onFullscreen = {
                    requestedOrientation =
                        if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                })
            }
        }
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ID = "id"

        fun open(ctx: Context, uri: Uri, title: String, id: String) {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java)
                    .putExtra(EXTRA_URI, uri.toString()).putExtra(EXTRA_TITLE, title).putExtra(EXTRA_ID, id)
            )
        }
    }
}

@Composable
private fun PlayerScreen(player: ExoPlayer, title: String, onBack: () -> Unit, onFullscreen: () -> Unit) {
    var controls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(player.isPlaying) }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }
    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            dur = player.duration.coerceAtLeast(0L)
            delay(250L)
        }
    }
    LaunchedEffect(controls, playing) {
        if (controls && playing) { delay(3500L); controls = false }
    }

    fun seekBy(deltaMs: Long) {
        val target = (player.currentPosition + deltaMs).coerceIn(0L, if (dur > 0L) dur else Long.MAX_VALUE)
        player.seekTo(target)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.player = player
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Zones de double-tap ±10 s avec animation circulaire
        Row(Modifier.fillMaxSize()) {
            SeekZone(Modifier.weight(1f), Icons.Rounded.Replay10, onTap = { controls = !controls }) { if (!locked) seekBy(-10_000L) }
            SeekZone(Modifier.weight(1f), Icons.Rounded.Forward10, onTap = { controls = !controls }) { if (!locked) seekBy(10_000L) }
        }

        AnimatedVisibility(visible = controls, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
                if (!locked) {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent, Color(0xCC000000)))))
                }
                // Barre haute
                Row(
                    Modifier.fillMaxWidth().systemBarsPadding().padding(12.dp).align(Alignment.TopStart),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!locked) {
                        RoundBtn(Icons.AutoMirrored.Rounded.ArrowBack, onBack)
                        Text(
                            title.substringBeforeLast('.'), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                        )
                    } else Box(Modifier.weight(1f))
                    RoundBtn(if (locked) Icons.Rounded.Lock else Icons.Rounded.LockOpen) { locked = !locked }
                }
                if (!locked) {
                    // Centre
                    Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                        RoundBtn(Icons.Rounded.Replay10, { seekBy(-10_000L) })
                        Box(
                            Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Aurora.Indigo, Aurora.Cyan)))
                                .clickable { if (playing) player.pause() else player.play() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(40.dp))
                        }
                        RoundBtn(Icons.Rounded.Forward10, { seekBy(10_000L) })
                    }
                    // Barre basse
                    Column(Modifier.fillMaxWidth().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp).align(Alignment.BottomStart)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtDuration(pos), color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = if (dur > 0L) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f,
                                onValueChange = { f -> pos = (f * dur).toLong(); player.seekTo(pos) },
                                colors = SliderDefaults.colors(thumbColor = Aurora.Cyan, activeTrackColor = Aurora.Indigo, inactiveTrackColor = Color(0x44FFFFFF)),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                            )
                            Text(fmtDuration(dur), color = Color.White, fontSize = 12.sp)
                            Box(Modifier.size(8.dp))
                            RoundBtn(Icons.Rounded.Fullscreen, onFullscreen)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color(0x55000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White) }
}

@Composable
private fun SeekZone(modifier: Modifier, icon: ImageVector, onTap: () -> Unit, onDouble: () -> Unit) {
    var flash by remember { mutableIntStateOf(0) }
    var tapPos by remember { mutableStateOf(Offset.Zero) }
    val anim = remember { Animatable(0f) }
    LaunchedEffect(flash) {
        if (flash > 0) { anim.snapTo(0f); anim.animateTo(1f, tween(550)) }
    }
    Box(
        modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(
                onTap = { onTap() },
                onDoubleTap = { o -> tapPos = o; flash++; onDouble() }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        if (anim.value in 0.01f..0.99f) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension * 0.6f * anim.value
                drawCircle(Color.White.copy(alpha = 0.22f * (1f - anim.value)), radius = r, center = tapPos)
            }
            Icon(icon, null, tint = Color.White.copy(alpha = 1f - anim.value), modifier = Modifier.size(56.dp))
        }
    }
}
