package com.vidgrab.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

/** Préférences persistantes (SharedPreferences) exposées sous forme d'états Compose. */
object AppPrefs {
    private lateinit var sp: SharedPreferences

    /** "Télécharger uniquement en Wi-Fi" — désactivé par défaut. */
    var wifiOnly by mutableStateOf(false)
        private set

    /** 0 = système, 1 = sombre (défaut), 2 = clair */
    var themeMode by mutableIntStateOf(1)
        private set

    var seenVersion by mutableIntStateOf(0)
        private set

    val bookmarks = mutableStateListOf<Bookmark>()
    val history = mutableStateListOf<HistoryEntry>()
    private val seen = HashSet<String>()

    var pending: String
        get() = sp.getString("pending", "[]") ?: "[]"
        set(v) { sp.edit().putString("pending", v).apply() }

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("vidgrab_prefs", Context.MODE_PRIVATE)
        wifiOnly = sp.getBoolean("wifiOnly", false)
        themeMode = sp.getInt("theme", 1)
        seen.addAll(sp.getStringSet("seen", emptySet()) ?: emptySet())
        try {
            val b = JSONArray(sp.getString("bookmarks", "[]"))
            for (i in 0 until b.length()) {
                val o = b.getJSONObject(i)
                bookmarks.add(Bookmark(o.getString("url"), o.getString("title")))
            }
            val h = JSONArray(sp.getString("history", "[]"))
            for (i in 0 until h.length()) {
                val o = h.getJSONObject(i)
                history.add(HistoryEntry(o.getString("url"), o.getString("title"), o.getLong("time")))
            }
        } catch (_: Exception) { }
    }

    fun setWifiOnly(v: Boolean) { wifiOnly = v; sp.edit().putBoolean("wifiOnly", v).apply() }
    fun setTheme(v: Int) { themeMode = v; sp.edit().putInt("theme", v).apply() }

    // ---- Favoris ----
    fun isBookmarked(url: String): Boolean = bookmarks.any { it.url == url }

    fun toggleBookmark(url: String, title: String) {
        val idx = bookmarks.indexOfFirst { it.url == url }
        if (idx >= 0) bookmarks.removeAt(idx) else bookmarks.add(0, Bookmark(url, title.ifBlank { url }))
        saveBookmarks()
    }

    fun renameBookmark(b: Bookmark, newTitle: String) {
        val idx = bookmarks.indexOf(b)
        if (idx >= 0 && newTitle.isNotBlank()) { bookmarks[idx] = b.copy(title = newTitle.trim()); saveBookmarks() }
    }

    fun removeBookmark(b: Bookmark) { bookmarks.remove(b); saveBookmarks() }

    private fun saveBookmarks() {
        val a = JSONArray()
        bookmarks.forEach { a.put(JSONObject().put("url", it.url).put("title", it.title)) }
        sp.edit().putString("bookmarks", a.toString()).apply()
    }

    // ---- Historique ----
    fun addHistory(url: String, title: String) {
        history.removeAll { it.url == url }
        history.add(0, HistoryEntry(url, title.ifBlank { url }, System.currentTimeMillis()))
        while (history.size > 100) history.removeAt(history.size - 1)
        saveHistory()
    }

    fun clearHistory() { history.clear(); saveHistory() }

    private fun saveHistory() {
        val a = JSONArray()
        history.forEach { a.put(JSONObject().put("url", it.url).put("title", it.title).put("time", it.time)) }
        sp.edit().putString("history", a.toString()).apply()
    }

    // ---- Badge "Nouveau" ----
    fun isSeen(id: String): Boolean = seen.contains(id)

    fun markSeen(id: String) {
        if (seen.add(id)) {
            sp.edit().putStringSet("seen", HashSet(seen)).apply()
            seenVersion++
        }
    }

    // ---- Code PIN : SHA-256 salé ----
    fun hasPin(): Boolean = sp.contains("pinHash")

    fun setPin(pin: String) {
        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val salt = toHex(saltBytes)
        sp.edit().putString("pinSalt", salt).putString("pinHash", hash(pin, salt)).apply()
    }

    fun verifyPin(pin: String): Boolean {
        val salt = sp.getString("pinSalt", null) ?: return false
        val expected = sp.getString("pinHash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
    }

    private fun hash(pin: String, salt: String): String =
        toHex(MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray(Charsets.UTF_8)))

    private fun toHex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
}
