package com.vidgrab.app.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ThumbnailUtils
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import com.vidgrab.app.download.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Bibliothèque : vidéos publiques (MediaStore Movies/VidGrab) et dossier privé
 * (context.filesDir/private + .nomedia, jamais dans Movies/ ni MediaStore → invisible de la Galerie).
 */
object Library {
    private fun privateDir(ctx: Context): File {
        val d = File(ctx.filesDir, "private")
        d.mkdirs()
        val nomedia = File(d, ".nomedia")
        if (!nomedia.exists()) nomedia.createNewFile()
        return d
    }

    fun mimeFor(name: String): String = when (name.substringAfterLast('.', "mp4").lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "ts" -> "video/mp2t"
        else -> "video/mp4"
    }

    suspend fun loadPublic(ctx: Context): List<LibItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<LibItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", arrayOf("Movies/VidGrab%"),
                MediaStore.Video.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    out.add(LibItem("m:$id", uri, c.getString(1) ?: "video", c.getLong(2), c.getLong(3), c.getLong(4), false, null))
                }
            }
        } catch (_: Exception) { }
        out
    }

    suspend fun loadPrivate(ctx: Context): List<LibItem> = withContext(Dispatchers.IO) {
        val files = privateDir(ctx).listFiles { f -> f.isFile && !f.name.startsWith(".") } ?: emptyArray()
        files.sortedByDescending { it.lastModified() }.map { f ->
            var dur = 0L
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.absolutePath)
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                r.release()
            } catch (_: Exception) { }
            LibItem("p:" + f.name, Uri.fromFile(f), f.name, f.length(), dur, f.lastModified() / 1000L, true, f.absolutePath)
        }
    }

    suspend fun moveToPrivate(ctx: Context, item: LibItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val dest = uniqueFile(privateDir(ctx), item.title)
            ctx.contentResolver.openInputStream(item.uri)?.use { i ->
                dest.outputStream().use { o -> i.copyTo(o, 128 * 1024) }
            } ?: return@withContext false
            ctx.contentResolver.delete(item.uri, null, null)
            true
        } catch (e: Exception) { false }
    }

    suspend fun restoreToPublic(ctx: Context, item: LibItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val f = File(item.path ?: return@withContext false)
            MediaStoreSaver.save(ctx, f, item.title, mimeFor(item.title))
            f.delete()
            true
        } catch (e: Exception) { false }
    }

    suspend fun delete(ctx: Context, item: LibItem) = withContext(Dispatchers.IO) {
        try {
            if (item.isPrivate) File(item.path ?: return@withContext).delete()
            else ctx.contentResolver.delete(item.uri, null, null)
        } catch (_: Exception) { }
        Unit
    }

    suspend fun rename(ctx: Context, item: LibItem, newBase: String): Boolean = withContext(Dispatchers.IO) {
        val ext = item.title.substringAfterLast('.', "mp4")
        val clean = newBase.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        if (clean.isEmpty()) return@withContext false
        try {
            if (item.isPrivate) {
                val f = File(item.path ?: return@withContext false)
                f.renameTo(File(f.parentFile, "$clean.$ext"))
            } else {
                val v = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "$clean.$ext") }
                ctx.contentResolver.update(item.uri, v, null, null) > 0
            }
        } catch (e: Exception) { false }
    }

    fun share(ctx: Context, item: LibItem) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mimeFor(item.title)
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(i, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        var n = 1
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "mp4")
        while (f.exists()) { f = File(dir, "$base ($n).$ext"); n++ }
        return f
    }
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(48)

    suspend fun get(ctx: Context, item: LibItem): Bitmap? = withContext(Dispatchers.IO) {
        val hit = cache.get(item.id)
        if (hit != null) return@withContext hit
        val bmp: Bitmap? = try {
            if (item.isPrivate) ThumbnailUtils.createVideoThumbnail(File(item.path ?: ""), Size(720, 405), null)
            else ctx.contentResolver.loadThumbnail(item.uri, Size(720, 405), null)
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(item.id, bmp)
        bmp
    }
}
