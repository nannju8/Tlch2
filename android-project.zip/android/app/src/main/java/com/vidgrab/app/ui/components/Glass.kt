package com.vidgrab.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.ui.theme.Aurora
import com.vidgrab.app.ui.theme.LocalDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Arrière-plan : dégradé #0B0D14 → #121624 + halos d'aurore animés lentement. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val dark = LocalDark.current
    val t = rememberInfiniteTransition(label = "aurora")
    val p1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "p1")
    val p2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "p2")
    val p3 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "p3")
    val base = if (dark) listOf(Aurora.BgTop, Aurora.BgBottom) else listOf(Aurora.LightTop, Aurora.LightBottom)
    val a: Float = if (dark) 0.30f else 0.22f
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(base))
            .drawBehind {
                val w = size.width
                val h = size.height
                fun halo(c: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
                    drawCircle(
                        Brush.radialGradient(listOf(c.copy(alpha = alpha), Color.Transparent), center = Offset(cx, cy), radius = r),
                        radius = r, center = Offset(cx, cy)
                    )
                }
                halo(Aurora.Indigo, w * (0.15f + 0.55f * p1), h * (0.06f + 0.08f * p2), w * 0.75f, a)
                halo(Aurora.Cyan, w * (0.95f - 0.55f * p2), h * (0.16f + 0.06f * p1), w * 0.60f, a * 0.8f)
                halo(Aurora.Magenta, w * (0.30f + 0.40f * p3), h * (0.62f + 0.12f * p3), w * 0.55f, a * 0.45f)
            },
        content = content
    )
}

fun Modifier.glassBorder(shape: Shape): Modifier = composed {
    val dark = LocalDark.current
    val start = if (dark) Color.White.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.9f)
    border(1.dp, Brush.linearGradient(listOf(start, Color.Transparent)), shape)
}

/**
 * Carte glassmorphism : surface à 70 %, bordure dégradée 1 dp, ombre colorée, et — si tilt = true —
 * inclinaison 3D (rotationX/Y, cameraDistance = 16f * density) avec reflet spéculaire qui suit le doigt.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    glow: Color = Aurora.Indigo,
    tilt: Boolean = false,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val rx = remember { Animatable(0f) }
    val ry = remember { Animatable(0f) }
    val sheen = remember { Animatable(0f) }
    var hl by remember { mutableStateOf(Offset(0.5f, 0.2f)) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val maxDeg = 9f
    val soft = spring<Float>(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)

    var m = modifier
        .graphicsLayer {
            rotationX = rx.value
            rotationY = ry.value
            cameraDistance = 16f * density
        }
        .shadow(10.dp, shape, ambientColor = glow.copy(alpha = 0.35f), spotColor = glow.copy(alpha = 0.50f))
        .clip(shape)
        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.70f))
        .glassBorder(shape)
        .onSizeChanged { sz = it }
        .drawWithContent {
            drawContent()
            val s = sheen.value
            if (s > 0.01f) {
                val c = Offset(hl.x * size.width, hl.y * size.height)
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.18f * s), Color.Transparent),
                        center = c, radius = size.maxDimension * 0.65f
                    )
                )
            }
        }

    if (tilt || onClick != null || onLongClick != null) {
        m = m.pointerInput(onClick, onLongClick, tilt) {
            detectTapGestures(
                onPress = { o ->
                    if (tilt && sz.width > 0 && sz.height > 0) {
                        val nx = (o.x / sz.width).coerceIn(0f, 1f)
                        val ny = (o.y / sz.height).coerceIn(0f, 1f)
                        hl = Offset(nx, ny)
                        scope.launch { rx.animateTo((0.5f - ny) * 2f * maxDeg, soft) }
                        scope.launch { ry.animateTo((nx - 0.5f) * 2f * maxDeg, soft) }
                        scope.launch { sheen.animateTo(1f, tween(180)) }
                    }
                    tryAwaitRelease()
                    if (tilt) {
                        scope.launch { rx.animateTo(0f, soft) }
                        scope.launch { ry.animateTo(0f, soft) }
                        scope.launch { sheen.animateTo(0f, tween(400)) }
                    }
                },
                onTap = { onClick?.invoke() },
                onLongPress = {
                    if (onLongClick != null) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongClick()
                    }
                }
            )
        }
    }
    Box(m, content = content)
}

/** Apparition en cascade : léger décalage Z / échelle / translation. */
fun Modifier.staggerIn(index: Int): Modifier = composed {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index.coerceAtMost(8) * 55L)
        p.animateTo(1f, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow))
    }
    graphicsLayer {
        val v = p.value
        alpha = v.coerceIn(0f, 1f)
        val s = 0.88f + 0.12f * v
        scaleX = s
        scaleY = s
        translationY = (1f - v) * 60f
        rotationX = (1f - v) * 18f
        cameraDistance = 16f * density
    }
}

@Composable
fun GlassIconButton(icon: ImageVector, desc: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.onSurface) {
    val shape = RoundedCornerShape(14.dp)
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .size(42.dp)
            .shadow(6.dp, shape, ambientColor = Aurora.Indigo.copy(alpha = 0.3f), spotColor = Aurora.Indigo.copy(alpha = 0.3f))
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.70f))
            .glassBorder(shape)
            .clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(22.dp)) }
}

/** Bouton carré en relief affichant le nombre d'onglets. */
@Composable
fun TabCountButton(count: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier
            .size(42.dp)
            .shadow(8.dp, shape, ambientColor = Aurora.Cyan.copy(alpha = 0.4f), spotColor = Aurora.Cyan.copy(alpha = 0.4f))
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.70f))
            .border(1.5.dp, Aurora.navBrush, shape)
            .clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(count.toString(), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun GradientButton(
    text: String, brush: Brush, onClick: () -> Unit, modifier: Modifier = Modifier,
    icon: ImageVector? = null, glow: Color = Aurora.Indigo
) {
    val haptic = LocalHapticFeedback.current
    Row(
        modifier
            .shadow(10.dp, CircleShape, ambientColor = glow, spotColor = glow)
            .clip(CircleShape)
            .background(brush)
            .clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() }
            .padding(horizontal = 22.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Box(Modifier.size(8.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun Badge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) { Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
}
