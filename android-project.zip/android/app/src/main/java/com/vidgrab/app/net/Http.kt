package com.vidgrab.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import okhttp3.Call
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * OkHttpClient singleton optimisé : sans le Dispatcher personnalisé, OkHttp plafonne à
 * 5 requêtes simultanées par hôte, ce qui étranglerait les workers parallèles.
 * Un registre des Call actifs par tâche permet d'annuler instantanément les sockets.
 */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dispatcher(Dispatcher().apply {
                maxRequests = 64
                maxRequestsPerHost = 16
            })
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    private val registry = ConcurrentHashMap<String, MutableSet<Call>>()

    fun newCall(taskId: String?, request: Request): Call {
        val call = client.newCall(request)
        if (taskId != null) {
            registry.getOrPut(taskId) { Collections.newSetFromMap(ConcurrentHashMap<Call, Boolean>()) }.add(call)
        }
        return call
    }

    fun release(taskId: String?, call: Call) {
        if (taskId != null) registry[taskId]?.remove(call)
    }

    fun cancelAll(taskId: String) {
        val set = registry.remove(taskId) ?: return
        set.forEach { it.cancel() }
    }

    private val skipped = setOf(
        "range", "host", "accept-encoding", "connection", "content-length",
        "if-range", "if-none-match", "if-modified-since", "x-requested-with"
    )

    /** Reconstruit les en-têtes capturés (Referer, Origin, User-Agent, Cookie...) pour OkHttp. */
    fun headersFor(h: Map<String, String>): Headers {
        val b = Headers.Builder()
        for ((k, v) in h) {
            if (k.lowercase() in skipped) continue
            try { b.set(k, v) } catch (_: IllegalArgumentException) { }
        }
        return b.build()
    }
}

object Net {
    fun isWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }
}
