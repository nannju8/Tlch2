package com.vidgrab.app.download

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class RangeInfo(val supportsRange: Boolean, val total: Long)

class DownloadResult(val file: File, val ext: String, val mime: String)

/** État mémoire d'une tâche : conserve les blocs terminés pour une vraie reprise après Pause. */
class TaskRuntime(val id: String) {
    val downloaded = AtomicLong(0L)
    val total = AtomicLong(0L)
    val doneBlocks: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    @Volatile var tmpFile: File? = null
    @Volatile var rangeInfo: RangeInfo? = null
}
