package com.vidgrab.app.download

import android.content.Context
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.DlState
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.net.Http
import com.vidgrab.app.net.Net
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** File d'attente + orchestration. MAX_PARALLEL = 2 : les suivants attendent. */
object DownloadCenter {
    const val MAX_PARALLEL = 2

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val runtimes = ConcurrentHashMap<String, TaskRuntime>()

    val items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val completed = MutableStateFlow(0)

    fun init(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        restore()
    }

    // ---------- API ----------
    fun enqueue(video: DetectedVideo): Boolean {
        if (items.value.any { it.video.url == video.url }) return false
        val item = DownloadItem(id = UUID.randomUUID().toString(), video = video, total = maxOf(video.sizeBytes, 0L))
        items.update { it + item }
        persist()
        kick()
        return true
    }

    fun pause(id: String, waitingWifi: Boolean = false) {
        update(id) { it.copy(state = DlState.Paused, speedBps = 0L, etaSec = -1L, waitingWifi = waitingWifi) }
        Http.cancelAll(id)
        jobs[id]?.cancel()
        persist()
    }

    fun resume(id: String) {
        update(id) { it.copy(state = DlState.Queued, waitingWifi = false, error = null) }
        persist()
        kick()
    }

    fun cancel(id: String) {
        Http.cancelAll(id)
        jobs[id]?.cancel()
        items.update { l -> l.filter { it.id != id } }
        cleanup(id)
        persist()
    }

    fun pauseAll() {
        items.value.filter { it.state == DlState.Running || it.state == DlState.Queued }.forEach { pause(it.id) }
    }

    fun hasActive(): Boolean = items.value.any { it.state == DlState.Running || it.state == DlState.Merging }

    /** Le service doit rester vivant tant qu'il y a du travail (ou une attente de Wi-Fi). */
    fun needsService(): Boolean = items.value.any {
        it.state == DlState.Running || it.state == DlState.Merging || it.state == DlState.Queued || it.waitingWifi
    }

    /** Point d'entrée idempotent (UI, WorkManager) : démarre ce qui est en attente sans doublon. */
    fun kick() {
        if (!::app.isInitialized) return
        pump()
        if (needsService()) DownloadService.start(app)
    }

    /** Appelé périodiquement par le service : respecte le mode "Wi-Fi uniquement". */
    fun onNetworkTick() {
        val wifiOk = !AppPrefs.wifiOnly || Net.isWifi(app)
        if (!wifiOk) {
            items.value.filter { it.state == DlState.Running }.forEach { pause(it.id, waitingWifi = true) }
            items.update { l -> l.map { if (it.state == DlState.Queued) it.copy(waitingWifi = true) else it } }
        } else {
            val waiting = items.value.filter { it.waitingWifi }
            if (waiting.isNotEmpty()) {
                items.update { l -> l.map { if (it.waitingWifi) it.copy(state = DlState.Queued, waitingWifi = false) else it } }
            }
            pump()
        }
    }

    // ---------- Interne ----------
    private fun update(id: String, f: (DownloadItem) -> DownloadItem) {
        items.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    @Synchronized
    private fun pump() {
        val wifiBlocked = AppPrefs.wifiOnly && !Net.isWifi(app)
        while (jobs.size < MAX_PARALLEL) {
            val next = items.value.firstOrNull { it.state == DlState.Queued && !jobs.containsKey(it.id) } ?: break
            if (wifiBlocked) {
                items.update { l -> l.map { if (it.state == DlState.Queued) it.copy(waitingWifi = true) else it } }
                break
            }
            val job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) { run(next.id) }
            jobs[next.id] = job
            job.start()
        }
    }

    private suspend fun run(id: String) {
        val item = items.value.firstOrNull { it.id == id } ?: run { jobs.remove(id); return }
        val rt = runtimes.getOrPut(id) { TaskRuntime(id) }
        update(id) { it.copy(state = DlState.Running, error = null, waitingWifi = false) }

        val ticker = scope.launch {
            var last = rt.downloaded.get()
            var lastT = System.nanoTime()
            var ema = 0.0
            while (isActive) {
                delay(500L)
                val now = System.nanoTime()
                val cur = rt.downloaded.get()
                val dt: Double = (now - lastT).toDouble() / 1_000_000_000.0
                val inst: Double = (cur - last).toDouble() / dt
                ema = if (ema == 0.0) inst else ema * 0.7 + inst * 0.3
                last = cur
                lastT = now
                val tot = rt.total.get()
                val eta: Long = if (ema > 1.0 && tot > cur) ((tot - cur).toDouble() / ema).toLong() else -1L
                update(id) {
                    if (it.state == DlState.Running) it.copy(downloaded = cur, total = tot, speedBps = ema.toLong(), etaSec = eta) else it
                }
            }
        }

        try {
            val result = if (item.video.type == "HLS") {
                HlsDownloader.download(app, item, rt) { update(id) { it.copy(state = DlState.Merging, speedBps = 0L, etaSec = -1L) } }
            } else {
                DirectDownloader.download(app, item, rt)
            }
            ticker.cancel()
            update(id) { it.copy(state = DlState.Merging, speedBps = 0L, etaSec = -1L) }
            val name = item.video.title.ifBlank { "video" } + "." + result.ext
            withContext(Dispatchers.IO) { MediaStoreSaver.save(app, result.file, name, result.mime) }
            cleanup(id)
            items.update { l -> l.filter { it.id != id } }
            completed.update { it + 1 }
            persist()
        } catch (e: CancellationException) {
            ticker.cancel()
            throw e
        } catch (e: Exception) {
            ticker.cancel()
            update(id) { it.copy(state = DlState.Failed, speedBps = 0L, etaSec = -1L, error = e.message ?: "Erreur réseau") }
            persist()
        } finally {
            jobs.remove(id)
            pump()
        }
    }

    private fun cleanup(id: String) {
        runtimes.remove(id)
        File(app.cacheDir, "dl/$id.part").delete()
        File(app.cacheDir, "dl/$id").deleteRecursively()
    }

    // ---------- Persistance (reprise après mort du process par le Worker) ----------
    private fun persist() {
        try {
            val arr = JSONArray()
            items.value.forEach {
                arr.put(
                    JSONObject().put("id", it.id).put("video", it.video.toJson())
                        .put("paused", it.state == DlState.Paused && !it.waitingWifi)
                )
            }
            AppPrefs.pending = arr.toString()
        } catch (_: Exception) { }
    }

    private fun restore() {
        try {
            val arr = JSONArray(AppPrefs.pending)
            val list = ArrayList<DownloadItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val v = DetectedVideo.fromJson(o.getJSONObject("video"))
                val paused = o.optBoolean("paused", false)
                list.add(
                    DownloadItem(
                        id = o.getString("id"), video = v,
                        state = if (paused) DlState.Paused else DlState.Queued,
                        total = maxOf(v.sizeBytes, 0L)
                    )
                )
            }
            items.value = list
        } catch (_: Exception) { }
    }
}
