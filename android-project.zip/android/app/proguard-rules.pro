# Ponts JavaScript : ne jamais renommer / supprimer
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.vidgrab.app.browser.TabManager$Bridge { *; }
-keep @androidx.annotation.Keep class * { *; }
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
