plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    // Plugin Compose obligatoire avec Kotlin 2.0 (K2) : remplace l'ancien bloc composeOptions
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
