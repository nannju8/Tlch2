# VidGrab — navigateur + sniffer vidéo + téléchargeur haute vitesse (Android / Kotlin / Compose)

## Compiler l'APK
1. Ouvrir ce dossier dans **Android Studio Koala (2024.1.1)** ou plus récent (JDK 17 embarqué).
2. Laisser Gradle synchroniser (Android Studio génère `gradlew` et `gradle-wrapper.jar` tout seul).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - APK debug : `app/build/outputs/apk/debug/app-debug.apk`
   - En ligne de commande : `./gradlew assembleDebug` ou `./gradlew assembleRelease`
     (la variante release est signée avec la clé debug pour rester installable sans keystore).
4. Activer « sources inconnues » sur le téléphone et installer l'APK.

## Versions
- Gradle 8.9 · AGP 8.6.1 · Kotlin 2.0.20 (plugin Compose compiler)
- compileSdk 35 · targetSdk 35 · minSdk 29 (Android 10+) · Java 17
- Compose BOM 2024.09.03 · Media3 1.4.1 · WorkManager 2.9.1

## Package
`com.vidgrab.app`
