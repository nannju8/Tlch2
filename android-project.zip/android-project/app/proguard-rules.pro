# Règles ProGuard / R8 (minification désactivée par défaut dans build.gradle.kts).
-keep class com.vidgrab.app.data.** { *; }
-dontwarn org.slf4j.**
