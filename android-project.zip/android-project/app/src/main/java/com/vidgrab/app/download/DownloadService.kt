package com.vidgrab.app.download

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground Service (type dataSync) : garde le processus actif, affiche la notification de progression
 * persistante et maintient un PARTIAL_WAKE_LOCK + un WifiLock FULL_HIGH_PERF pendant les téléchargements.
 */
class DownloadService : Service() {
    companion object {
        const val ACTION_PAUSE_ALL = "com.vidgrab.app.action.PAUSE_ALL"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var collector: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE_ALL) DownloadCenter.pauseAll()

        try {
            ServiceCompat.startForeground(
                this,
                Notifs.ID_FOREGROUND,
                Notifs.progress(this, DownloadCenter.items.value),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        acquireLocks()

        if (collector?.isActive != true) {
            collector = scope.launch {
                DownloadCenter.items.collect { items ->
                    if (items.none { it.isActive }) {
                        shutdown()
                    } else {
                        NotificationManagerCompat.from(this@DownloadService).let { nm ->
                            try {
                                nm.notify(Notifs.ID_FOREGROUND, Notifs.progress(this@DownloadService, items))
                            } catch (_: SecurityException) {
                            }
                        }
                        delay(1000) // limite la mise à jour de la notification à 1 Hz
                    }
                }
            }
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wakeLock?.isHeld != true) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VidGrab::DownloadWake").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        }
        if (wifiLock?.isHeld != true) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "VidGrab::DownloadWifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocks() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        wakeLock = null
        wifiLock = null
    }

    private fun shutdown() {
        collector?.cancel()
        releaseLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Android 15 : les services dataSync ont une limite de 6 h cumulées par 24 h. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        DownloadCenter.pauseAll()
        shutdown()
    }

    override fun onDestroy() {
        releaseLocks()
        scope.cancel()
        super.onDestroy()
    }
}
