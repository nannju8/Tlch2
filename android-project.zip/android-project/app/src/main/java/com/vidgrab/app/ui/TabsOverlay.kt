package com.vidgrab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import android.net.Uri
import com.vidgrab.app.MainViewModel

/** Gestionnaire d'onglets plein écran. */
@Composable
fun TabsOverlay(vm: MainViewModel) {
    Dialog(
        onDismissRequest = { vm.showTabs = false },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = GraySearch) {
            Column(Modifier.systemBarsPadding()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${vm.tabs.tabs.size} onglet(s)",
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    TextButton(onClick = {
                        vm.tabs.closeAll()
                        vm.showTabs = false
                    }) { Text("Tout fermer") }
                    IconButton(onClick = {
                        vm.tabs.newTab()
                        vm.screen = 0
                        vm.showTabs = false
                    }) { Icon(Icons.Outlined.Add, "Nouvel onglet") }
                    IconButton(onClick = { vm.showTabs = false }) { Icon(Icons.Outlined.Close, "Fermer") }
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(vm.tabs.tabs.toList(), key = { it.id }) { t ->
                        val selected = t.id == vm.tabs.currentId
                        val host = if (t.showHome || t.url.isBlank()) "Accueil"
                        else Uri.parse(t.url).host?.removePrefix("www.") ?: t.url
                        Column(
                            Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .border(
                                    if (selected) 2.dp else 0.dp,
                                    if (selected) Blue else Color.Transparent,
                                    RoundedCornerShape(16.dp)
                                )
                                .clickable {
                                    vm.tabs.select(t.id)
                                    vm.screen = 0
                                    vm.showTabs = false
                                }
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 12.dp, top = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (t.showHome) "Nouvel onglet" else t.title,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                                IconButton(onClick = { vm.tabs.closeTab(t.id) }, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Outlined.Close, "Fermer l'onglet", modifier = Modifier.size(18.dp))
                                }
                            }
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Brush.linearGradient(colorsForHost(host))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    host,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
