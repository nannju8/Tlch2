package com.vidgrab.app

import android.app.Activity
import android.app.Application
import android.content.MutableContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vidgrab.app.browser.TabManager
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.LibraryVideo
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.storage.LibraryStore
import com.vidgrab.app.storage.Storage
import com.vidgrab.app.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val webContext = MutableContextWrapper(app)

    val recent = mutableStateListOf<String>()
    val tabs = TabManager(webContext) { host -> addRecent(host) }

    /** 0 = Onglet, 1 = Progression, 2 = Terminé */
    var screen by mutableIntStateOf(0)
    var showTabs by mutableStateOf(false)
    var showHelp by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var showSheet by mutableStateOf(false)

    val downloads = DownloadCenter.items
    val library = LibraryStore.videos

    init {
        recent.addAll(AppPrefs.recentSites())
        DownloadCenter.resumePending()
        viewModelScope.launch { LibraryStore.refreshExistence() }
    }

    fun attachActivity(activity: Activity) {
        webContext.baseContext = activity
    }

    fun detachActivity(activity: Activity) {
        if (webContext.baseContext === activity) {
            webContext.baseContext = getApplication<Application>()
        }
    }

    // ------------------------------------------------------------ sites récents

    private fun addRecent(host: String) {
        val h = host.removePrefix("www.").lowercase()
        if (h.isBlank()) return
        recent.remove(h)
        recent.add(0, h)
        while (recent.size > 10) recent.removeAt(recent.lastIndex)
        AppPrefs.saveRecentSites(recent.toList())
    }

    fun removeRecent(host: String) {
        recent.remove(host)
        AppPrefs.saveRecentSites(recent.toList())
    }

    fun clearRecent() {
        recent.clear()
        AppPrefs.saveRecentSites(emptyList())
    }

    // ------------------------------------------------------------ téléchargements

    fun download(v: DetectedVideo) = DownloadCenter.enqueue(v)

    // ------------------------------------------------------------ bibliothèque

    private val ctx get() = getApplication<Application>()

    fun markSeen(id: String) = LibraryStore.markSeen(id)

    fun rename(v: LibraryVideo, title: String) {
        viewModelScope.launch(Dispatchers.IO) { LibraryStore.replace(Storage.rename(ctx, v, title)) }
    }

    fun delete(list: List<LibraryVideo>) {
        viewModelScope.launch(Dispatchers.IO) {
            list.forEach { Storage.delete(ctx, it) }
            LibraryStore.remove(list.map { it.id })
        }
    }

    fun moveToPrivate(list: List<LibraryVideo>, onDone: (Int) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            list.filter { !it.isPrivate }.forEach { v ->
                Storage.moveToPrivate(ctx, v)?.let { LibraryStore.replace(it); ok++ }
            }
            launch(Dispatchers.Main) { onDone(ok) }
        }
    }

    fun moveToPublic(list: List<LibraryVideo>, onDone: (Int) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            list.filter { it.isPrivate }.forEach { v ->
                Storage.moveToPublic(ctx, v)?.let { LibraryStore.replace(it); ok++ }
            }
            launch(Dispatchers.Main) { onDone(ok) }
        }
    }

    // ------------------------------------------------------------ code PIN

    fun hasPin(): Boolean = AppPrefs.pinHash != null

    fun setPin(pin: String) {
        AppPrefs.pinHash = Fmt.sha256("vidgrab:$pin")
    }

    fun checkPin(pin: String): Boolean = AppPrefs.pinHash == Fmt.sha256("vidgrab:$pin")
}