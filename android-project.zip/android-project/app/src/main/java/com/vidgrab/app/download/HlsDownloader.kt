package com.vidgrab.app.download

import android.content.Context
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.net.ConnectionRegistry
import com.vidgrab.app.net.Http
import com.vidgrab.app.net.HlsParser
import com.vidgrab.app.net.HlsSegment
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class HlsResult(val file: File, val ext: String)

/**
 * Téléchargeur HLS natif : télécharge les segments en parallèle (4 à 8 workers),
 * déchiffre l'AES-128, concatène puis remuxe en MP4 unique.
 * Les segments terminés sont conservés pour permettre la reprise après pause.
 */
class HlsDownloader(
    private val ctx: Context,
    private val item: DownloadItem,
    private val dir: File,
    private val reg: ConnectionRegistry,
    private val listener: ProgressListener
) {
    private val keyCache = ConcurrentHashMap<String, ByteArray>()

    private fun segFile(s: HlsSegment) = File(dir, "seg_%05d.bin".format(s.index))

    suspend fun run(): HlsResult = withContext(Dispatchers.IO) {
        dir.mkdirs()
        var base = item.url
        var text = try {
            Http.fetchTextOrThrow(base, item.userAgent, item.referer, item.cookies, reg)
        } catch (e: IOException) {
            if (reg.aborted) throw CancellationException("aborted")
            throw e
        }
        if (HlsParser.isMaster(text)) {
            val best = HlsParser.parseMaster(text, base)
                .maxByOrNull { it.height * 1_000_000L + it.bandwidth }
                ?: throw IOException("Aucune variante HLS trouvée")
            base = best.url
            text = Http.fetchTextOrThrow(base, item.userAgent, item.referer, item.cookies, reg)
        }
        val pl = HlsParser.parseMedia(text, base)
        if (pl.segments.isEmpty()) throw IOException("Playlist HLS vide")
        if (pl.segments.any { it.key?.method?.startsWith("SAMPLE-AES") == true || it.key?.method == "SAMPLE-AES-CTR" }) {
            throw IOException("Flux protégé (SAMPLE-AES / DRM) non supporté")
        }

        val segments = pl.segments
        val totalSegs = segments.size
        val bytes = AtomicLong(0)
        val done = AtomicInteger(0)

        val initFile = pl.initUrl?.let { u ->
            File(dir, "init.bin").also { f ->
                if (!f.exists() || f.length() == 0L) fetchToFile(u, f)
            }
        }

        // Reprise : compte les segments déjà complets
        for (s in segments) {
            val f = segFile(s)
            if (f.exists()) {
                bytes.addAndGet(f.length())
                done.incrementAndGet()
            }
        }

        val estimate = {
            val d = done.get()
            if (d <= 0) item.total else maxOf(bytes.get(), bytes.get() * totalSegs / d)
        }
        val next = AtomicInteger(0)
        val workers = AppPrefs.segments

        coroutineScope {
            val ticker = launchTicker({ bytes.get() }, estimate, listener)
            try {
                coroutineScope {
                    repeat(workers) {
                        launch {
                            while (true) {
                                val i = next.getAndIncrement()
                                if (i >= totalSegs) break
                                val s = segments[i]
                                val f = segFile(s)
                                if (f.exists()) continue
                                downloadSegment(s, f, bytes)
                                done.incrementAndGet()
                            }
                        }
                    }
                }
            } finally {
                ticker.cancel()
            }
        }

        // Fusion
        listener.onMerging()
        val isFmp4 = initFile != null
        val merged = File(dir, if (isFmp4) "merged.mp4" else "merged.ts")
        merged.outputStream().buffered(1 shl 20).use { out ->
            initFile?.inputStream()?.use { it.copyTo(out) }
            for (s in segments) {
                currentCoroutineContext().ensureActive()
                segFile(s).inputStream().use { it.copyTo(out) }
            }
        }
        segments.forEach { segFile(it).delete() }
        initFile?.delete()

        if (isFmp4) return@withContext HlsResult(merged, "mp4")

        val mp4 = File(dir, "final.mp4")
        val ok = Remuxer.tsToMp4(ctx, merged, mp4)
        if (ok && mp4.exists() && mp4.length() > 0) {
            merged.delete()
            HlsResult(mp4, "mp4")
        } else {
            // Repli : on conserve le flux TS tel quel (lisible par ExoPlayer / VLC)
            mp4.delete()
            HlsResult(merged, "ts")
        }
    }

    private fun fetchToFile(url: String, dest: File) {
        val data = Http.fetchBytes(url, item.userAgent, item.referer, item.cookies, reg)
        dest.writeBytes(data)
    }

    private fun cipherFor(s: HlsSegment): Cipher {
        val key = s.key ?: error("no key")
        val uri = key.uri ?: throw IOException("URI de clé AES manquante")
        val keyBytes = keyCache.getOrPut(uri) {
            Http.fetchBytes(uri, item.userAgent, item.referer, item.cookies, reg)
        }
        val iv = key.iv ?: HlsParser.ivFromSequence(s.sequence)
        return Cipher.getInstance("AES/CBC/PKCS5Padding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(iv))
        }
    }

    private suspend fun downloadSegment(s: HlsSegment, dest: File, bytes: AtomicLong) {
        var attempt = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val part = File(dir, dest.name + ".part")
            var counted = 0L
            try {
                val c = Http.connect(s.url, item.userAgent, item.referer, item.cookies, null, reg)
                try {
                    if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
                    var input: InputStream = c.inputStream
                    val key = s.key
                    if (key != null && key.method == "AES-128") {
                        input = CipherInputStream(input, cipherFor(s))
                    }
                    input.use { ins ->
                        part.outputStream().buffered(128 * 1024).use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                out.write(buf, 0, r)
                                bytes.addAndGet(r.toLong())
                                counted += r
                                currentCoroutineContext().ensureActive()
                            }
                        }
                    }
                } finally {
                    runCatching { c.disconnect() }
                    reg.remove(c)
                }
                if (!part.renameTo(dest)) throw IOException("Renommage du segment impossible")
                return
            } catch (e: IOException) {
                bytes.addAndGet(-counted)
                part.delete()
                if (reg.aborted) throw CancellationException("aborted")
                attempt++
                if (attempt >= 5) throw e
                delay(800L * attempt)
            }
        }
    }
}
