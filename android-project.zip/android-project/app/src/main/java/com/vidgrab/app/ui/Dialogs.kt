package com.vidgrab.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.vidgrab.app.data.AppPrefs

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    val steps = listOf(
        "Ouvrez un site contenant une vidéo (Facebook, Instagram, Vimeo, Dailymotion, TikTok…) depuis l'onglet « Onglet ».",
        "Lancez la lecture de la vidéo dans la page.",
        "Le bouton de téléchargement en bas à droite s'illumine dès qu'un flux vidéo est détecté.",
        "Touchez-le, choisissez la qualité (480p, 720p, 1080p…) puis « Télécharger ».",
        "Suivez l'avancement et la vitesse dans « Progression ». Le téléchargement continue écran verrouillé.",
        "Retrouvez vos vidéos dans « Terminé » : lecture, renommage, partage ou dossier privé protégé par PIN.",
        "Note : les vidéos YouTube sont exclues."
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Comment télécharger", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                steps.forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            Modifier.size(22.dp).clip(CircleShape).background(Blue),
                            contentAlignment = Alignment.Center
                        ) { Text("${i + 1}", color = androidx.compose.ui.graphics.Color.White) }
                        Spacer(Modifier.width(10.dp))
                        Text(s)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Compris") } }
    )
}

@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var segments by remember { mutableFloatStateOf(AppPrefs.segments.toFloat()) }
    val ignoring = remember {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Paramètres", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Segments parallèles par fichier : ${segments.toInt()}", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = segments,
                    onValueChange = {
                        segments = it
                        AppPrefs.segments = it.toInt()
                    },
                    valueRange = 4f..8f,
                    steps = 3
                )
                Text("Plus de segments = débit maximal sur Wi-Fi rapide (4 à 8).")
                Spacer(Modifier.height(16.dp))
                Text("Optimisation de la batterie", fontWeight = FontWeight.SemiBold)
                if (ignoring) {
                    Text("Désactivée pour VidGrab : les téléchargements ne seront pas suspendus.")
                } else {
                    Text("Recommandé : désactivez-la pour que les longs téléchargements ne soient jamais coupés.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        runCatching {
                            ctx.startActivity(
                                Intent(
                                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    Uri.parse("package:${ctx.packageName}")
                                )
                            )
                        }
                    }) { Text("Désactiver l'optimisation") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

/** Dialogue de code PIN : création (double saisie) ou déverrouillage. */
@Composable
fun PinDialog(
    create: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (pin: String) -> Boolean
) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (create) "Créer un code PIN" else "Dossier privé", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    if (create) "Choisissez un code de 4 à 6 chiffres pour protéger vos vidéos privées."
                    else "Saisissez votre code PIN."
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                    label = { Text("Code PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                if (create) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) confirm = it },
                        label = { Text("Confirmer le code") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                error?.let {
                    Text(it, color = Red, modifier = Modifier.padding(top = 8.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> error = "Le code doit contenir au moins 4 chiffres."
                    create && pin != confirm -> error = "Les deux codes ne correspondent pas."
                    else -> if (!onSubmit(pin)) error = "Code incorrect."
                }
            }) { Text(if (create) "Créer" else "Déverrouiller") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
