package com.vidgrab.app.download

import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.net.ConnectionRegistry
import com.vidgrab.app.net.Http
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicLongArray
import kotlin.math.min

/**
 * Téléchargeur segmenté dynamique : découpe le fichier en micro-blocs (en-tête HTTP Range)
 * consommés en parallèle par 6 à 8 workers sur Dispatchers.IO afin d'éviter toute chute de vitesse
 * en fin de téléchargement, et écrits avec tampon dans un fichier pré-alloué.
 * Reprise possible grâce à un fichier meta.json (offset de chaque bloc).
 */
class DirectDownloader(
    private val item: DownloadItem,
    private val dir: File,
    private val reg: ConnectionRegistry,
    private val listener: ProgressListener
) {
    private data class Info(val total: Long, val ranges: Boolean)

    private val downloaded = AtomicLong(0)
    private lateinit var pos: AtomicLongArray
    private lateinit var ends: LongArray
    private lateinit var channel: FileChannel

    suspend fun run(): File = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val out = File(dir, "file.${item.ext}")
        val info = probe()
        if (info.total > 0 && info.ranges) segmented(out, info.total) else single(out)
        out
    }

    private fun probe(): Info {
        try {
            val c = Http.connect(item.url, item.userAgent, item.referer, item.cookies, "bytes=0-0", reg)
            try {
                return when (c.responseCode) {
                    206 -> {
                        val total = c.getHeaderField("Content-Range")
                            ?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                        Info(total, total > 0)
                    }
                    200 -> Info(c.contentLengthLong, false)
                    else -> throw IOException("HTTP ${c.responseCode}")
                }
            } finally {
                runCatching { c.disconnect() }
                reg.remove(c)
            }
        } catch (e: IOException) {
            if (reg.aborted) throw CancellationException("aborted")
            throw e
        }
    }

    private suspend fun segmented(out: File, total: Long) {
        val workers = when {
            total < 512 * 1024L -> 1
            total < 4L * 1024 * 1024 -> AppPrefs.segments.coerceIn(4, 6)
            else -> AppPrefs.segments.coerceIn(6, 8)
        }
        val chunkSize = when {
            workers == 1 -> total
            total < 16L * 1024 * 1024 -> maxOf(512 * 1024L, (total + workers * 3 - 1) / (workers * 3))
            else -> maxOf(2L * 1024 * 1024, (total + 255) / 256)
        }
        val n = ((total + chunkSize - 1) / chunkSize).toInt().coerceAtLeast(1)
        val starts = LongArray(n) { it.toLong() * chunkSize }
        ends = LongArray(n) { min(total - 1, (it.toLong() + 1L) * chunkSize - 1L) }
        pos = AtomicLongArray(n)
        val meta = File(dir, "meta.json")

        // Reprise éventuelle
        var resumed = false
        if (out.exists() && out.length() == total && meta.exists()) {
            try {
                val o = JSONObject(meta.readText())
                val arr = o.getJSONArray("pos")
                if (o.getLong("total") == total && o.getInt("n") == n && arr.length() == n) {
                    for (i in 0 until n) pos.set(i, arr.getLong(i).coerceIn(starts[i], ends[i] + 1))
                    resumed = true
                }
            } catch (_: Exception) {
            }
        }
        if (!resumed) {
            out.delete()
            for (i in 0 until n) pos.set(i, starts[i])
        }
        var already = 0L
        for (i in 0 until n) already += pos.get(i) - starts[i]
        downloaded.set(already)

        RandomAccessFile(out, "rw").use { raf ->
            if (raf.length() != total) raf.setLength(total)
            channel = raf.channel
            val nextChunk = AtomicInteger(0)
            coroutineScope {
                val ticker = launchTicker({ downloaded.get() }, { total }, listener)
                val saver = launch(Dispatchers.IO) {
                    while (isActive) {
                        delay(1000)
                        saveMeta(meta, total)
                    }
                }
                try {
                    (0 until workers).map {
                        async(Dispatchers.IO) {
                            while (true) {
                                val i = nextChunk.getAndIncrement()
                                if (i >= n) break
                                if (pos.get(i) <= ends[i]) {
                                    downloadSegment(i)
                                }
                            }
                        }
                    }.awaitAll()
                } finally {
                    ticker.cancel()
                    saver.cancel()
                    saveMeta(meta, total)
                }
            }
        }
        meta.delete()
    }

    private fun saveMeta(meta: File, total: Long) {
        try {
            val arr = JSONArray()
            for (i in 0 until pos.length()) arr.put(pos.get(i))
            meta.writeText(JSONObject().put("total", total).put("n", pos.length()).put("pos", arr).toString())
        } catch (_: Exception) {
        }
    }

    private suspend fun downloadSegment(i: Int) {
        var failures = 0
        val readBuf = ByteArray(64 * 1024)
        val writeBuf = ByteArray(256 * 1024)

        while (pos.get(i) <= ends[i]) {
            currentCoroutineContext().ensureActive()
            var buffered = 0

            fun flushWriteBuf() {
                if (buffered <= 0) return
                val bb = ByteBuffer.wrap(writeBuf, 0, buffered)
                var p = pos.get(i)
                while (bb.hasRemaining()) p += channel.write(bb, p)
                pos.set(i, p)
                downloaded.addAndGet(buffered.toLong())
                buffered = 0
            }

            try {
                val c = Http.connect(
                    item.url, item.userAgent, item.referer, item.cookies,
                    "bytes=${pos.get(i)}-${ends[i]}", reg
                )
                try {
                    if (c.responseCode != 206) throw IOException("HTTP ${c.responseCode} (Range non respecté)")
                    c.inputStream.use { input ->
                        while (true) {
                            val r = input.read(readBuf)
                            if (r < 0) break
                            val remaining = ends[i] - pos.get(i) - buffered + 1
                            val len = min(r.toLong(), remaining).toInt()
                            if (len <= 0) break
                            var offset = 0
                            while (offset < len) {
                                val space = writeBuf.size - buffered
                                val copy = min(space, len - offset)
                                System.arraycopy(readBuf, offset, writeBuf, buffered, copy)
                                buffered += copy
                                offset += copy
                                if (buffered == writeBuf.size) {
                                    flushWriteBuf()
                                }
                            }
                            currentCoroutineContext().ensureActive()
                        }
                        flushWriteBuf()
                    }
                } finally {
                    runCatching { c.disconnect() }
                    reg.remove(c)
                }
                if (pos.get(i) <= ends[i]) throw IOException("Flux interrompu prématurément")
            } catch (e: IOException) {
                if (reg.aborted) throw CancellationException("aborted")
                failures++
                if (failures >= 6) throw e
                delay(400L * failures)
            }
        }
    }

    /** Repli : serveur sans support Range -> flux unique (sans reprise). */
    private suspend fun single(out: File) {
        out.delete()
        try {
            val c = Http.connect(item.url, item.userAgent, item.referer, item.cookies, null, reg)
            try {
                if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
                val total = c.contentLengthLong
                val got = AtomicLong(0)
                coroutineScope {
                    val ticker = launchTicker({ got.get() }, { total }, listener)
                    try {
                        c.inputStream.use { input ->
                            out.outputStream().buffered(256 * 1024).use { o ->
                                val buf = ByteArray(128 * 1024)
                                while (true) {
                                    val r = input.read(buf)
                                    if (r < 0) break
                                    o.write(buf, 0, r)
                                    got.addAndGet(r.toLong())
                                    ensureActive()
                                }
                            }
                        }
                    } finally {
                        ticker.cancel()
                    }
                }
            } finally {
                runCatching { c.disconnect() }
                reg.remove(c)
            }
        } catch (e: IOException) {
            if (reg.aborted) throw CancellationException("aborted")
            throw e
        }
    }
}