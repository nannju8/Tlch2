package com.vidgrab.app.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vidgrab.app.data.DetectedVideo
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.util.UUID

/** Filtre anti-publicité et anti-redirection partagé avec VideoSniffer. */
internal object AdFilter {

    private val AD_HOST_KEYWORDS = listOf(
        "doubleclick",
        "googlesyndication",
        "googleadservices",
        "popads",
        "popcash",
        "propellerads",
        "propellerclick",
        "exoclick",
        "exosrv",
        "adsterra",
        "comnyanticipatedfragile",
        "wayfarerorthodox",
        "preferencenoticeable",
        "detrimentalstammer",
        "lasciviousstaircase",
        "tsyndicate",
        "realsrv",
        "juicyads",
        "trafficjunky",
        "clickadu",
        "hilltopads",
        "admaven",
        "monetag",
        "onclickads",
        "onclkds",
        "adspyglass",
        "profitablecpmrate",
        "highperformanceformat",
        "topcreativeformat",
        "effectivegatecpm",
        "betteradsystem",
        "magsrv",
        "wpadmngr",
        "adcash",
        "acscdn",
        "adskeeper",
        "revcontent",
        "infolinks",
        "richpush",
        "pushame",
        "popunderjs",
        "poperblocker",
        "ero-advertising",
        "bidswitch",
        "pubmatic",
        "rubiconproject",
        "smartadserver",
        "casalemedia",
        "criteo",
        "taboola",
        "outbrain",
        "mgid",
        "adnxs"
    )

    private val AD_EXACT_HOSTS = listOf(
        "2mdn.net",
        "vdo.ai",
        "propu.sh",
        "openx.net",
        "ad-delivery.net",
        "ads-twitter.com",
        "serving-sys.com",
        "moatads.com",
        "doubleverify.com",
        "demdex.net",
        "omtrdc.net",
        "scorecardresearch.com",
        "quantserve.com",
        "mc.yandex.ru",
        "setupad.com",
        "ezoic.net",
        "bidgear.com"
    )

    private val AD_PATH_PATTERNS = listOf(
        "/afu.php",
        "/popunder",
        "/pop.js",
        "/pu.js",
        "/adframe",
        "/adserver",
        "/pagead/",
        "adservice.google"
    )

    private val SUSPICIOUS_QUERY_KEYS = setOf(
        "zoneid",
        "zone_id",
        "clickid",
        "click_id",
        "subid",
        "sub_id",
        "ymid",
        "tid",
        "banner_id",
        "campaign_id",
        "ad_id",
        "aff_id",
        "visitor_id",
        "pop"
    )

    private val SUSPICIOUS_TLDS = setOf(
        "cfd", "sbs", "click", "icu", "buzz", "top", "cyou", "monster", "rest", "quest", "work"
    )

    private val MULTI_PART_SUFFIXES = setOf(
        "co.uk", "org.uk", "com.br", "net.br", "com.au", "co.jp",
        "com.tr", "com.mx", "co.in", "com.ar", "co.za"
    )

    private val SEARCH_ENGINES = listOf(
        "google.", "bing.com", "duckduckgo.com", "yahoo.com",
        "qwant.com", "ecosia.org", "startpage.com", "brave.com", "yandex."
    )

    private val STREAMING_PATH_HINTS = listOf(
        "/anime", "/episode", "/watch", "/film", "/serie",
        "/streaming", "/lecteur", "/player", "/embed", "/vf", "/vostfr"
    )

    fun isAdUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (AD_PATH_PATTERNS.any { lower.contains(it) }) return true
        val host = runCatching { Uri.parse(lower).host }.getOrNull() ?: return false
        return isAdHost(host)
    }

    fun isAdHost(host: String?): Boolean {
        val h = host?.lowercase()?.trimEnd('.') ?: return false
        if (h.isEmpty()) return false
        if (AD_EXACT_HOSTS.any { h == it || h.endsWith(".$it") }) return true
        if (AD_HOST_KEYWORDS.any { h.contains(it) }) return true
        return false
    }

    fun rootDomain(host: String?): String? {
        val clean = host?.lowercase()?.trimEnd('.')?.removePrefix("www.") ?: return null
        if (clean.isEmpty()) return null
        val parts = clean.split('.').filter { it.isNotEmpty() }
        if (parts.size <= 2) return clean
        val lastTwo = "${parts[parts.lastIndex - 1]}.${parts.last()}"
        return if (lastTwo in MULTI_PART_SUFFIXES && parts.size >= 3) {
            parts.takeLast(3).joinToString(".")
        } else {
            lastTwo
        }
    }

    fun sameRootDomain(hostA: String?, hostB: String?): Boolean {
        val a = rootDomain(hostA) ?: return false
        val b = rootDomain(hostB) ?: return false
        return a == b
    }

    fun isSearchEngine(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return SEARCH_ENGINES.any { h == it || h.contains(".$it") || h.startsWith(it) }
    }

    fun looksLikeStreamingPage(uri: Uri?): Boolean {
        val path = uri?.path?.lowercase() ?: return false
        return STREAMING_PATH_HINTS.any { path.contains(it) }
    }

    fun isSuspiciousExternalRedirect(target: Uri, current: Uri?): Boolean {
        val targetHost = target.host?.lowercase() ?: return false
        val currentHost = current?.host?.lowercase()
        if (sameRootDomain(targetHost, currentHost)) return false

        val queryNames = runCatching { target.queryParameterNames }.getOrNull().orEmpty()
        if (queryNames.any { it.lowercase() in SUSPICIOUS_QUERY_KEYS }) return true

        val tld = targetHost.substringAfterLast('.', "")
        if (tld in SUSPICIOUS_TLDS) return true

        val mainLabel = rootDomain(targetHost)?.substringBefore('.') ?: ""
        if (mainLabel.length >= 18 && !mainLabel.contains('-')) return true

        val path = target.path.orEmpty()
        if (path.length >= 48 && !path.contains('-')) return true

        return false
    }
}

/** État observable d'un onglet. */
class TabState(val id: String = UUID.randomUUID().toString()) {
    var title by mutableStateOf("Nouvel onglet")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var showHome by mutableStateOf(true)
    var canGoBack by mutableStateOf(false)
    val detected = mutableStateListOf<DetectedVideo>()

    var webView: WebView? = null
    var sniffer: VideoSniffer? = null

    @Volatile
    internal var currentUrl: String = ""

    @Volatile
    internal var currentTitle: String = "Nouvel onglet"

    @Volatile
    internal var pendingAddressNavUntilMs: Long = 0L

    @Volatile
    internal var hasPlayerContent: Boolean = false

    @Volatile
    internal var lastRealLinkHref: String? = null

    @Volatile
    internal var lastRealLinkTimeMs: Long = 0L

    internal var shieldInjectedProgress: Int = 0
}

/** Gère la liste d'onglets et la création des WebView (une par onglet). */
class TabManager(private val app: Context, private val onVisit: (String) -> Unit) {

    companion object {
        private const val JS_BRIDGE_NAME = "__vgShield"

        private val ANTI_AD_SHIELD_JS = """
            (function() {
                try {
                    window.open = function() { return null; };
                } catch (e) {}

                function isHiddenOverlay(el) {
                    if (!el || el.nodeType !== 1) return false;
                    var tag = el.tagName;
                    if (tag === 'HTML' || tag === 'BODY' || tag === 'VIDEO' || tag === 'SELECT' || tag === 'OPTION' || tag === 'INPUT' || tag === 'BUTTON') {
                        return false;
                    }
                    var style = window.getComputedStyle(el);
                    if (!style) return false;
                    var pos = style.position;
                    if (pos !== 'fixed' && pos !== 'absolute') return false;

                    var rect = el.getBoundingClientRect();
                    if (rect.width < 150 || rect.height < 120) return false;

                    var z = parseInt(style.zIndex, 10);
                    if (isNaN(z)) z = 0;

                    var isTransparent = style.opacity === '0' ||
                        style.visibility === 'hidden' ||
                        style.backgroundColor === 'transparent' ||
                        style.backgroundColor === 'rgba(0, 0, 0, 0)';

                    if (!isTransparent) return false;

                    var text = (el.innerText || '').replace(/[\s\u200B-\u200D\uFEFF]/g, '');
                    if (text.length > 0) return false;
                    if (el.querySelector('video, select, input, button, textarea, canvas, iframe')) return false;

                    var imgs = el.querySelectorAll('img');
                    for (var j = 0; j < imgs.length; j++) {
                        var ir = imgs[j].getBoundingClientRect();
                        if (ir.width > 16 && ir.height > 16) return false;
                    }

                    if (tag === 'A') {
                        return z >= 1 || (rect.width >= window.innerWidth * 0.5 && rect.height >= window.innerHeight * 0.5);
                    }

                    var coversScreen = rect.width >= window.innerWidth * 0.6 && rect.height >= window.innerHeight * 0.6;
                    return (coversScreen && z >= 999) || z >= 50000;
                }

                function reportVideoElement(el) {
                    try {
                        if (!el || el.tagName !== 'VIDEO') return;
                        var src = el.currentSrc || el.src || '';
                        if (!src && el.querySelector) {
                            var s = el.querySelector('source[src]');
                            if (s) src = s.src || '';
                        }
                        if (src && src.indexOf('http') === 0 && src.indexOf('blob:') !== 0) {
                            if (window.$JS_BRIDGE_NAME && window.$JS_BRIDGE_NAME.onVideoSrc) {
                                var pageHref = (el.ownerDocument && el.ownerDocument.location && el.ownerDocument.location.href)
                                    ? el.ownerDocument.location.href
                                    : window.location.href;
                                window.$JS_BRIDGE_NAME.onVideoSrc(src, pageHref);
                            }
                        }
                    } catch (err) {}
                }

                function scanVideos(doc) {
                    try {
                        if (!doc || !doc.querySelectorAll) return;
                        var vids = doc.querySelectorAll('video');
                        for (var k = 0; k < vids.length; k++) {
                            reportVideoElement(vids[k]);
                        }
                    } catch (err) {}
                }

                function hookVideoListeners(doc) {
                    try {
                        if (!doc || doc.__vgVideoHooked) return;
                        doc.__vgVideoHooked = true;
                        doc.addEventListener('loadedmetadata', function(e) {
                            reportVideoElement(e.target);
                        }, true);
                        doc.addEventListener('play', function(e) {
                            reportVideoElement(e.target);
                        }, true);
                    } catch (err) {}
                }

                function sweepOverlays() {
                    try {
                        var candidates = document.querySelectorAll('a, div, span, ins');
                        for (var i = 0; i < candidates.length; i++) {
                            var el = candidates[i];
                            if (el.getAttribute('data-vg-neutralized') === '1') continue;
                            if (isHiddenOverlay(el)) {
                                el.style.setProperty('pointer-events', 'none', 'important');
                                el.style.setProperty('display', 'none', 'important');
                                el.setAttribute('data-vg-neutralized', '1');
                            }
                        }
                        if (document.querySelector('video, select, iframe[src*="embed"], iframe[src*="player"], iframe[src*="video"]')) {
                            if (window.$JS_BRIDGE_NAME && window.$JS_BRIDGE_NAME.markHasPlayer) {
                                window.$JS_BRIDGE_NAME.markHasPlayer();
                            }
                        }
                        scanVideos(document);
                        var iframes = document.querySelectorAll('iframe');
                        for (var f = 0; f < iframes.length; f++) {
                            try {
                                var idoc = iframes[f].contentDocument;
                                if (idoc) {
                                    hookVideoListeners(idoc);
                                    scanVideos(idoc);
                                }
                            } catch (ce) {}
                        }
                    } catch (e) {}
                }

                hookVideoListeners(document);
                sweepOverlays();

                if (!window.__vgShieldInstalled) {
                    window.__vgShieldInstalled = true;

                    var notifyLink = function(e) {
                        try {
                            var target = e.target;
                            if (!target || !target.closest) return;
                            var a = target.closest('a[href]');
                            if (!a) return;
                            if (isHiddenOverlay(a)) {
                                a.style.setProperty('pointer-events', 'none', 'important');
                                a.style.setProperty('display', 'none', 'important');
                                return;
                            }
                            var href = a.href || '';
                            if (href.indexOf('http') === 0 && window.$JS_BRIDGE_NAME && window.$JS_BRIDGE_NAME.onLinkTap) {
                                window.$JS_BRIDGE_NAME.onLinkTap(href);
                            }
                        } catch (err) {}
                    };

                    document.addEventListener('touchstart', notifyLink, true);
                    document.addEventListener('click', notifyLink, true);

                    try {
                        var timer = null;
                        var observer = new MutationObserver(function() {
                            if (timer) return;
                            timer = setTimeout(function() {
                                timer = null;
                                sweepOverlays();
                            }, 250);
                        });
                        if (document.documentElement) {
                            observer.observe(document.documentElement, { childList: true, subtree: true });
                        }
                    } catch (e) {}
                }
            })();
        """.trimIndent()
    }

    private class AdShieldBridge(private val tab: TabState) {
        @Keep
        @JavascriptInterface
        fun onLinkTap(href: String?) {
            if (!href.isNullOrBlank()) {
                tab.lastRealLinkHref = href
                tab.lastRealLinkTimeMs = System.currentTimeMillis()
            }
        }

        @Keep
        @JavascriptInterface
        fun markHasPlayer() {
            tab.hasPlayerContent = true
        }

        @Keep
        @JavascriptInterface
        fun onVideoSrc(src: String?, pageHref: String?) {
            if (!src.isNullOrBlank()) {
                tab.sniffer?.reportVideoSrc(src, pageHref?.takeIf { it.isNotBlank() } ?: tab.currentUrl)
            }
        }
    }

    val tabs = mutableStateListOf<TabState>()
    var currentId by mutableStateOf("")

    /** Vue plein écran demandée par le lecteur HTML5 (onShowCustomView). */
    var customView by mutableStateOf<View?>(null)
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    init {
        newTab()
    }

    val current: TabState
        get() = tabs.firstOrNull { it.id == currentId } ?: tabs.first()

    fun newTab(select: Boolean = true): TabState {
        val t = TabState()
        tabs.add(t)
        if (select) currentId = t.id
        return t
    }

    fun select(id: String) {
        currentId = id
    }

    fun closeTab(id: String) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val t = tabs[idx]
        t.sniffer?.shutdown()
        t.webView?.let {
            runCatching {
                it.removeJavascriptInterface(JS_BRIDGE_NAME)
                it.stopLoading()
                it.destroy()
            }
        }
        tabs.removeAt(idx)
        if (tabs.isEmpty()) newTab()
        else if (currentId == id) currentId = tabs[minOf(idx, tabs.lastIndex)].id
    }

    fun closeAll() {
        tabs.toList().forEach { closeTab(it.id) }
    }

    fun hideCustomView() {
        val cb = customCallback
        customCallback = null
        customView = null
        cb?.onCustomViewHidden()
    }

    fun normalize(input: String): String {
        val s = input.trim()
        return when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            !s.contains(' ') && s.contains('.') -> "https://$s"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        }
    }

    fun navigate(tab: TabState, input: String) {
        if (input.isBlank()) return
        val target = normalize(input)
        val wv = tab.webView ?: createWebView(tab).also { tab.webView = it }
        tab.showHome = false
        tab.url = target
        tab.currentUrl = target
        tab.detected.clear()
        tab.pendingAddressNavUntilMs = System.currentTimeMillis() + 5000L
        tab.hasPlayerContent = false
        tab.lastRealLinkHref = null
        tab.lastRealLinkTimeMs = 0L
        tab.shieldInjectedProgress = 0
        wv.loadUrl(target)
    }

    private fun emptyBlockedResponse(url: String): WebResourceResponse {
        val path = runCatching { Uri.parse(url).path?.lowercase() }.getOrNull().orEmpty()
        val mime = if (path.endsWith(".js")) "application/javascript" else "text/plain"
        return WebResourceResponse(mime, "utf-8", ByteArrayInputStream(ByteArray(0)))
    }

    private fun findActivity(ctx: Context?): Activity? {
        var c = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return c as? Activity
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: TabState): WebView {
        val wv = WebView(app)
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        val sniffer = VideoSniffer(tab, wv.settings.userAgentString)
        tab.sniffer = sniffer
        wv.addJavascriptInterface(AdShieldBridge(tab), JS_BRIDGE_NAME)

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request != null) {
                    val reqUrl = request.url?.toString().orEmpty()
                    if (!request.isForMainFrame && AdFilter.isAdUrl(reqUrl)) {
                        return emptyBlockedResponse(reqUrl)
                    }
                    if (request.method.equals("GET", ignoreCase = true)) {
                        val headers = request.requestHeaders ?: emptyMap()
                        if (!request.isForMainFrame || VideoSniffer.looksLikeDirectVideoUrl(reqUrl)) {
                            sniffer.inspect(reqUrl, headers, tab.currentUrl)
                        }
                    }
                }
                return null // on laisse le WebView charger la requête normalement
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val req = request ?: return false
                val uri = req.url ?: return false
                val scheme = uri.scheme?.lowercase()
                if (scheme != "http" && scheme != "https" && scheme != "about") {
                    return true
                }
                if (scheme == "about") return false

                val targetUrl = uri.toString()
                if (AdFilter.isAdUrl(targetUrl)) {
                    return true
                }

                // Laisser les sous-requêtes/iframes légitimes (lecteurs intégrés) se charger
                if (!req.isForMainFrame) {
                    return false
                }

                val currentUri = runCatching { Uri.parse(tab.currentUrl) }.getOrNull()
                val currentHost = currentUri?.host?.lowercase()
                val targetHost = uri.host?.lowercase()

                if (currentHost.isNullOrBlank() || targetHost.isNullOrBlank()) {
                    return false
                }

                // Navigation sur le même domaine racine : autorisée
                if (AdFilter.sameRootDomain(currentHost, targetHost)) {
                    return false
                }

                // Moteur de recherche : autoriser le clic vers les résultats
                if (AdFilter.isSearchEngine(currentHost)) {
                    return false
                }

                val now = System.currentTimeMillis()
                // Redirection HTTP initiale juste après saisie dans la barre d'adresse
                if (now <= tab.pendingAddressNavUntilMs && req.isRedirect) {
                    return false
                }

                // Bloquer les redirections automatiques (sans geste) ou rebonds HTTP externes
                if (!req.hasGesture() || req.isRedirect) {
                    return true
                }

                // Bloquer les redirections externes vers un domaine/URL suspect
                if (AdFilter.isSuspiciousExternalRedirect(uri, currentUri)) {
                    return true
                }

                // Sur une page contenant un lecteur/streaming, bloquer toute redirection externe
                // qui ne vient pas d'un vrai clic sur un lien <a> visible
                val tappedRealLink = (now - tab.lastRealLinkTimeMs) <= 2000L &&
                    AdFilter.sameRootDomain(
                        runCatching { Uri.parse(tab.lastRealLinkHref ?: "").host?.lowercase() }.getOrNull(),
                        targetHost
                    )
                if ((tab.hasPlayerContent || tab.detected.isNotEmpty() || AdFilter.looksLikeStreamingPage(currentUri)) &&
                    !tappedRealLink
                ) {
                    return true
                }

                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.loading = true
                tab.progress = 5
                if (url != null) {
                    tab.url = url
                    tab.currentUrl = url
                }
                tab.detected.clear()
                sniffer.reset()
                tab.canGoBack = view?.canGoBack() == true
                tab.hasPlayerContent = false
                tab.lastRealLinkHref = null
                tab.lastRealLinkTimeMs = 0L
                tab.shieldInjectedProgress = 0
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                tab.pendingAddressNavUntilMs = 0L
                if (url != null) {
                    tab.url = url
                    tab.currentUrl = url
                }
                tab.canGoBack = view?.canGoBack() == true
                val t = view?.title
                if (!t.isNullOrBlank()) {
                    tab.title = t
                    tab.currentTitle = t
                }
                view?.evaluateJavascript(ANTI_AD_SHIELD_JS, null)
                url?.let { u -> Uri.parse(u).host?.let(onVisit) }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) {
                    tab.url = url
                    tab.currentUrl = url
                }
                tab.canGoBack = view?.canGoBack() == true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                tab.loading = newProgress < 100
                if (view != null && newProgress >= 30 && tab.shieldInjectedProgress < 30) {
                    tab.shieldInjectedProgress = newProgress
                    view.evaluateJavascript(ANTI_AD_SHIELD_JS, null)
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) {
                    tab.title = title
                    tab.currentTitle = title
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                // Bloquer silencieusement toute tentative de pop-up / nouvel onglet publicitaire
                return false
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                if (AdFilter.isAdUrl(url)) {
                    result?.cancel()
                    return true
                }
                val activity = findActivity(view?.context)
                if (activity == null || activity.isFinishing || activity.isDestroyed) {
                    result?.confirm()
                    return true
                }
                var handled = false
                AlertDialog.Builder(activity)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        if (!handled) {
                            handled = true
                            result?.confirm()
                        }
                    }
                    .setOnCancelListener {
                        if (!handled) {
                            handled = true
                            result?.cancel()
                        }
                    }
                    .setOnDismissListener {
                        if (!handled) {
                            handled = true
                            result?.cancel()
                        }
                    }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                if (AdFilter.isAdUrl(url)) {
                    result?.cancel()
                    return true
                }
                val activity = findActivity(view?.context)
                if (activity == null || activity.isFinishing || activity.isDestroyed) {
                    result?.confirm()
                    return true
                }
                var handled = false
                AlertDialog.Builder(activity)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        if (!handled) {
                            handled = true
                            result?.confirm()
                        }
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ ->
                        if (!handled) {
                            handled = true
                            result?.cancel()
                        }
                    }
                    .setOnCancelListener {
                        if (!handled) {
                            handled = true
                            result?.cancel()
                        }
                    }
                    .setOnDismissListener {
                        if (!handled) {
                            handled = true
                            result?.cancel()
                        }
                    }
                    .show()
                return true
            }

            override fun onJsBeforeUnload(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                result?.confirm()
                return true
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                customView = view
                customCallback = callback
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        wv.setDownloadListener { url, _, _, mimetype, contentLength ->
            sniffer.reportDownload(url, mimetype, contentLength, tab.currentUrl)
        }
        return wv
    }
}