package com.vidgrab.app.browser

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vidgrab.app.data.DetectedVideo
import java.net.URLEncoder
import java.util.UUID

/** État observable d'un onglet. */
class TabState(val id: String = UUID.randomUUID().toString()) {
    var title by mutableStateOf("Nouvel onglet")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var showHome by mutableStateOf(true)
    var canGoBack by mutableStateOf(false)
    val detected = mutableStateListOf<DetectedVideo>()

    var webView: WebView? = null
    var sniffer: VideoSniffer? = null
}

/** Gère la liste d'onglets et la création des WebView (une par onglet). */
class TabManager(private val app: Context, private val onVisit: (String) -> Unit) {

    val tabs = mutableStateListOf<TabState>()
    var currentId by mutableStateOf("")

    /** Vue plein écran demandée par le lecteur HTML5 (onShowCustomView). */
    var customView by mutableStateOf<View?>(null)
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    init {
        newTab()
    }

    val current: TabState
        get() = tabs.firstOrNull { it.id == currentId } ?: tabs.first()

    fun newTab(select: Boolean = true): TabState {
        val t = TabState()
        tabs.add(t)
        if (select) currentId = t.id
        return t
    }

    fun select(id: String) {
        currentId = id
    }

    fun closeTab(id: String) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val t = tabs[idx]
        t.sniffer?.shutdown()
        t.webView?.let { runCatching { it.stopLoading(); it.destroy() } }
        tabs.removeAt(idx)
        if (tabs.isEmpty()) newTab()
        else if (currentId == id) currentId = tabs[minOf(idx, tabs.lastIndex)].id
    }

    fun closeAll() {
        tabs.toList().forEach { closeTab(it.id) }
    }

    fun hideCustomView() {
        val cb = customCallback
        customCallback = null
        customView = null
        cb?.onCustomViewHidden()
    }

    fun normalize(input: String): String {
        val s = input.trim()
        return when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            !s.contains(' ') && s.contains('.') -> "https://$s"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        }
    }

    fun navigate(tab: TabState, input: String) {
        if (input.isBlank()) return
        val target = normalize(input)
        val wv = tab.webView ?: createWebView(tab).also { tab.webView = it }
        tab.showHome = false
        tab.url = target
        tab.detected.clear()
        wv.loadUrl(target)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: TabState): WebView {
        val wv = WebView(app)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        val sniffer = VideoSniffer(tab, wv.settings.userAgentString)
        tab.sniffer = sniffer

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request != null && request.method == "GET" && !request.isForMainFrame) {
                    sniffer.inspect(request.url.toString(), request.requestHeaders ?: emptyMap(), tab.url)
                }
                return null // on laisse le WebView charger la requête normalement
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme
                return scheme != "http" && scheme != "https" && scheme != "about"
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                tab.loading = true
                tab.progress = 5
                if (url != null) tab.url = url
                tab.detected.clear()
                sniffer.reset()
                tab.canGoBack = view?.canGoBack() == true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                if (url != null) tab.url = url
                tab.canGoBack = view?.canGoBack() == true
                val t = view?.title
                if (!t.isNullOrBlank()) tab.title = t
                url?.let { u -> Uri.parse(u).host?.let(onVisit) }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) tab.url = url
                tab.canGoBack = view?.canGoBack() == true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                tab.loading = newProgress < 100
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) tab.title = title
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                customView = view
                customCallback = callback
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        wv.setDownloadListener { url, _, _, mimetype, contentLength ->
            sniffer.reportDownload(url, mimetype, contentLength, tab.url)
        }
        return wv
    }
}
