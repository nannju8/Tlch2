package com.vidgrab.app

import android.app.Application
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.download.DownloadWatchdogWorker
import com.vidgrab.app.download.Notifs
import com.vidgrab.app.storage.LibraryStore

class VidGrabApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppPrefs.init(this)
        Notifs.ensureChannels(this)
        LibraryStore.init(this)
        DownloadCenter.init(this)
        DownloadWatchdogWorker.schedule(this)
    }
}
