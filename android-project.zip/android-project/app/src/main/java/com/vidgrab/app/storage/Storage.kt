package com.vidgrab.app.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import androidx.core.content.FileProvider
import com.vidgrab.app.data.LibraryVideo
import java.io.File
import java.util.UUID

/** Accès au stockage : MediaStore (Movies/VidGrab) + coffre privé interne masqué. */
object Storage {
    private const val RELATIVE_DIR = "Movies/VidGrab"

    fun sanitize(name: String): String =
        name.replace(Regex("""[\\/:*?"<>|\r\n\t]"""), "_").trim().take(100).ifBlank { "video" }

    fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "ts" -> "video/mp2t"
        else -> "video/mp4"
    }

    fun vaultDir(ctx: Context): File {
        val dir = File(ctx.filesDir, ".vault")
        if (!dir.exists()) {
            dir.mkdirs()
            runCatching { File(dir, ".nomedia").createNewFile() }
        }
        return dir
    }

    /** Copie un fichier temporaire dans Movies/VidGrab via MediaStore. */
    fun saveToMovies(ctx: Context, src: File, displayName: String, ext: String): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, mimeFor(ext))
            put(MediaStore.Video.Media.RELATIVE_PATH, RELATIVE_DIR)
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Impossible de créer l'entrée MediaStore")
        try {
            resolver.openOutputStream(uri)!!.use { out ->
                src.inputStream().use { it.copyTo(out, 256 * 1024) }
            }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }

    fun duration(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            runCatching { r.release() }
        }
    }

    fun exists(ctx: Context, v: LibraryVideo): Boolean = try {
        if (v.isPrivate) File(v.uri.path ?: "").exists()
        else ctx.contentResolver.query(v.uri, arrayOf(MediaStore.Video.Media._ID), null, null, null)
            ?.use { it.moveToFirst() } == true
    } catch (e: Exception) {
        false
    }

    /** Déplace une vidéo publique vers le coffre privé (copie + suppression de l'original). */
    fun moveToPrivate(ctx: Context, v: LibraryVideo): LibraryVideo? {
        val dest = File(vaultDir(ctx), "${UUID.randomUUID()}.${v.ext}")
        return try {
            ctx.contentResolver.openInputStream(v.uri)!!.use { ins ->
                dest.outputStream().use { ins.copyTo(it, 256 * 1024) }
            }
            ctx.contentResolver.delete(v.uri, null, null)
            v.copy(uriString = Uri.fromFile(dest).toString(), isPrivate = true)
        } catch (e: Exception) {
            dest.delete()
            null
        }
    }

    /** Sort une vidéo du coffre et la republie dans Movies/VidGrab. */
    fun moveToPublic(ctx: Context, v: LibraryVideo): LibraryVideo? {
        val file = File(v.uri.path ?: return null)
        return try {
            val uri = saveToMovies(ctx, file, "${v.title}.${v.ext}", v.ext)
            file.delete()
            v.copy(uriString = uri.toString(), isPrivate = false)
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, v: LibraryVideo) {
        try {
            if (v.isPrivate) File(v.uri.path ?: "").delete()
            else ctx.contentResolver.delete(v.uri, null, null)
        } catch (_: Exception) {
        }
    }

    fun rename(ctx: Context, v: LibraryVideo, newTitle: String): LibraryVideo {
        val title = sanitize(newTitle)
        if (!v.isPrivate) {
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "$title.${v.ext}")
                }
                ctx.contentResolver.update(v.uri, cv, null, null)
            } catch (_: Exception) {
            }
        }
        return v.copy(title = title)
    }

    fun share(ctx: Context, v: LibraryVideo) {
        val uri = if (v.isPrivate)
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(v.uri.path ?: return))
        else v.uri
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mimeFor(v.ext)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Partager la vidéo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Cache mémoire de miniatures vidéo. */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(48)

    fun get(id: String): Bitmap? = cache.get(id)

    fun load(ctx: Context, v: LibraryVideo): Bitmap? {
        cache.get(v.id)?.let { return it }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, v.uri)
            val bmp = r.getScaledFrameAtTime(
                1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 360, 202
            )
            if (bmp != null) cache.put(v.id, bmp)
            bmp
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }
}
