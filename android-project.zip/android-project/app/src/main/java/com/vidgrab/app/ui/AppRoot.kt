package com.vidgrab.app.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import com.vidgrab.app.MainViewModel

/** Racine : barre de navigation inférieure à 3 onglets + overlays. */
@Composable
fun AppRoot(vm: MainViewModel) {
    val downloads by vm.downloads.collectAsState()
    val activeCount = downloads.count { it.isActive }
    val customView = vm.tabs.customView

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.White,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Blue,
                        selectedTextColor = Blue,
                        indicatorColor = BlueSoft
                    )
                    NavigationBarItem(
                        selected = vm.screen == 0,
                        onClick = { vm.screen = 0 },
                        icon = { Icon(Icons.Outlined.Layers, null) },
                        label = { Text("Onglet") },
                        colors = colors
                    )
                    NavigationBarItem(
                        selected = vm.screen == 1,
                        onClick = { vm.screen = 1 },
                        icon = {
                            BadgedBox(badge = {
                                if (activeCount > 0) Badge { Text(activeCount.toString()) }
                            }) { Icon(Icons.Outlined.Download, null) }
                        },
                        label = { Text("Progression") },
                        colors = colors
                    )
                    NavigationBarItem(
                        selected = vm.screen == 2,
                        onClick = { vm.screen = 2 },
                        icon = { Icon(Icons.Outlined.Folder, null) },
                        label = { Text("Terminé") },
                        colors = colors
                    )
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (vm.screen) {
                    0 -> if (vm.tabs.current.showHome) HomeScreen(vm) else WebScreen(vm)
                    1 -> ProgressScreen(vm)
                    else -> LibraryScreen(vm)
                }
            }
        }

        // Overlays
        if (vm.showTabs) TabsOverlay(vm)
        if (vm.showHelp) HelpDialog { vm.showHelp = false }
        if (vm.showSettings) SettingsDialog { vm.showSettings = false }
        if (vm.showSheet && vm.screen == 0) DetectedSheet(vm)

        // Lecteur HTML5 plein écran (onShowCustomView)
        if (customView != null) {
            BackHandler { vm.tabs.hideCustomView() }
            AndroidView(
                factory = { ctx -> FrameLayout(ctx).apply { setBackgroundColor(android.graphics.Color.BLACK) } },
                update = { frame ->
                    if (customView.parent !== frame) {
                        (customView.parent as? ViewGroup)?.removeView(customView)
                        frame.removeAllViews()
                        frame.addView(
                            customView,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier.fillMaxSize().background(Color.Black)
            )
        }
    }
}
