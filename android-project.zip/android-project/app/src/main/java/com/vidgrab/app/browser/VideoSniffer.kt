package com.vidgrab.app.browser

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.net.ConnectionRegistry
import com.vidgrab.app.net.HlsParser
import com.vidgrab.app.net.Http
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Sniffer réseau : analysé depuis WebViewClient.shouldInterceptRequest et via le pont JS <video>.
 *  - extensions d'URL directes (.mp4 .webm .mkv .mov .m4v .m3u8) + URLs sans extension ou masquées (.txt .png .js...)
 *  - transmission des en-têtes WebView (Referer, Origin, User-Agent, Cookie) lors des sondes et du téléchargement
 *  - inspection du Content-Type (video/, mpegurl, application/octet-stream >= 1 Mo) et des premiers octets (#EXTM3U / ftyp / EBML)
 *  - exclusion stricte de YouTube et des régies publicitaires
 */
class VideoSniffer(private val tab: TabState, private val userAgent: String) {

    companion object {
        val BLOCKED_HOSTS = listOf("youtube.com", "googlevideo.com", "youtu.be", "youtube-nocookie.com")
        private val DIRECT_EXT = setOf("mp4", "webm", "mkv", "mov", "m4v")
        private val HLS_EXT = setOf("m3u8", "m3u")
        private val NEVER_VIDEO_EXT = setOf(
            "css", "woff", "woff2", "ttf", "otf", "svg", "ico", "map",
            "vtt", "srt", "ts", "m4s", "aac", "mp3", "avif"
        )
        private val GENERIC_EXT = setOf("txt", "php", "bin", "dat", "asp", "aspx", "do")
        private val DISGUISED_IMAGE_EXT = setOf("png", "jpg", "jpeg", "webp", "gif")
        private val DISGUISED_SCRIPT_EXT = setOf("js", "json", "html", "htm", "xml")
        private val HINTS = listOf(
            "video", "mime=video", "mpegurl", "m3u8", "m3u", "/media/", "playback",
            "manifest", "stream", "master", "index", "playlist", "chunklist",
            "hls", "vod", "source", "clip"
        )
        private val TRACKING_PATH_HINTS = listOf(
            "/favicon", "/analytics", "/pixel", "/beacon", "/telemetry",
            "/collect", "/ping", "/metrics", "/heartbeat", "/csp-report"
        )
        private val SEGMENT_URL_HINTS = listOf(
            "/seg", "seg-", "seg_", "segment", "chunk-", "chunk_", "frag-", "init."
        )
        private const val MIN_SIZE = 150L * 1024
        private const val OCTET_STREAM_MIN_SIZE = 1024L * 1024L

        fun isBlocked(host: String?): Boolean {
            val h = host?.lowercase() ?: return false
            return BLOCKED_HOSTS.any { h == it || h.endsWith(".$it") } || AdFilter.isAdHost(h)
        }

        internal fun looksLikeDirectVideoUrl(url: String): Boolean {
            if (!url.startsWith("http", ignoreCase = true)) return false
            val path = runCatching { Uri.parse(url).path?.lowercase() }.getOrNull().orEmpty()
            val lastSeg = path.substringAfterLast('/', "")
            val ext = if (lastSeg.contains('.')) lastSeg.substringAfterLast('.', "") else ""
            return ext in DIRECT_EXT || ext in HLS_EXT
        }
    }

    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val variantUrls = ConcurrentHashMap.newKeySet<String>()
    private val probeExec = Executors.newFixedThreadPool(4)
    private val hlsExec = Executors.newSingleThreadExecutor() // séquentiel : master avant variantes
    private val main = Handler(Looper.getMainLooper())

    fun reset() {
        seen.clear()
        variantUrls.clear()
    }

    fun shutdown() {
        probeExec.shutdownNow()
        hlsExec.shutdownNow()
    }

    /** Appelé depuis un thread d'arrière-plan (shouldInterceptRequest). */
    fun inspect(url: String, headers: Map<String, String>, pageUrl: String?) {
        if (!url.startsWith("http", ignoreCase = true)) return

        val reqReferer = headerIgnoreCase(headers, "Referer")
        val reqOrigin = headerIgnoreCase(headers, "Origin")
        val reqUa = headerIgnoreCase(headers, "User-Agent") ?: userAgent
        val reqCookies = headerIgnoreCase(headers, "Cookie")
        val effectiveReferer = reqReferer ?: reqOrigin ?: pageUrl

        if (AdFilter.isAdUrl(url) || AdFilter.isAdUrl(effectiveReferer) || AdFilter.isAdUrl(pageUrl)) return
        val uri = Uri.parse(url)
        if (isBlocked(uri.host) ||
            isBlocked(runCatching { Uri.parse(effectiveReferer ?: "").host }.getOrNull()) ||
            isBlocked(runCatching { Uri.parse(pageUrl ?: "").host }.getOrNull())
        ) return

        val path = (uri.path ?: "").lowercase()
        val lastSeg = path.substringAfterLast('/', "")
        val ext = if (lastSeg.contains('.')) lastSeg.substringAfterLast('.', "") else ""
        if (ext in NEVER_VIDEO_EXT) return

        val hasRange = headerIgnoreCase(headers, "Range") != null
        val secFetchDest = headerIgnoreCase(headers, "Sec-Fetch-Dest")?.lowercase().orEmpty()
        val accept = headerIgnoreCase(headers, "Accept")?.lowercase().orEmpty()

        val urlHasHint = HINTS.any { url.contains(it, ignoreCase = true) }
        val isDirectExt = ext in DIRECT_EXT
        val isHlsExt = ext in HLS_EXT
        val isGenericOrNoExt = ext.isEmpty() || ext in GENERIC_EXT
        val isDisguisedImg = ext in DISGUISED_IMAGE_EXT
        val isDisguisedScript = ext in DISGUISED_SCRIPT_EXT
        val isBlockedBySecDest = secFetchDest in setOf("style", "font", "script", "image", "document")
        val isVideoHeader = secFetchDest == "video" || accept.contains("video/")
        val isXhrOrFetch = secFetchDest == "empty" || accept == "*/*"

        val shouldProbe = when {
            isHlsExt -> true
            isDirectExt -> true
            hasRange -> true
            isVideoHeader -> true
            urlHasHint && !isBlockedBySecDest -> true
            isGenericOrNoExt && !isBlockedBySecDest && !isLikelyTrackingPath(path) -> true
            isDisguisedImg && !isBlockedBySecDest && (urlHasHint || isXhrOrFetch) -> true
            isDisguisedScript && !isBlockedBySecDest && (urlHasHint || secFetchDest == "empty") -> true
            else -> false
        }
        if (!shouldProbe) return
        if (!seen.add(url)) return

        if (isHlsExt) {
            hlsExec.execute { handleHls(url, effectiveReferer, reqUa, reqOrigin, reqCookies) }
        } else {
            probeExec.execute {
                handleProbe(
                    url = url,
                    referer = effectiveReferer,
                    ext = ext,
                    forced = isDirectExt,
                    effectiveUa = reqUa,
                    origin = reqOrigin,
                    requestCookies = reqCookies
                )
            }
        }
    }

    /** Appelé par le pont JS (<video> loadedmetadata / play) en filet de sécurité. */
    fun reportVideoSrc(url: String?, pageUrl: String?) {
        if (url.isNullOrBlank() || !url.startsWith("http", ignoreCase = true)) return
        if (AdFilter.isAdUrl(url) || AdFilter.isAdUrl(pageUrl)) return
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return
        if (isBlocked(uri.host) || isBlocked(runCatching { Uri.parse(pageUrl ?: "").host }.getOrNull())) return
        if (!seen.add(url)) return

        val path = (uri.path ?: "").lowercase()
        val lastSeg = path.substringAfterLast('/', "")
        val ext = if (lastSeg.contains('.')) lastSeg.substringAfterLast('.', "") else ""
        if (ext in HLS_EXT) {
            hlsExec.execute { handleHls(url, pageUrl, userAgent, null, null) }
        } else {
            probeExec.execute {
                handleProbe(
                    url = url,
                    referer = pageUrl,
                    ext = ext,
                    forced = true,
                    effectiveUa = userAgent,
                    origin = null,
                    requestCookies = null
                )
            }
        }
    }

    /** Appelé par le DownloadListener du WebView (liens de téléchargement directs). */
    fun reportDownload(url: String, mime: String?, length: Long, pageUrl: String?) {
        if (AdFilter.isAdUrl(url) || isBlocked(Uri.parse(url).host)) return
        val m = mime?.lowercase() ?: ""
        if (!m.startsWith("video/") && !m.contains("mpegurl") && !m.contains("octet-stream")) return
        if (m.contains("octet-stream") && length in 1 until OCTET_STREAM_MIN_SIZE) return
        if (!seen.add(url)) return
        if (m.contains("mpegurl")) {
            hlsExec.execute { handleHls(url, pageUrl, userAgent, null, null) }
        } else {
            probeExec.execute {
                handleProbe(
                    url = url,
                    referer = pageUrl,
                    ext = extFromMime(m),
                    forced = true,
                    effectiveUa = userAgent,
                    origin = null,
                    requestCookies = null,
                    knownSize = length
                )
            }
        }
    }

    // ------------------------------------------------------------------ sonde HTTP

    private class Probe(
        val contentType: String?,
        val size: Long,
        val isHls: Boolean,
        val peek: ByteArray
    )

    private fun headerIgnoreCase(headers: Map<String, String>, name: String): String? {
        headers[name]?.let { if (it.isNotBlank()) return it }
        return headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }
            ?.value?.takeIf { it.isNotBlank() }
    }

    private fun cookiesFor(url: String): String? = try {
        CookieManager.getInstance().getCookie(url)
    } catch (_: Exception) {
        null
    }

    private fun mergeCookies(managerCookies: String?, headerCookies: String?): String? {
        val m = managerCookies?.trim()?.takeIf { it.isNotEmpty() }
        val h = headerCookies?.trim()?.takeIf { it.isNotEmpty() }
        return when {
            m == null -> h
            h == null -> m
            m == h -> m
            else -> "$m; $h"
        }
    }

    private fun isLikelyTrackingPath(path: String): Boolean {
        return TRACKING_PATH_HINTS.any { path.contains(it) }
    }

    private fun looksLikeSegmentUrl(url: String): Boolean {
        val lower = url.lowercase()
        return SEGMENT_URL_HINTS.any { lower.contains(it) }
    }

    private fun probe(
        url: String,
        referer: String?,
        effectiveUa: String,
        origin: String?,
        cookies: String?
    ): Probe? {
        val first = runProbeConnection(url, referer, effectiveUa, null, cookies, "bytes=0-1023")
        if (first != null) return first

        // Certains serveurs refusent l'en-tête Range ou exigent Origin
        return runProbeConnection(url, referer, effectiveUa, origin, cookies, null)
    }

    private fun runProbeConnection(
        url: String,
        referer: String?,
        effectiveUa: String,
        origin: String?,
        cookies: String?,
        range: String?
    ): Probe? {
        val reg = ConnectionRegistry()
        var conn: HttpURLConnection? = null
        return try {
            conn = if (origin.isNullOrBlank()) {
                Http.connect(url, effectiveUa, referer, cookies, range, reg)
            } else {
                openWithOrigin(url, effectiveUa, referer, origin, cookies, range)
            }
            var code = conn.responseCode
            if ((code == 401 || code == 403) && origin != null) {
                runCatching { conn.disconnect() }
                conn = openWithOrigin(url, effectiveUa, referer, origin, cookies, range)
                code = conn.responseCode
            }
            if (code !in 200..299) return null

            val ct = conn.contentType?.lowercase()?.substringBefore(';')?.trim()
            val totalSize = conn.getHeaderField("Content-Range")
                ?.substringAfter('/')?.trim()?.toLongOrNull()?.takeIf { it > 0 }
                ?: conn.contentLengthLong

            if (ct != null && (ct.contains("mpegurl") || ct.contains("m3u8") || ct.contains("m3u"))) {
                return Probe(ct, totalSize, isHls = true, peek = ByteArray(0))
            }

            val shouldPeek = ct == null ||
                ct.startsWith("text/") ||
                ct.contains("octet-stream") ||
                ct.contains("javascript") ||
                ct.contains("json") ||
                ct.contains("xml") ||
                ct.contains("html") ||
                ct.startsWith("image/") ||
                ct.startsWith("application/")

            val peek = if (shouldPeek) readPrefix(conn, 512) else ByteArray(0)
            val isHlsMagic = startsWithExtM3u(peek)
            Probe(ct, totalSize, isHls = isHlsMagic, peek = peek)
        } catch (_: Exception) {
            null
        } finally {
            conn?.let { runCatching { it.disconnect() } }
        }
    }

    private fun openWithOrigin(
        url: String,
        userAgent: String,
        referer: String?,
        origin: String?,
        cookies: String?,
        range: String?
    ): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", userAgent)
            setRequestProperty("Accept", "*/*")
            if (!referer.isNullOrBlank()) setRequestProperty("Referer", referer)
            if (!origin.isNullOrBlank()) setRequestProperty("Origin", origin)
            if (!cookies.isNullOrBlank()) setRequestProperty("Cookie", cookies)
            if (!range.isNullOrBlank()) setRequestProperty("Range", range)
        }
    }

    private fun readPrefix(conn: HttpURLConnection, maxBytes: Int): ByteArray {
        val stream = runCatching { conn.inputStream }.getOrNull() ?: return ByteArray(0)
        val out = ByteArrayOutputStream(maxBytes)
        val buf = ByteArray(maxBytes)
        return try {
            var remaining = maxBytes
            while (remaining > 0) {
                val r = stream.read(buf, 0, remaining)
                if (r <= 0) break
                out.write(buf, 0, r)
                remaining -= r
            }
            out.toByteArray()
        } catch (_: Exception) {
            out.toByteArray()
        } finally {
            runCatching { stream.close() }
        }
    }

    private fun startsWithExtM3u(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        var idx = 0
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()
        ) {
            idx = 3
        }
        while (idx < bytes.size) {
            val b = bytes[idx].toInt() and 0xFF
            if (b == ' '.code || b == '\t'.code || b == '\r'.code || b == '\n'.code) idx++ else break
        }
        if (bytes.size - idx < 7) return false
        val header = String(bytes, idx, 7, Charsets.US_ASCII)
        return header.equals("#EXTM3U", ignoreCase = true)
    }

    private fun isMpegTsSegment(bytes: ByteArray): Boolean {
        return bytes.size >= 189 && bytes[0] == 0x47.toByte() && bytes[188] == 0x47.toByte()
    }

    private fun containerExtFromMagic(bytes: ByteArray): String? {
        if (bytes.size >= 8 &&
            bytes[4] == 'f'.code.toByte() &&
            bytes[5] == 't'.code.toByte() &&
            bytes[6] == 'y'.code.toByte() &&
            bytes[7] == 'p'.code.toByte()
        ) {
            return "mp4"
        }
        if (bytes.size >= 4 &&
            bytes[0] == 0x1A.toByte() &&
            bytes[1] == 0x45.toByte() &&
            bytes[2] == 0xDF.toByte() &&
            bytes[3] == 0xA3.toByte()
        ) {
            val text = String(bytes, Charsets.ISO_8859_1).lowercase()
            return if (text.contains("webm")) "webm" else "mkv"
        }
        return null
    }

    private fun extFromMime(ct: String): String = when {
        ct.contains("webm") -> "webm"
        ct.contains("matroska") -> "mkv"
        else -> "mp4"
    }

    private fun normalizeDirectExt(ext: String): String = when (ext) {
        "m4v", "mov" -> "mp4"
        in DIRECT_EXT -> ext
        else -> "mp4"
    }

    private fun handleProbe(
        url: String,
        referer: String?,
        ext: String,
        forced: Boolean,
        effectiveUa: String,
        origin: String?,
        requestCookies: String?,
        knownSize: Long = -1L
    ) {
        val cookies = mergeCookies(cookiesFor(url), requestCookies)
        val p = probe(url, referer, effectiveUa, origin, cookies)
        if (p?.isHls == true) {
            hlsExec.execute { handleHls(url, referer, effectiveUa, origin, requestCookies) }
            return
        }
        if (p == null && !forced) return
        if (p != null && isMpegTsSegment(p.peek)) return

        val ct = p?.contentType
        val magicExt = p?.peek?.let { containerExtFromMagic(it) }
        val size = p?.size?.takeIf { it > 0 } ?: knownSize

        if (forced) {
            if (magicExt == null && ct != null && (
                    ct.startsWith("audio/") || ct.contains("mp2t") || ct.startsWith("text/") ||
                        ct.contains("html") || ct.contains("json") || ct.startsWith("image/")
                    )
            ) return
        } else {
            val isVideoMime = ct != null && ct.startsWith("video/") && !ct.contains("mp2t") && !ct.contains("iso.segment")
            val isLargeOctetStream = ct != null &&
                ct.contains("octet-stream") &&
                size >= OCTET_STREAM_MIN_SIZE &&
                !looksLikeSegmentUrl(url)
            val isMagicVideo = magicExt != null && (size < 0 || size >= MIN_SIZE)
            if (!isVideoMime && !isLargeOctetStream && !isMagicVideo) return
        }

        if (size in 1 until MIN_SIZE) return
        val e = when {
            ext in DIRECT_EXT -> normalizeDirectExt(ext)
            magicExt != null -> magicExt
            else -> extFromMime(ct ?: "")
        }

        publish(
            DetectedVideo(
                id = "d" + url.hashCode().toString(16),
                url = url,
                pageUrl = referer,
                title = tab.title,
                kind = VideoKind.DIRECT,
                ext = e,
                label = e.uppercase(),
                sizeBytes = size,
                durationSec = 0.0,
                height = 0,
                userAgent = effectiveUa,
                cookies = cookies
            )
        )
    }

    // ------------------------------------------------------------------ HLS

    private fun qualityLabel(height: Int, bandwidth: Long): String = when {
        height > 0 -> "${height}p"
        bandwidth > 0 -> "${bandwidth / 1000} kbps"
        else -> "Auto"
    }

    private fun fetchHlsText(
        url: String,
        effectiveUa: String,
        referer: String?,
        origin: String?,
        cookies: String?
    ): String? {
        val text = Http.fetchText(url, effectiveUa, referer, cookies)
        if (text != null) return text
        if (origin.isNullOrBlank()) return null
        var conn: HttpURLConnection? = null
        return try {
            conn = openWithOrigin(url, effectiveUa, referer, origin, cookies, null)
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            conn?.let { runCatching { it.disconnect() } }
        }
    }

    private fun handleHls(
        url: String,
        referer: String?,
        effectiveUa: String,
        origin: String?,
        requestCookies: String?
    ) {
        val cookies = mergeCookies(cookiesFor(url), requestCookies)
        val text = fetchHlsText(url, effectiveUa, referer, origin, cookies) ?: return
        if (HlsParser.isMaster(text)) {
            val variants = HlsParser.parseMaster(text, url)
                .sortedByDescending { it.height * 1_000_000L + it.bandwidth }
            if (variants.isEmpty()) return
            variants.forEach { variantUrls.add(it.url) }

            val firstUrl = variants.first().url
            val firstText = fetchHlsText(firstUrl, effectiveUa, referer, origin, cookies)
            val duration: Double = if (firstText != null) {
                HlsParser.parseMedia(firstText, firstUrl).totalDuration
            } else {
                0.0
            }

            for (v in variants) {
                val estimatedSize = if (duration > 0.0 && v.bandwidth > 0L) {
                    ((v.bandwidth.toDouble() * duration) / 8.0).toLong()
                } else {
                    -1L
                }
                publish(
                    DetectedVideo(
                        id = "h" + v.url.hashCode().toString(16),
                        url = v.url,
                        pageUrl = referer,
                        title = tab.title,
                        kind = VideoKind.HLS,
                        ext = "mp4",
                        label = qualityLabel(v.height, v.bandwidth),
                        sizeBytes = estimatedSize,
                        durationSec = duration,
                        height = v.height,
                        userAgent = effectiveUa,
                        cookies = cookies
                    )
                )
            }
        } else if (text.contains("#EXTINF")) {
            if (url in variantUrls) return
            val pl = HlsParser.parseMedia(text, url)
            if (pl.segments.isEmpty()) return
            publish(
                DetectedVideo(
                    id = "h" + url.hashCode().toString(16),
                    url = url,
                    pageUrl = referer,
                    title = tab.title,
                    kind = VideoKind.HLS,
                    ext = "mp4",
                    label = "HLS",
                    sizeBytes = -1L,
                    durationSec = pl.totalDuration,
                    height = 0,
                    userAgent = effectiveUa,
                    cookies = cookies
                )
            )
        }
    }

    private fun publish(v: DetectedVideo) {
        main.post {
            if (tab.detected.none { it.id == v.id }) tab.detected.add(v)
        }
    }
}