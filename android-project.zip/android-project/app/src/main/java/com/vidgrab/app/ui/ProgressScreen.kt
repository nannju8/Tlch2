package com.vidgrab.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.MainViewModel
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.data.DownloadState
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.util.Fmt

/** Écran 2 : téléchargements en cours. */
@Composable
fun ProgressScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val items by vm.downloads.collectAsState()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("PROGRESSION") {
            IconButton(onClick = { sendFeedback(ctx) }) { Icon(Icons.Outlined.Feedback, "Feedback") }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (items.isEmpty()) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier.size(120.dp).clip(CircleShape).background(Orange.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Inbox, null, tint = Orange, modifier = Modifier.size(72.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Aucun historique", color = GrayInactive, fontSize = 16.sp)
                }
            } else {
                LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(items, key = { it.id }) { d -> DownloadCard(d) }
                }
            }
        }

        HowToButton(
            onClick = { vm.showHelp = true },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
        )
    }
}

@Composable
private fun DownloadCard(d: DownloadItem) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFFE0E3E7), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                d.title,
                modifier = Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium
            )
            when (d.state) {
                DownloadState.RUNNING, DownloadState.QUEUED ->
                    IconButton(onClick = { DownloadCenter.pause(d.id) }) { Icon(Icons.Outlined.Pause, "Pause") }
                DownloadState.PAUSED ->
                    IconButton(onClick = { DownloadCenter.resume(d.id) }) { Icon(Icons.Outlined.PlayArrow, "Reprendre") }
                DownloadState.FAILED ->
                    IconButton(onClick = { DownloadCenter.resume(d.id) }) { Icon(Icons.Outlined.Refresh, "Réessayer") }
                DownloadState.MERGING -> Unit
            }
            IconButton(onClick = { DownloadCenter.cancel(d.id) }) { Icon(Icons.Outlined.Close, "Annuler") }
        }
        Spacer(Modifier.height(6.dp))

        val indeterminate = d.state == DownloadState.MERGING ||
            (d.state == DownloadState.RUNNING && d.total <= 0)
        if (indeterminate) {
            LinearProgressIndicator(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Blue)
        } else {
            LinearProgressIndicator(
                progress = { d.progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = if (d.state == DownloadState.PAUSED) GrayInactive else Blue,
                trackColor = GraySearch
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val sizeText = if (d.total > 0) "${Fmt.bytes(d.downloaded)} / ${Fmt.bytes(d.total)}"
            else Fmt.bytes(d.downloaded)
            Text(sizeText, fontSize = 12.sp, color = Color(0xFF5F6368), modifier = Modifier.weight(1f))
            val status = when (d.state) {
                DownloadState.RUNNING -> "${Fmt.speed(d.speedBps)}" + if (d.total > 0) " • ${(d.progress * 100).toInt()} %" else ""
                DownloadState.QUEUED -> "En attente"
                DownloadState.PAUSED -> "En pause"
                DownloadState.MERGING -> "Finalisation…"
                DownloadState.FAILED -> "Échec : ${d.error ?: "erreur réseau"}"
            }
            Text(
                status,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (d.state == DownloadState.FAILED) Red else Blue,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

fun sendFeedback(ctx: Context) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        putExtra(Intent.EXTRA_EMAIL, arrayOf("feedback@vidgrab.app"))
        putExtra(Intent.EXTRA_SUBJECT, "Retour sur VidGrab")
    }
    runCatching { ctx.startActivity(intent) }
}
