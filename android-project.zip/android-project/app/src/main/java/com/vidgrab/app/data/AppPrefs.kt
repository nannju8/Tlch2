package com.vidgrab.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Préférences persistantes (SharedPreferences). */
object AppPrefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("vidgrab_prefs", Context.MODE_PRIVATE)
    }

    /** Nombre de segments parallèles par fichier (4 à 8). */
    var segments: Int
        get() = sp.getInt("segments", 8).coerceIn(4, 8)
        set(value) {
            sp.edit().putInt("segments", value.coerceIn(4, 8)).apply()
        }

    /** Hash SHA-256 du code PIN du dossier privé. */
    var pinHash: String?
        get() = sp.getString("pin_hash", null)
        set(value) {
            sp.edit().putString("pin_hash", value).apply()
        }

    fun getString(key: String): String? = sp.getString(key, null)

    fun putString(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun recentSites(): List<String> {
        val arr = JSONArray(sp.getString("recent_sites", "[]"))
        return List(arr.length()) { arr.getString(it) }
    }

    fun saveRecentSites(list: List<String>) {
        sp.edit().putString("recent_sites", JSONArray(list).toString()).apply()
    }
}
