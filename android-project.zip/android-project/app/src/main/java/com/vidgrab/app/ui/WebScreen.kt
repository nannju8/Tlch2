package com.vidgrab.app.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.vidgrab.app.MainViewModel
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.util.Fmt

/** Écran 1B : navigation web active. */
@Composable
fun WebScreen(vm: MainViewModel) {
    val tab = vm.tabs.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val clipboard = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    var field by remember(tab.id, tab.url) { mutableStateOf(tab.url) }

    BackHandler {
        val wv = tab.webView
        if (wv != null && wv.canGoBack()) wv.goBack() else tab.showHome = true
    }
    DisposableEffect(tab.id) {
        tab.webView?.onResume()
        onDispose { tab.webView?.onPause() }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Barre supérieure
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.width(4.dp))
                TabCounter(vm.tabs.tabs.size) { vm.showTabs = true }
                IconButton(onClick = { tab.showHome = true }) { Icon(Icons.Outlined.Home, "Accueil") }
                Row(
                    Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(GraySearch)
                        .padding(start = 14.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = field,
                        onValueChange = { field = it },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = Ink),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                        keyboardActions = KeyboardActions(onGo = {
                            focus.clearFocus()
                            vm.tabs.navigate(tab, field)
                        }),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { if (tab.loading) tab.webView?.stopLoading() else field = "" },
                        modifier = Modifier.size(32.dp)
                    ) { Icon(Icons.Outlined.Close, "Effacer / arrêter", modifier = Modifier.size(18.dp)) }
                }
                IconButton(onClick = { feedback(ctx) }) { Icon(Icons.Outlined.Feedback, "Signaler") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "Menu") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Nouvel onglet") }, onClick = {
                            menu = false
                            vm.tabs.newTab()
                        })
                        DropdownMenuItem(text = { Text("Actualiser") }, onClick = {
                            menu = false
                            tab.webView?.reload()
                        })
                        DropdownMenuItem(text = { Text("Page suivante") }, onClick = {
                            menu = false
                            tab.webView?.let { if (it.canGoForward()) it.goForward() }
                        })
                        DropdownMenuItem(text = { Text("Copier le lien") }, onClick = {
                            menu = false
                            clipboard.setText(AnnotatedString(tab.url))
                            Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show()
                        })
                    }
                }
            }

            // Fine barre de progression bleue
            Box(Modifier.fillMaxWidth().height(3.dp)) {
                if (tab.loading) {
                    LinearProgressIndicator(
                        progress = { tab.progress / 100f },
                        modifier = Modifier.fillMaxSize(),
                        color = Blue,
                        trackColor = Color.Transparent
                    )
                }
            }

            // WebView plein écran
            AndroidView(
                factory = { c -> FrameLayout(c) },
                update = { frame ->
                    val wv = tab.webView
                    if (wv != null && wv.parent !== frame) {
                        (wv.parent as? ViewGroup)?.removeView(wv)
                        frame.removeAllViews()
                        frame.addView(
                            wv,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }

        DownloadFab(
            count = tab.detected.size,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            onClick = {
                if (tab.detected.isNotEmpty()) vm.showSheet = true
                else Toast.makeText(
                    ctx, "Aucune vidéo détectée. Lancez la lecture de la vidéo dans la page.", Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

private fun feedback(ctx: android.content.Context) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO).apply {
        data = android.net.Uri.parse("mailto:")
        putExtra(android.content.Intent.EXTRA_EMAIL, arrayOf("feedback@vidgrab.app"))
        putExtra(android.content.Intent.EXTRA_SUBJECT, "Retour sur VidGrab")
    }
    runCatching { ctx.startActivity(intent) }
}

/** FAB : gris inactif ; rouge pulsant avec badge quand une vidéo est détectée. */
@Composable
fun DownloadFab(count: Int, modifier: Modifier, onClick: () -> Unit) {
    val active = count > 0
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "scale"
    )
    Box(modifier) {
        FloatingActionButton(
            onClick = onClick,
            shape = CircleShape,
            containerColor = if (active) Red else GrayInactive,
            contentColor = Color.White,
            modifier = Modifier.scale(if (active) pulse else 1f)
        ) {
            Icon(Icons.Filled.Download, "Télécharger")
        }
        if (active) {
            Badge(Modifier.align(Alignment.TopEnd), containerColor = Blue, contentColor = Color.White) {
                Text(count.toString())
            }
        }
    }
}

/** Bottom sheet listant les vidéos détectées sur la page. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetectedSheet(vm: MainViewModel) {
    val ctx = LocalContext.current
    val tab = vm.tabs.current
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var started by remember { mutableStateOf(setOf<String>()) }

    ModalBottomSheet(onDismissRequest = { vm.showSheet = false }, sheetState = state) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Text(
                "Vidéos détectées (${tab.detected.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tab.detected.toList(), key = { it.id }) { v ->
                    DetectedRow(v, started = v.id in started) {
                        vm.download(v)
                        started = started + v.id
                        Toast.makeText(ctx, "Téléchargement ajouté à la file", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

@Composable
private fun DetectedRow(v: DetectedVideo, started: Boolean, onDownload: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(GraySearch)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Outlined.PlayCircle, null, tint = Blue, modifier = Modifier.size(36.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            val size = when {
                v.sizeBytes > 0 -> (if (v.kind == VideoKind.HLS) "≈ " else "") + Fmt.bytes(v.sizeBytes)
                else -> "Taille inconnue"
            }
            val dur = if (v.durationSec > 0) " • " + Fmt.duration((v.durationSec * 1000).toLong()) else ""
            Text(
                "${v.label}${if (v.kind == VideoKind.HLS) " (HLS)" else ""} • $size$dur",
                fontSize = 12.sp,
                color = Color(0xFF5F6368)
            )
        }
        Spacer(Modifier.width(8.dp))
        Button(onClick = onDownload, enabled = !started) {
            Text(if (started) "Ajouté" else "Télécharger")
        }
    }
}
