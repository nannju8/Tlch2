package com.vidgrab.app.storage

import android.content.Context
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.LibraryVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** Index persistant des vidéos téléchargées (publiques et privées). */
object LibraryStore {
    private const val KEY = "library"
    private lateinit var app: Context
    private val _videos = MutableStateFlow<List<LibraryVideo>>(emptyList())
    val videos: StateFlow<List<LibraryVideo>> = _videos.asStateFlow()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val arr = JSONArray(AppPrefs.getString(KEY) ?: "[]")
        _videos.value = (0 until arr.length()).mapNotNull {
            runCatching { LibraryVideo.fromJson(arr.getJSONObject(it)) }.getOrNull()
        }
    }

    private fun persist() {
        AppPrefs.putString(KEY, JSONArray(_videos.value.map { it.toJson() }).toString())
    }

    fun add(v: LibraryVideo) {
        _videos.update { listOf(v) + it }
        persist()
    }

    fun replace(v: LibraryVideo) {
        _videos.update { list -> list.map { if (it.id == v.id) v else it } }
        persist()
    }

    fun remove(ids: Collection<String>) {
        _videos.update { list -> list.filter { it.id !in ids } }
        persist()
    }

    fun markSeen(id: String) {
        _videos.update { list -> list.map { if (it.id == id) it.copy(seen = true) else it } }
        persist()
    }

    /** Retire de l'index les fichiers supprimés depuis une autre application. */
    suspend fun refreshExistence() = withContext(Dispatchers.IO) {
        val current = _videos.value
        val alive = current.filter { Storage.exists(app, it) }
        if (alive.size != current.size) {
            _videos.value = alive
            persist()
        }
    }
}
