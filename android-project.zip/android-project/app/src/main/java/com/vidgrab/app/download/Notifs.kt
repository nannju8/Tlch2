package com.vidgrab.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.vidgrab.app.MainActivity
import com.vidgrab.app.R
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.data.DownloadState
import com.vidgrab.app.util.Fmt

object Notifs {
    const val CH_PROGRESS = "downloads_progress"
    const val CH_DONE = "downloads_done"
    const val ID_FOREGROUND = 1001

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Téléchargements en cours", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                description = "Progression en temps réel des téléchargements"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(ctx: Context): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(MainActivity.EXTRA_OPEN_PROGRESS, true)
        return PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun progress(ctx: Context, items: List<DownloadItem>): Notification {
        val active = items.filter { it.isActive }
        val speed = active.filter { it.state == DownloadState.RUNNING }.sumOf { it.speedBps }
        val known = active.filter { it.total > 0 }
        val totalSum = known.sumOf { it.total }
        val dl = known.sumOf { it.downloaded }
        val pct = if (totalSum > 0) (dl * 100 / totalSum).toInt().coerceIn(0, 100) else 0

        val title = when (active.size) {
            0 -> "VidGrab"
            1 -> active[0].title
            else -> "${active.size} téléchargements en cours"
        }
        val text = buildString {
            append(Fmt.speed(speed))
            if (totalSum > 0) append(" • $pct % • ${Fmt.bytes(dl)} / ${Fmt.bytes(totalSum)}")
        }
        val pause = PendingIntent.getService(
            ctx, 1,
            Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_PAUSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(ctx))
            .setProgress(100, pct, totalSum <= 0)
            .addAction(0, "Tout mettre en pause", pause)
            .build()
    }

    fun done(ctx: Context, title: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("Téléchargement terminé")
            .setContentText(title)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        runCatching {
            ctx.getSystemService(NotificationManager::class.java)
                .notify((System.nanoTime() and 0x7fffffff).toInt(), n)
        }
    }
}
