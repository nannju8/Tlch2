package com.vidgrab.app.download

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/**
 * Remux MPEG-TS -> MP4 avec Media3 Transformer (copie des flux H.264/H.265 + AAC, sans ré-encodage).
 * Alternative native et maintenue à FFmpegKit (projet archivé, binaires retirés de Maven Central).
 */
object Remuxer {
    @OptIn(UnstableApi::class)
    suspend fun tsToMp4(ctx: Context, input: File, output: File): Boolean =
        withContext(Dispatchers.Main) {
            output.delete()
            suspendCancellableCoroutine { cont ->
                val transformer = Transformer.Builder(ctx.applicationContext)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            if (cont.isActive) cont.resume(false)
                        }
                    })
                    .build()
                cont.invokeOnCancellation {
                    Handler(Looper.getMainLooper()).post { runCatching { transformer.cancel() } }
                }
                try {
                    val edited = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).build()
                    transformer.start(edited, output.absolutePath)
                } catch (e: Exception) {
                    if (cont.isActive) cont.resume(false)
                }
            }
        }
}
