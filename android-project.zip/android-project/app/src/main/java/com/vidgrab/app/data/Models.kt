package com.vidgrab.app.data

import android.net.Uri
import org.json.JSONObject

enum class VideoKind { DIRECT, HLS }

enum class DownloadState { QUEUED, RUNNING, PAUSED, MERGING, FAILED }

/** Vidéo détectée par le sniffer réseau pendant la navigation. */
data class DetectedVideo(
    val id: String,
    val url: String,
    val pageUrl: String?,
    val title: String,
    val kind: VideoKind,
    val ext: String,
    val label: String,
    val sizeBytes: Long,
    val durationSec: Double,
    val height: Int,
    val userAgent: String,
    val cookies: String?
)

/** Téléchargement en cours / en file d'attente. */
data class DownloadItem(
    val id: String,
    val title: String,
    val url: String,
    val kind: VideoKind,
    val ext: String,
    val referer: String?,
    val userAgent: String?,
    val cookies: String?,
    val state: DownloadState = DownloadState.QUEUED,
    val downloaded: Long = 0L,
    val total: Long = -1L,
    val speedBps: Long = 0L,
    val error: String? = null
) {
    val progress: Float
        get() = if (total > 0) (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f

    val isActive: Boolean
        get() = state == DownloadState.QUEUED || state == DownloadState.RUNNING || state == DownloadState.MERGING

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("url", url)
        put("kind", kind.name)
        put("ext", ext)
        referer?.let { put("referer", it) }
        userAgent?.let { put("ua", it) }
        cookies?.let { put("cookies", it) }
        put("state", state.name)
        put("total", total)
    }

    companion object {
        fun fromJson(o: JSONObject): DownloadItem = DownloadItem(
            id = o.getString("id"),
            title = o.getString("title"),
            url = o.getString("url"),
            kind = VideoKind.valueOf(o.getString("kind")),
            ext = o.getString("ext"),
            referer = o.optStr("referer"),
            userAgent = o.optStr("ua"),
            cookies = o.optStr("cookies"),
            state = DownloadState.valueOf(o.getString("state")),
            total = o.optLong("total", -1L)
        )
    }
}

/** Vidéo terminée présente dans la bibliothèque (publique via MediaStore, ou privée dans le coffre). */
data class LibraryVideo(
    val id: String,
    val title: String,
    val ext: String,
    val uriString: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val seen: Boolean,
    val isPrivate: Boolean,
    val addedAt: Long
) {
    val uri: Uri get() = Uri.parse(uriString)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("ext", ext)
        put("uri", uriString)
        put("size", sizeBytes)
        put("dur", durationMs)
        put("seen", seen)
        put("private", isPrivate)
        put("added", addedAt)
    }

    companion object {
        fun fromJson(o: JSONObject): LibraryVideo = LibraryVideo(
            id = o.getString("id"),
            title = o.getString("title"),
            ext = o.optString("ext", "mp4"),
            uriString = o.getString("uri"),
            sizeBytes = o.optLong("size"),
            durationMs = o.optLong("dur"),
            seen = o.optBoolean("seen"),
            isPrivate = o.optBoolean("private"),
            addedAt = o.optLong("added")
        )
    }
}

private fun JSONObject.optStr(key: String): String? = if (has(key) && !isNull(key)) getString(key) else null
