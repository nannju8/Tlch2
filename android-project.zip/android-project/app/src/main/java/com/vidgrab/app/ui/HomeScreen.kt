package com.vidgrab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardReturn
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.MainViewModel

private data class Shortcut(val name: String, val glyph: String, val url: String, val colors: List<Color>)

private val SHORTCUTS = listOf(
    Shortcut("Facebook", "f", "https://m.facebook.com", listOf(Color(0xFF1877F2), Color(0xFF4A9BFF))),
    Shortcut("Instagram", "◎", "https://www.instagram.com", listOf(Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF))),
    Shortcut("Vimeo", "V", "https://vimeo.com", listOf(Color(0xFF1AB7EA), Color(0xFF4FD0FF))),
    Shortcut("Dailymotion", "d", "https://www.dailymotion.com", listOf(Color(0xFF0066DC), Color(0xFF3C8DFF))),
    Shortcut("TikTok", "♪", "https://www.tiktok.com", listOf(Color(0xFF111111), Color(0xFF3A3A3A)))
)

/** Écran 1A : accueil du navigateur. */
@Composable
fun HomeScreen(vm: MainViewModel) {
    val tab = vm.tabs.current
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current

    fun go(text: String) {
        focus.clearFocus()
        vm.tabs.navigate(tab, text)
        query = ""
    }

    Column(Modifier.fillMaxSize()) {
        // Barre supérieure
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabCounter(vm.tabs.tabs.size) { vm.showTabs = true }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.showHelp = true }) { Icon(Icons.Outlined.HelpOutline, "Aide") }
            IconButton(onClick = { vm.showSettings = true }) { Icon(Icons.Outlined.Settings, "Paramètres") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "Menu") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Nouvel onglet") }, onClick = {
                        menu = false
                        vm.tabs.newTab()
                    })
                    DropdownMenuItem(text = { Text("Effacer les sites récents") }, onClick = {
                        menu = false
                        vm.clearRecent()
                    })
                    DropdownMenuItem(text = { Text("Paramètres") }, onClick = {
                        menu = false
                        vm.showSettings = true
                    })
                }
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(28.dp))

            // Zone de recherche
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Rechercher ou inscrire l'URL") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = GraySearch,
                    unfocusedContainerColor = GraySearch,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                trailingIcon = {
                    IconButton(onClick = { go(query) }) { Icon(Icons.Filled.KeyboardReturn, "Valider") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { go(query) }),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(36.dp))

            // Raccourcis rapides
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SHORTCUTS.forEach { s ->
                    SiteBubble(s.name, s.glyph, s.colors, onClick = { go(s.url) })
                }
            }

            Spacer(Modifier.height(40.dp))

            // Sites récents
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Sites web récemment utilisés",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                if (vm.recent.isNotEmpty()) {
                    IconButton(onClick = { vm.clearRecent() }) {
                        Icon(Icons.Outlined.DeleteOutline, "Tout effacer")
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (vm.recent.isEmpty()) {
                Text("Aucun site récent", color = GrayInactive, fontSize = 13.sp)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    vm.recent.take(5).forEach { host ->
                        SiteBubble(
                            label = host,
                            glyph = host.first().uppercase(),
                            colors = colorsForHost(host),
                            onClick = { go(host) },
                            onDelete = { vm.removeRecent(host) }
                        )
                    }
                }
                Text(
                    "Appui long sur une icône pour la supprimer",
                    color = GrayInactive,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(24.dp))
        }

        HowToButton(
            onClick = { vm.showHelp = true },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
        )
    }
}
