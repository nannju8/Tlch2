package com.vidgrab.app.util

import java.security.MessageDigest
import java.util.Locale

object Fmt {
    fun bytes(b: Long): String {
        if (b < 0) return "—"
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            b < kb -> "$b o"
            b < mb -> String.format(Locale.FRANCE, "%.0f Ko", b / kb)
            b < gb -> if (b < 10 * mb) String.format(Locale.FRANCE, "%.1f Mo", b / mb)
            else String.format(Locale.FRANCE, "%.0f Mo", b / mb)
            else -> String.format(Locale.FRANCE, "%.2f Go", b / gb)
        }
    }

    fun speed(bps: Long): String =
        String.format(Locale.FRANCE, "%.1f Mo/s", bps / (1024.0 * 1024.0))

    fun duration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
