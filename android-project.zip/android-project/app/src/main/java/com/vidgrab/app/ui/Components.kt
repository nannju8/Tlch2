package com.vidgrab.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Carré affichant le nombre d'onglets ouverts. */
@Composable
fun TabCounter(count: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier
            .size(34.dp)
            .clip(shape)
            .border(2.dp, Ink, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(count.toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink)
    }
}

/** Bouton pilule bleu clair « Comment télécharger ». */
@Composable
fun HowToButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(CircleShape)
            .background(BlueSoft)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.HelpOutline, null, tint = Blue)
        Spacer(Modifier.width(10.dp))
        Text("Comment télécharger", color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

/** En-tête d'écran : titre en majuscules + actions à droite. */
@Composable
fun ScreenHeader(title: String, actions: @Composable RowScope.() -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 20.sp,
            letterSpacing = 1.sp,
            color = Ink
        )
        actions()
    }
}

/** Icône circulaire (raccourci ou site récent). Appui long : menu optionnel. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SiteBubble(
    label: String,
    glyph: String,
    colors: List<Color>,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier
            .width(64.dp)
            .combinedClickable(onClick = onClick, onLongClick = { if (onDelete != null) menu = true }),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(colors)),
            contentAlignment = Alignment.Center
        ) {
            Text(glyph, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            color = Ink
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text("Supprimer de l'historique") },
                onClick = {
                    menu = false
                    onDelete?.invoke()
                }
            )
        }
    }
}

fun colorsForHost(host: String): List<Color> {
    val palette = listOf(
        listOf(Color(0xFF1A73E8), Color(0xFF4F9BFF)),
        listOf(Color(0xFFE53935), Color(0xFFFF7A70)),
        listOf(Color(0xFF00897B), Color(0xFF4DB6AC)),
        listOf(Color(0xFF8E24AA), Color(0xFFBA68C8)),
        listOf(Color(0xFFF57C00), Color(0xFFFFB74D)),
        listOf(Color(0xFF3949AB), Color(0xFF7986CB))
    )
    return palette[(host.hashCode() and 0x7fffffff) % palette.size]
}
