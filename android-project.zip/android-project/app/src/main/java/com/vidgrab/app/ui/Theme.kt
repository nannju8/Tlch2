package com.vidgrab.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF1A73E8)
val BlueSoft = Color(0xFFDCE8FD)
val GraySearch = Color(0xFFF1F3F4)
val GrayInactive = Color(0xFF9AA0A6)
val Orange = Color(0xFFFF8A1F)
val Red = Color(0xFFE53935)
val Ink = Color(0xFF202124)

@Composable
fun VidGrabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            primaryContainer = BlueSoft,
            onPrimaryContainer = Blue,
            background = Color.White,
            surface = Color.White,
            onSurface = Ink,
            surfaceVariant = GraySearch
        ),
        content = content
    )
}
