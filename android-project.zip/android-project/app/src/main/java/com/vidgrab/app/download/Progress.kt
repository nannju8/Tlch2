package com.vidgrab.app.download

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

interface ProgressListener {
    fun onProgress(downloaded: Long, total: Long, speedBps: Long)
    fun onMerging()
}

/**
 * Lance une coroutine qui mesure la vitesse (moyenne exponentielle) toutes les 500 ms
 * et notifie le listener. À annuler par l'appelant.
 */
fun CoroutineScope.launchTicker(
    bytes: () -> Long,
    total: () -> Long,
    listener: ProgressListener
): Job = launch {
    var last = bytes()
    var lastT = System.nanoTime()
    var ema = 0.0
    while (isActive) {
        delay(500)
        val now = System.nanoTime()
        val cur = bytes()
        val dt = (now - lastT).coerceAtLeast(1L)
        val inst = (cur - last) * 1e9 / dt
        ema = if (ema == 0.0) inst else ema * 0.6 + inst * 0.4
        last = cur
        lastT = now
        listener.onProgress(cur, total(), ema.toLong().coerceAtLeast(0L))
    }
}
