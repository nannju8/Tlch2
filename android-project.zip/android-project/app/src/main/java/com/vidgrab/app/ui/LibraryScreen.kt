package com.vidgrab.app.ui

import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Feedback
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.MainViewModel
import com.vidgrab.app.data.LibraryVideo
import com.vidgrab.app.storage.Storage
import com.vidgrab.app.storage.Thumbs
import com.vidgrab.app.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class LibAction { PLAY, RENAME, SHARE, MOVE, DELETE }

/** Écran 3 : bibliothèque des vidéos téléchargées (+ dossier privé protégé par PIN). */
@Composable
fun LibraryScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val all by vm.library.collectAsState()

    var inVault by remember { mutableStateOf(false) }
    var selecting by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }

    var pinCreate by remember { mutableStateOf<Boolean?>(null) } // null = fermé
    var pendingMove by remember { mutableStateOf<List<LibraryVideo>?>(null) }
    var renameTarget by remember { mutableStateOf<LibraryVideo?>(null) }
    var deleteTarget by remember { mutableStateOf<List<LibraryVideo>?>(null) }

    val list = all.filter { it.isPrivate == inVault }.sortedByDescending { it.addedAt }

    fun exitSelection() {
        selecting = false
        selected.clear()
    }

    BackHandler(enabled = selecting || inVault) {
        if (selecting) exitSelection() else inVault = false
    }

    fun play(v: LibraryVideo) {
        vm.markSeen(v.id)
        ctx.startActivity(
            Intent(ctx, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_URI, v.uriString)
                .putExtra(PlayerActivity.EXTRA_TITLE, v.title)
        )
    }

    fun requestMove(vids: List<LibraryVideo>) {
        if (vids.isEmpty()) return
        if (inVault) {
            vm.moveToPublic(vids) { n ->
                Toast.makeText(ctx, "$n vidéo(s) sorties du dossier privé", Toast.LENGTH_SHORT).show()
            }
        } else if (!vm.hasPin()) {
            pendingMove = vids
            pinCreate = true
        } else {
            vm.moveToPrivate(vids) { n ->
                Toast.makeText(ctx, "$n vidéo(s) déplacées vers le dossier privé", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // En-tête
        if (selecting) {
            ScreenHeader("${selected.size} SÉLECTIONNÉ(S)") {
                IconButton(onClick = { requestMove(list.filter { it.id in selected }); exitSelection() }) {
                    Icon(if (inVault) Icons.Outlined.LockOpen else Icons.Outlined.Lock, "Dossier privé")
                }
                IconButton(onClick = { deleteTarget = list.filter { it.id in selected } }) {
                    Icon(Icons.Outlined.Delete, "Supprimer")
                }
                IconButton(onClick = { exitSelection() }) { Icon(Icons.Outlined.Close, "Annuler") }
            }
        } else {
            ScreenHeader(if (inVault) "DOSSIER PRIVÉ" else "TERMINÉ") {
                if (inVault) {
                    IconButton(onClick = { inVault = false }) { Icon(Icons.Outlined.ArrowBack, "Retour") }
                } else {
                    IconButton(onClick = { sendFeedback(ctx) }) { Icon(Icons.Outlined.Feedback, "Feedback") }
                    IconButton(onClick = {
                        pinCreate = !vm.hasPin()
                    }) {
                        Box {
                            Icon(Icons.Outlined.Folder, "Dossier privé")
                            Icon(
                                Icons.Outlined.Lock, null,
                                modifier = Modifier.size(11.dp).align(Alignment.Center),
                                tint = Ink
                            )
                        }
                    }
                }
                IconButton(onClick = { selecting = true }) { Icon(Icons.Outlined.CheckBox, "Sélection multiple") }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (list.isEmpty()) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Outlined.VideoLibrary, null, tint = GrayInactive, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (inVault) "Le dossier privé est vide" else "Aucune vidéo téléchargée",
                        color = GrayInactive
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(list, key = { it.id }) { v ->
                        LibraryCard(
                            v = v,
                            selecting = selecting,
                            isSelected = v.id in selected,
                            inVault = inVault,
                            onClick = {
                                if (selecting) {
                                    if (v.id in selected) selected.remove(v.id) else selected.add(v.id)
                                } else play(v)
                            },
                            onAction = { a ->
                                when (a) {
                                    LibAction.PLAY -> play(v)
                                    LibAction.RENAME -> renameTarget = v
                                    LibAction.SHARE -> Storage.share(ctx, v)
                                    LibAction.MOVE -> requestMove(listOf(v))
                                    LibAction.DELETE -> deleteTarget = listOf(v)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // --- Dialogues ---
    pinCreate?.let { create ->
        PinDialog(
            create = create,
            onDismiss = {
                pinCreate = null
                pendingMove = null
            },
            onSubmit = { pin ->
                if (create) vm.setPin(pin)
                else if (!vm.checkPin(pin)) return@PinDialog false
                pinCreate = null
                val move = pendingMove
                pendingMove = null
                if (move != null) {
                    vm.moveToPrivate(move) { n ->
                        Toast.makeText(ctx, "$n vidéo(s) déplacées vers le dossier privé", Toast.LENGTH_SHORT).show()
                    }
                    exitSelection()
                } else {
                    inVault = true
                }
                true
            }
        )
    }

    renameTarget?.let { v ->
        var text by remember(v.id) { mutableStateOf(v.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Renommer") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = false, maxLines = 3)
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotBlank()) vm.rename(v, text)
                    renameTarget = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Annuler") } }
        )
    }

    deleteTarget?.let { vids ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Supprimer") },
            text = { Text("Supprimer définitivement ${vids.size} vidéo(s) ?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(vids)
                    deleteTarget = null
                    exitSelection()
                }) { Text("Supprimer", color = Red) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun LibraryCard(
    v: LibraryVideo,
    selecting: Boolean,
    isSelected: Boolean,
    inVault: Boolean,
    onClick: () -> Unit,
    onAction: (LibAction) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) {
            Checkbox(checked = isSelected, onCheckedChange = { onClick() })
        }
        VideoThumb(v)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                v.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Movie, null, modifier = Modifier.size(16.dp), tint = Color(0xFF5F6368))
                Spacer(Modifier.width(4.dp))
                Text(Fmt.bytes(v.sizeBytes), fontSize = 12.sp, color = Color(0xFF5F6368))
            }
        }
        if (!selecting) {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "Actions") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Lire") },
                        leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) },
                        onClick = { menu = false; onAction(LibAction.PLAY) })
                    DropdownMenuItem(
                        text = { Text("Renommer") },
                        leadingIcon = { Icon(Icons.Outlined.Edit, null) },
                        onClick = { menu = false; onAction(LibAction.RENAME) })
                    DropdownMenuItem(
                        text = { Text("Partager") },
                        leadingIcon = { Icon(Icons.Outlined.Share, null) },
                        onClick = { menu = false; onAction(LibAction.SHARE) })
                    DropdownMenuItem(
                        text = { Text(if (inVault) "Sortir du dossier privé" else "Déplacer vers le dossier privé") },
                        leadingIcon = { Icon(if (inVault) Icons.Outlined.LockOpen else Icons.Outlined.Lock, null) },
                        onClick = { menu = false; onAction(LibAction.MOVE) })
                    DropdownMenuItem(
                        text = { Text("Supprimer", color = Red) },
                        leadingIcon = { Icon(Icons.Outlined.Delete, null, tint = Red) },
                        onClick = { menu = false; onAction(LibAction.DELETE) })
                }
            }
        }
    }
}

/** Miniature avec point rouge (non vue) et badge de durée. */
@Composable
private fun VideoThumb(v: LibraryVideo) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(Thumbs.get(v.id), v.id) {
        if (value == null) value = withContext(Dispatchers.IO) { Thumbs.load(ctx, v) }
    }
    Box(
        Modifier
            .width(132.dp)
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF2B2B2B))
    ) {
        bmp?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        if (!v.seen) {
            Box(
                Modifier
                    .padding(6.dp)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Red)
                    .align(Alignment.TopStart)
            )
        }
        Text(
            Fmt.duration(v.durationMs),
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(5.dp)
                .background(Color.Black.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}
