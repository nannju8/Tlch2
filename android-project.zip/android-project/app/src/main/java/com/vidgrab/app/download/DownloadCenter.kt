package com.vidgrab.app.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.vidgrab.app.data.AppPrefs
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.DownloadItem
import com.vidgrab.app.data.DownloadState
import com.vidgrab.app.data.LibraryVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.net.ConnectionRegistry
import com.vidgrab.app.storage.LibraryStore
import com.vidgrab.app.storage.Storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Cerveau des téléchargements : file d'attente, exécution parallèle (2 fichiers max),
 * pause / reprise / annulation, persistance et publication dans la bibliothèque.
 * Le [DownloadService] ne sert qu'à garder le processus vivant (foreground + wake/wifi locks).
 */
object DownloadCenter {
    private const val KEY = "download_queue"
    private const val MAX_PARALLEL = 2

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val jobs = ConcurrentHashMap<String, Job>()
    private val registries = ConcurrentHashMap<String, ConnectionRegistry>()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val arr = JSONArray(AppPrefs.getString(KEY) ?: "[]")
        _items.value = (0 until arr.length()).mapNotNull {
            runCatching { DownloadItem.fromJson(arr.getJSONObject(it)) }.getOrNull()
        }.map {
            when (it.state) {
                DownloadState.RUNNING, DownloadState.MERGING -> it.copy(state = DownloadState.QUEUED)
                else -> it
            }
        }
    }

    private fun persist() {
        AppPrefs.putString(KEY, JSONArray(_items.value.map { it.toJson() }).toString())
    }

    private fun find(id: String) = _items.value.firstOrNull { it.id == id }

    private fun update(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    fun hasActive(): Boolean = _items.value.any { it.isActive }

    // ---------------------------------------------------------------- API publique

    fun enqueue(v: DetectedVideo) {
        if (_items.value.any { it.url == v.url }) return
        val title = Storage.sanitize(v.title.ifBlank { "video" }) +
            if (v.kind == VideoKind.HLS && v.label.isNotBlank()) " ${v.label}" else ""
        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            title = title,
            url = v.url,
            kind = v.kind,
            ext = v.ext,
            referer = v.pageUrl,
            userAgent = v.userAgent,
            cookies = v.cookies,
            total = v.sizeBytes
        )
        _items.update { it + item }
        persist()
        resumePending()
    }

    /** Démarre le service et lance les téléchargements en attente. */
    fun resumePending() {
        if (!hasActive()) return
        ensureService()
        schedule()
    }

    fun pause(id: String) {
        val it = find(id) ?: return
        if (it.state != DownloadState.RUNNING && it.state != DownloadState.QUEUED) return
        update(id) { d -> d.copy(state = DownloadState.PAUSED, speedBps = 0) }
        registries[id]?.abort()
        jobs[id]?.cancel()
        persist()
    }

    fun pauseAll() {
        _items.value.filter { it.state == DownloadState.RUNNING || it.state == DownloadState.QUEUED }
            .forEach { pause(it.id) }
    }

    fun resume(id: String) {
        val it = find(id) ?: return
        if (it.state != DownloadState.PAUSED && it.state != DownloadState.FAILED) return
        update(id) { d -> d.copy(state = DownloadState.QUEUED, error = null, speedBps = 0) }
        persist()
        resumePending()
    }

    fun cancel(id: String) {
        registries[id]?.abort()
        val job = jobs[id]
        job?.cancel()
        _items.update { list -> list.filter { it.id != id } }
        persist()
        scope.launch {
            job?.join()
            File(app.filesDir, "dl/$id").deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- ordonnanceur

    fun ensureService() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        } catch (_: Exception) {
            // Démarrage interdit en arrière-plan : le worker réessaiera.
        }
    }

    @Synchronized
    private fun schedule() {
        val running = _items.value.count { it.state == DownloadState.RUNNING || it.state == DownloadState.MERGING }
        var slots = MAX_PARALLEL - running
        for (item in _items.value.filter { it.state == DownloadState.QUEUED }) {
            if (slots <= 0) break
            start(item)
            slots--
        }
    }

    private fun start(item: DownloadItem) {
        update(item.id) { it.copy(state = DownloadState.RUNNING, error = null, speedBps = 0) }
        persist()
        val reg = ConnectionRegistry()
        registries[item.id] = reg
        val previous = jobs[item.id]
        val job = scope.launch(start = CoroutineStart.LAZY) {
            previous?.join()
            try {
                execute(item, reg)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                val st = find(item.id)?.state
                if (st == DownloadState.RUNNING || st == DownloadState.MERGING) {
                    update(item.id) {
                        it.copy(
                            state = DownloadState.FAILED,
                            speedBps = 0,
                            error = e.message ?: e.javaClass.simpleName
                        )
                    }
                    persist()
                }
            } finally {
                jobs.remove(item.id, coroutineContext[Job])
                registries.remove(item.id, reg)
                schedule()
            }
        }
        jobs[item.id] = job
        job.start()
    }

    private suspend fun execute(item: DownloadItem, reg: ConnectionRegistry) {
        val dir = File(app.filesDir, "dl/${item.id}")
        val listener = object : ProgressListener {
            override fun onProgress(downloaded: Long, total: Long, speedBps: Long) {
                update(item.id) {
                    if (it.state == DownloadState.RUNNING)
                        it.copy(downloaded = downloaded, total = if (total > 0) total else it.total, speedBps = speedBps)
                    else it
                }
            }

            override fun onMerging() {
                update(item.id) { it.copy(state = DownloadState.MERGING, speedBps = 0) }
            }
        }

        val file: File
        val ext: String
        when (item.kind) {
            VideoKind.DIRECT -> {
                file = DirectDownloader(item, dir, reg, listener).run()
                ext = item.ext
            }
            VideoKind.HLS -> {
                val r = HlsDownloader(app, item, dir, reg, listener).run()
                file = r.file
                ext = r.ext
            }
        }

        // Finalisation : le fichier est publié dans Movies/VidGrab
        update(item.id) { it.copy(state = DownloadState.MERGING, speedBps = 0) }
        val uri = Storage.saveToMovies(app, file, "${item.title}.$ext", ext)
        val video = LibraryVideo(
            id = UUID.randomUUID().toString(),
            title = item.title,
            ext = ext,
            uriString = uri.toString(),
            sizeBytes = file.length(),
            durationMs = Storage.duration(app, uri),
            seen = false,
            isPrivate = false,
            addedAt = System.currentTimeMillis()
        )
        LibraryStore.add(video)
        dir.deleteRecursively()
        _items.update { list -> list.filter { it.id != item.id } }
        persist()
        Notifs.done(app, item.title)
    }
}
