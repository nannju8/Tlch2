package com.vidgrab.app.net

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Registre des connexions ouvertes pour un téléchargement.
 * Permet d'interrompre immédiatement toutes les lectures bloquantes (pause / annulation).
 */
class ConnectionRegistry {
    private val conns = ConcurrentLinkedQueue<HttpURLConnection>()

    @Volatile
    var aborted: Boolean = false
        private set

    fun add(c: HttpURLConnection) {
        conns.add(c)
        if (aborted) runCatching { c.disconnect() }
    }

    fun remove(c: HttpURLConnection) {
        conns.remove(c)
    }

    fun abort() {
        aborted = true
        conns.forEach { runCatching { it.disconnect() } }
    }
}

object Http {
    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/126.0.0.0 Mobile Safari/537.36"

    /**
     * Ouvre une connexion GET, suit manuellement les redirections (y compris http -> https)
     * et retourne la connexion dont le code de réponse est déjà lu (non 3xx).
     */
    fun connect(
        url: String,
        ua: String?,
        referer: String?,
        cookies: String?,
        range: String?,
        reg: ConnectionRegistry?
    ): HttpURLConnection {
        var current = url
        for (hop in 0 until 8) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12_000
            c.readTimeout = 20_000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", ua ?: DEFAULT_UA)
            c.setRequestProperty("Accept", "*/*")
            // "identity" : indispensable pour que Content-Length / Range soient fiables
            c.setRequestProperty("Accept-Encoding", "identity")
            if (!referer.isNullOrBlank()) c.setRequestProperty("Referer", referer)
            if (!cookies.isNullOrBlank()) c.setRequestProperty("Cookie", cookies)
            if (range != null) c.setRequestProperty("Range", range)
            reg?.add(c)
            try {
                val code = c.responseCode
                if (code in 300..399 && code != 304) {
                    val loc = c.getHeaderField("Location")
                    c.disconnect()
                    reg?.remove(c)
                    if (loc == null) throw IOException("Redirection invalide")
                    current = URL(URL(current), loc).toString()
                    continue
                }
                return c
            } catch (e: IOException) {
                reg?.remove(c)
                runCatching { c.disconnect() }
                throw e
            }
        }
        throw IOException("Trop de redirections")
    }

    fun fetchTextOrThrow(
        url: String,
        ua: String?,
        referer: String?,
        cookies: String?,
        reg: ConnectionRegistry? = null
    ): String {
        val c = connect(url, ua, referer, cookies, null, reg)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            runCatching { c.disconnect() }
            reg?.remove(c)
        }
    }

    fun fetchText(url: String, ua: String?, referer: String?, cookies: String?): String? =
        try {
            fetchTextOrThrow(url, ua, referer, cookies)
        } catch (e: Exception) {
            null
        }

    fun fetchBytes(
        url: String,
        ua: String?,
        referer: String?,
        cookies: String?,
        reg: ConnectionRegistry?
    ): ByteArray {
        val c = connect(url, ua, referer, cookies, null, reg)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } finally {
            runCatching { c.disconnect() }
            reg?.remove(c)
        }
    }
}
