package com.vidgrab.app.net

import java.net.URI
import java.net.URL

data class HlsVariant(val url: String, val bandwidth: Long, val width: Int, val height: Int)

class HlsKey(val method: String, val uri: String?, val iv: ByteArray?)

data class HlsSegment(
    val index: Int,
    val url: String,
    val duration: Double,
    val key: HlsKey?,
    val sequence: Long
)

data class HlsPlaylist(
    val segments: List<HlsSegment>,
    val initUrl: String?,
    val totalDuration: Double,
    val endList: Boolean
)

/** Parseur HLS natif (master playlist + media playlist, AES-128, EXT-X-MAP). */
object HlsParser {
    private val ATTR = Regex("""([A-Z0-9-]+)=("[^"]*"|[^,]*)""")

    fun attrs(s: String): Map<String, String> =
        ATTR.findAll(s).associate { it.groupValues[1] to it.groupValues[2].trim().trim('"') }

    fun resolve(base: String, ref: String): String {
        val r = ref.trim()
        return try {
            URI(base).resolve(r).toString()
        } catch (e: Exception) {
            URL(URL(base), r).toString()
        }
    }

    fun isMaster(text: String): Boolean = text.contains("#EXT-X-STREAM-INF")

    fun parseMaster(text: String, base: String): List<HlsVariant> {
        val out = mutableListOf<HlsVariant>()
        var pending: Map<String, String>? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                pending = attrs(line.substringAfter(':'))
            } else if (line.isEmpty() || line.startsWith("#")) {
                continue
            } else {
                val a = pending
                if (a != null) {
                    val res = a["RESOLUTION"]?.split('x')
                    out += HlsVariant(
                        url = resolve(base, line),
                        bandwidth = (a["AVERAGE-BANDWIDTH"] ?: a["BANDWIDTH"])?.toLongOrNull() ?: 0L,
                        width = res?.getOrNull(0)?.toIntOrNull() ?: 0,
                        height = res?.getOrNull(1)?.toIntOrNull() ?: 0
                    )
                    pending = null
                }
            }
        }
        return out
    }

    fun parseMedia(text: String, base: String): HlsPlaylist {
        var seq = 0L
        var key: HlsKey? = null
        var initUrl: String? = null
        var total = 0.0
        var end = false
        var pendingDur = -1.0
        val segs = mutableListOf<HlsSegment>()

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:") ->
                    seq = line.substringAfter(':').trim().toLongOrNull() ?: 0L

                line.startsWith("#EXT-X-KEY:") -> {
                    val a = attrs(line.substringAfter(':'))
                    val method = a["METHOD"] ?: "NONE"
                    key = if (method == "NONE") null
                    else HlsKey(method, a["URI"]?.let { resolve(base, it) }, a["IV"]?.let { parseIv(it) })
                }

                line.startsWith("#EXT-X-MAP:") ->
                    initUrl = attrs(line.substringAfter(':'))["URI"]?.let { resolve(base, it) }

                line.startsWith("#EXTINF:") ->
                    pendingDur = line.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0

                line == "#EXT-X-ENDLIST" -> end = true

                line.startsWith("#") -> Unit

                else -> {
                    val idx = segs.size
                    val d = if (pendingDur > 0) pendingDur else 0.0
                    segs += HlsSegment(idx, resolve(base, line), d, key, seq + idx)
                    total += d
                    pendingDur = -1.0
                }
            }
        }
        return HlsPlaylist(segs, initUrl, total, end)
    }

    private fun parseIv(s: String): ByteArray {
        val hex = s.removePrefix("0x").removePrefix("0X").padStart(32, '0').takeLast(32)
        return ByteArray(16) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** IV par défaut = numéro de séquence du segment (big-endian sur 16 octets). */
    fun ivFromSequence(seq: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0 until 8) iv[15 - i] = ((seq shr (8 * i)) and 0xff).toByte()
        return iv
    }
}
