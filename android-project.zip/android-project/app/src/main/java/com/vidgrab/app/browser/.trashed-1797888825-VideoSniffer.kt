package com.vidgrab.app.browser

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.net.ConnectionRegistry
import com.vidgrab.app.net.HlsParser
import com.vidgrab.app.net.Http
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Sniffer réseau : analysé depuis WebViewClient.shouldInterceptRequest.
 *  - extensions d'URL : .mp4 .webm .mkv .m3u8
 *  - en-tête Content-Type (sonde GET Range: bytes=0-0) pour les URL sans extension explicite
 *  - exclusion stricte de YouTube et des régies publicitaires
 */
class VideoSniffer(private val tab: TabState, private val userAgent: String) {

    companion object {
        val BLOCKED_HOSTS = listOf("youtube.com", "googlevideo.com", "youtu.be", "youtube-nocookie.com")
        private val DIRECT_EXT = setOf("mp4", "webm", "mkv")
        private val IGNORED_EXT = setOf(
            "js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2", "ttf", "otf",
            "json", "html", "htm", "map", "txt", "xml", "ts", "m4s", "aac", "mp3", "vtt", "srt", "avif"
        )
        private val HINTS = listOf("video", "mime=video", "mpegurl", "/media/", "playback", "manifest", "stream")
        private const val MIN_SIZE = 150L * 1024

        fun isBlocked(host: String?): Boolean {
            val h = host?.lowercase() ?: return false
            return BLOCKED_HOSTS.any { h == it || h.endsWith(".$it") } || AdFilter.isAdHost(h)
        }
    }

    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val variantUrls = ConcurrentHashMap.newKeySet<String>()
    private val probeExec = Executors.newFixedThreadPool(3)
    private val hlsExec = Executors.newSingleThreadExecutor() // séquentiel : master avant variantes
    private val main = Handler(Looper.getMainLooper())

    fun reset() {
        seen.clear()
        variantUrls.clear()
    }

    fun shutdown() {
        probeExec.shutdownNow()
        hlsExec.shutdownNow()
    }

    /** Appelé depuis un thread d'arrière-plan (shouldInterceptRequest). */
    fun inspect(url: String, headers: Map<String, String>, pageUrl: String?) {
        if (!url.startsWith("http")) return
        if (AdFilter.isAdUrl(url) || AdFilter.isAdUrl(pageUrl)) return
        val uri = Uri.parse(url)
        if (isBlocked(uri.host) || isBlocked(runCatching { Uri.parse(pageUrl ?: "").host }.getOrNull())) return
        val path = (uri.path ?: "").lowercase()
        val ext = path.substringAfterLast('.', "")
        if (!seen.add(url)) return
        when {
            ext == "m3u8" -> hlsExec.execute { handleHls(url, pageUrl) }
            ext in DIRECT_EXT -> probeExec.execute { handleProbe(url, pageUrl, ext, forced = true) }
            ext in IGNORED_EXT -> Unit
            headers.keys.any { it.equals("Range", ignoreCase = true) } ||
                HINTS.any { url.contains(it, ignoreCase = true) } ->
                probeExec.execute { handleProbe(url, pageUrl, ext, forced = false) }
        }
    }

    /** Appelé par le DownloadListener du WebView (liens de téléchargement directs). */
    fun reportDownload(url: String, mime: String?, length: Long, pageUrl: String?) {
        if (AdFilter.isAdUrl(url) || isBlocked(Uri.parse(url).host)) return
        val m = mime?.lowercase() ?: ""
        if (!m.startsWith("video/") && !m.contains("mpegurl")) return
        if (!seen.add(url)) return
        if (m.contains("mpegurl")) hlsExec.execute { handleHls(url, pageUrl) }
        else probeExec.execute { handleProbe(url, pageUrl, extFromMime(m), forced = true, knownSize = length) }
    }

    // ------------------------------------------------------------------ sonde HTTP

    private class Probe(val contentType: String?, val size: Long)

    private fun cookiesFor(url: String): String? = try {
        CookieManager.getInstance().getCookie(url)
    } catch (e: Exception) {
        null
    }

    private fun probe(url: String, pageUrl: String?): Probe? {
        val reg = ConnectionRegistry()
        return try {
            val c = Http.connect(url, userAgent, pageUrl, cookiesFor(url), "bytes=0-0", reg)
            try {
                val code = c.responseCode
                if (code !in 200..299) return null
                val ct = c.contentType?.lowercase()?.substringBefore(';')?.trim()
                val size = c.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull()
                    ?: c.contentLengthLong
                Probe(ct, size)
            } finally {
                runCatching { c.disconnect() }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun extFromMime(ct: String): String = when {
        ct.contains("webm") -> "webm"
        ct.contains("matroska") -> "mkv"
        else -> "mp4"
    }

    private fun handleProbe(url: String, pageUrl: String?, ext: String, forced: Boolean, knownSize: Long = -1L) {
        val p = probe(url, pageUrl)
        val ct = p?.contentType
        if (ct != null && ct.contains("mpegurl")) {
            hlsExec.execute { handleHls(url, pageUrl) }
            return
        }
        if (p == null && !forced) return
        if (forced) {
            if (ct != null && (ct.startsWith("audio/") || ct.contains("mp2t") || ct.startsWith("text/") ||
                    ct.contains("html") || ct.contains("json") || ct.startsWith("image/"))
            ) return
        } else {
            val isVideo = ct != null && ct.startsWith("video/") && !ct.contains("mp2t") && !ct.contains("iso.segment")
            if (!isVideo) return
        }
        val size = p?.size?.takeIf { it > 0 } ?: knownSize
        if (size in 1 until MIN_SIZE) return
        val e = if (ext in DIRECT_EXT) ext else extFromMime(ct ?: "")
        publish(
            DetectedVideo(
                id = "d" + url.hashCode().toString(16),
                url = url,
                pageUrl = pageUrl,
                title = tab.title,
                kind = VideoKind.DIRECT,
                ext = e,
                label = e.uppercase(),
                sizeBytes = size,
                durationSec = 0.0,
                height = 0,
                userAgent = userAgent,
                cookies = cookiesFor(url)
            )
        )
    }

    // ------------------------------------------------------------------ HLS

    private fun qualityLabel(height: Int, bandwidth: Long): String = when {
        height > 0 -> "${height}p"
        bandwidth > 0 -> "${bandwidth / 1000} kbps"
        else -> "Auto"
    }

    private fun handleHls(url: String, pageUrl: String?) {
        val cookies = cookiesFor(url)
        val text = Http.fetchText(url, userAgent, pageUrl, cookies) ?: return
        if (HlsParser.isMaster(text)) {
            val variants = HlsParser.parseMaster(text, url).sortedByDescending { it.height * 1_000_000L + it.bandwidth }
            if (variants.isEmpty()) return
            variants.forEach { variantUrls.add(it.url) }
            // Durée récupérée sur la première variante pour estimer la taille de chacune
            val duration = Http.fetchText(variants.first().url, userAgent, pageUrl, cookies)
                ?.let { HlsParser.parseMedia(it, variants.first().url).totalDuration } ?: 0.0
            for (v in variants) {
                publish(
                    DetectedVideo(
                        id = "h" + v.url.hashCode().toString(16),
                        url = v.url,
                        pageUrl = pageUrl,
                        title = tab.title,
                        kind = VideoKind.HLS,
                        ext = "mp4",
                        label = qualityLabel(v.height, v.bandwidth),
                        sizeBytes = if (duration > 0 && v.bandwidth > 0) (v.bandwidth * duration / 8).toLong() else -1L,
                        durationSec = duration,
                        height = v.height,
                        userAgent = userAgent,
                        cookies = cookies
                    )
                )
            }
        } else if (text.contains("#EXTINF")) {
            if (url in variantUrls) return
            val pl = HlsParser.parseMedia(text, url)
            if (pl.segments.isEmpty()) return
            publish(
                DetectedVideo(
                    id = "h" + url.hashCode().toString(16),
                    url = url,
                    pageUrl = pageUrl,
                    title = tab.title,
                    kind = VideoKind.HLS,
                    ext = "mp4",
                    label = "HLS",
                    sizeBytes = -1L,
                    durationSec = pl.totalDuration,
                    height = 0,
                    userAgent = userAgent,
                    cookies = cookies
                )
            )
        }
    }

    private fun publish(v: DetectedVideo) {
        main.post {
            if (tab.detected.none { it.id == v.id }) tab.detected.add(v)
        }
    }
}