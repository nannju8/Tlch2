package com.vidgrab.app.download

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Chien de garde WorkManager : toutes les 15 min, si des téléchargements sont en attente
 * (processus tué, service arrêté par le système…), il relance le service et la file d'attente.
 */
class DownloadWatchdogWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        DownloadCenter.resumePending()
        return Result.success()
    }

    companion object {
        private const val NAME = "vidgrab_watchdog"

        fun schedule(ctx: Context) {
            val request = PeriodicWorkRequestBuilder<DownloadWatchdogWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }
}
